import bpy
import os
import sys
import textwrap

# ==============================================================================
# 0. CUSTOM PROPERTIES
# ==============================================================================

class FrameItem(bpy.types.PropertyGroup):
	"""Holds a single frame number item in the collection list."""
	frame: bpy.props.IntProperty(
		name="Frame",
		description="A specific frame number to render",
		min=1
	)

class CustomRenderSettings(bpy.types.PropertyGroup):
	"""Holds the collection of frames and the utility CSV string."""
	frame_items: bpy.props.CollectionProperty(type=FrameItem)
	frame_list_csv_utility: bpy.props.StringProperty(
		name="CSV String",
		description="Temporary field for batch importing/exporting the frame list (e.g., 1, 5, 10-20)",
		default=""
	)

# ==============================================================================
# 1. UTILITY FUNCTIONS
# ==============================================================================

def parse_frame_string(frame_str):
	"""Parses a string like '1, 5, 10-20' into a sorted list of unique integers."""
	frames = set()
	if not frame_str:
		return []
	parts = frame_str.replace(" ", "").split(',')
	for part in parts:
		if not part: continue
		if '-' in part:
			try:
				start, end = map(int, part.split('-'))
				if start > end: start, end = end, start
				frames.update(range(start, end + 1))
			except ValueError:
				print(f"Warning: Invalid frame range '{part}' ignored.")
		else:
			try:
				frames.add(int(part))
			except ValueError:
				print(f"Warning: Invalid frame number '{part}' ignored.")
	return sorted(list(frames))

def get_frames_from_collection(settings):
	"""Reads frames from the CollectionProperty and returns a sorted list of unique integers."""
	return sorted(list(set(item.frame for item in settings.frame_items)))

def rebuild_collection_from_frames(settings, frames_list):
	"""Clears the existing collection and rebuilds it from a sorted list of frames."""
	settings.frame_items.clear()
	for frame in frames_list:
		new_item = settings.frame_items.add()
		new_item.frame = frame

def sanitize_collection(settings):
	"""Removes duplicate frame numbers from the CollectionProperty."""
	seen_frames = set()
	indices_to_remove = []
	for i, item in enumerate(settings.frame_items):
		if item.frame in seen_frames:
			indices_to_remove.append(i)
		else:
			seen_frames.add(item.frame)
	if indices_to_remove:
		for index in reversed(indices_to_remove):
			settings.frame_items.remove(index)
		return True
	return False

def get_output_path_for_frame(scene, frame):
	"""Constructs the absolute output file path for a given frame."""
	filepath = scene.render.filepath
	if '#' in filepath:
		padding = filepath.count('#')
		frame_number_str = str(frame).zfill(padding)
		hash_start = filepath.find('#')
		filepath = filepath[:hash_start] + frame_number_str + filepath[hash_start + padding:]
	else:
		filepath += str(frame).zfill(4)
	abs_filepath = bpy.path.abspath(filepath)
	img_format = scene.render.image_settings.file_format
	video_formats = {'AVI', 'FFMPEG', 'QUICKTIME', 'H264', 'MPEG', 'OGG'}
	if img_format not in video_formats:
		ext_map = {'PNG': '.png', 'JPEG': '.jpg', 'BMP': '.bmp', 'TIFF': '.tif', 'OPEN_EXR': '.exr', 'OPEN_EXR_MULTILAYER': '.exr'}
		ext = ext_map.get(img_format, '')
		if ext and not abs_filepath.lower().endswith(ext):
			abs_filepath += ext
	return abs_filepath

def filter_existing_frames(scene, frames_to_check):
	"""Returns a new list containing only frames for which an output file does NOT already exist."""
	return [frame for frame in frames_to_check if not os.path.exists(get_output_path_for_frame(scene, frame))]

# ==============================================================================
# 2. RENDER MANAGEMENT
# ==============================================================================

# --- Global State and Compatibility Check ---
IS_ASYNC_SUPPORTED = hasattr(bpy.app, 'is_job_running')
custom_render_cancel_handler = None
render_timer = None

RENDER_STATE = {
	"is_running": False,
	"frames_to_render": [],
	"current_index": 0,
	"original_frame_start": 1,
	"original_frame_end": 250,
	"original_overwrite_state": False,
	"is_two_phase_render": False,
	"phase_1_frames": set(),
}

def clean_up_render_job(scene, is_cancellation=False):
	"""Restores scene state, unregisters timer and handler."""
	global render_timer, custom_render_cancel_handler
	if render_timer:
		bpy.app.timers.unregister(render_next_frame_modal)
		render_timer = None
	scene.frame_start = RENDER_STATE["original_frame_start"]
	scene.frame_end = RENDER_STATE["original_frame_end"]
	if not RENDER_STATE["is_two_phase_render"] or is_cancellation:
		scene.render.use_overwrite = RENDER_STATE["original_overwrite_state"]
	if custom_render_cancel_handler:
		if custom_render_cancel_handler in bpy.app.handlers.render_cancel:
			bpy.app.handlers.render_cancel.remove(custom_render_cancel_handler)
		custom_render_cancel_handler = None
	RENDER_STATE["is_running"] = False
	RENDER_STATE["frames_to_render"] = []
	if is_cancellation:
		print("Custom render job stopped and scene state restored due to cancellation (ESC).")

def handle_render_cancel(scene):
	"""Async: Handler called when user cancels render (e.g., ESC)."""
	if RENDER_STATE["is_running"]:
		clean_up_render_job(scene, is_cancellation=True)
	return None

# --- Asynchronous (Modern Blender) Functions ---
def render_next_frame_modal():
	"""Async: Modal timer function to render frames sequentially."""
	if bpy.app.is_job_running('RENDER'):
		return 0.1
	if RENDER_STATE["current_index"] >= len(RENDER_STATE["frames_to_render"]):
		finish_render_job()
		return None
	
	frame = RENDER_STATE["frames_to_render"][RENDER_STATE["current_index"]]
	# Set scene to render just this one frame
	for prop in ['frame_start', 'frame_end', 'frame_current']:
		setattr(bpy.context.scene, prop, frame)
		
	bpy.ops.render.render('INVOKE_DEFAULT', animation=True)
	RENDER_STATE["current_index"] += 1
	return 0.1

def finish_render_job():
	"""Async: Called when phase 1 completes."""
	scene = bpy.context.scene
	was_two_phase = RENDER_STATE["is_two_phase_render"]
	# Cleanup restores original frame start/end
	clean_up_render_job(scene)
	print("Specific frame rendering complete.")
	if was_two_phase:
		execute_phase_2(scene)
	else:
		print("Render complete.")

def execute_phase_2(scene):
	"""Async & Sync: Handles the logic for the second pass (Full Animation)."""
	scene.render.use_overwrite = False
	print("Starting Full Animation pass: Rendering remaining animation range.")
	if RENDER_STATE["original_overwrite_state"]:
		print("Overwrite was enabled. Deleting non-Key Frame files before rendering Full Animation.")
		frames_in_range = range(scene.frame_start, scene.frame_end + 1, scene.frame_step)
		deleted_count = 0
		for frame in frames_in_range:
			if frame in RENDER_STATE["phase_1_frames"]:
				continue
			filepath = get_output_path_for_frame(scene, frame)
			if os.path.exists(filepath):
				try:
					os.remove(filepath)
					deleted_count += 1
				except OSError as e:
					print(f"Error deleting file {filepath}: {e}", file=sys.stderr)
		print(f"Full Animation pre-render cleanup: Deleted {deleted_count} files.")
	
	# Phase 2 is always invoked asynchronously to let the user see progress
	bpy.ops.render.render('INVOKE_DEFAULT', animation=True)


# --- Synchronous (Older Blender) Functions ---
def render_frames_synchronous(scene, frames_to_render):
	"""Sync: Loops through and renders frames, blocking the UI."""
	print(f"Starting synchronous render of {len(frames_to_render)} frames.")
	for i, frame in enumerate(frames_to_render):
		print(f"Rendering frame {frame} ({i+1}/{len(frames_to_render)})...")
		# Set scene to render just this one frame
		for prop in ['frame_start', 'frame_end', 'frame_current']:
			setattr(scene, prop, frame)
		bpy.ops.render.render('EXEC_DEFAULT', animation=True)
	print("Specific frame rendering complete.")


# ==============================================================================
# 3. OPERATORS (UI Management)
# ==============================================================================

class RENDER_OT_list_add(bpy.types.Operator):
	"""Adds the current frame to the list."""
	bl_idname = "render.frame_list_add"
	bl_label = "Add Frame"
	def execute(self, context):
		settings = context.scene.custom_render_settings
		new_item = settings.frame_items.add()
		new_item.frame = context.scene.frame_current
		return {'FINISHED'}

class RENDER_OT_list_remove(bpy.types.Operator):
	"""Removes the selected frame from the list."""
	bl_idname = "render.frame_list_remove"
	bl_label = "Remove Frame"
	index: bpy.props.IntProperty()
	def execute(self, context):
		settings = context.scene.custom_render_settings
		settings.frame_items.remove(self.index)
		return {'FINISHED'}

class RENDER_OT_csv_import(bpy.types.Operator):
	"""Parses the CSV string and populates the frame list."""
	bl_idname = "render.csv_import"
	bl_label = "Import List"
	def execute(self, context):
		settings = context.scene.custom_render_settings
		frames_list = parse_frame_string(settings.frame_list_csv_utility)
		if not frames_list:
			self.report({'WARNING'}, "No valid frames found in CSV string.")
			return {'CANCELLED'}
		rebuild_collection_from_frames(settings, frames_list)
		self.report({'INFO'}, f"Imported {len(frames_list)} unique frames.")
		return {'FINISHED'}

class RENDER_OT_csv_export(bpy.types.Operator):
	"""Generates a CSV string from the frame list and removes duplicates."""
	bl_idname = "render.csv_export"
	bl_label = "Export List"
	def execute(self, context):
		settings = context.scene.custom_render_settings
		if sanitize_collection(settings):
			self.report({'WARNING'}, "Duplicate frames were removed.")
		frames_list = get_frames_from_collection(settings)
		if not frames_list:
			settings.frame_list_csv_utility = ""
			self.report({'WARNING'}, "Frame list is empty.")
			return {'CANCELLED'}
		settings.frame_list_csv_utility = ", ".join(map(str, frames_list))
		self.report({'INFO'}, "Frame list exported to CSV field.")
		return {'FINISHED'}

# ==============================================================================
# 4. OPERATORS (Render Management)
# ==============================================================================

class RENDER_OT_refresh_from_markers(bpy.types.Operator):
	"""Generates a frame list from timeline markers with a camera (F & F-1)."""
	bl_idname = "render.refresh_from_markers"
	bl_label = "Generate List from Camera Markers (F & F-1)"
	bl_description = "Generates a frame list from camera markers (marker frame F and preceding frame F-1)"

	def execute(self, context):
		scene = context.scene
		settings = scene.custom_render_settings
		frames = set()
		frame_start, frame_end = scene.frame_start, scene.frame_end
		for marker in scene.timeline_markers:
			if marker.camera and frame_start < marker.frame <= frame_end:
				frames.add(marker.frame)
				if marker.frame - 1 >= frame_start:
					frames.add(marker.frame - 1)
		sorted_frames = sorted(list(frames))
		if not sorted_frames:
			settings.frame_items.clear()
			self.report({'INFO'}, "No eligible camera markers found in the scene range.")
			return {'FINISHED'}
		rebuild_collection_from_frames(settings, sorted_frames)
		self.report({'INFO'}, f"Frame list refreshed with {len(sorted_frames)} frames.")
		return {'FINISHED'}

class RENDER_OT_KeyframeOnly(bpy.types.Operator):
	"""Renders only the frames specified in the custom frame list."""
	bl_idname = "render.keyframes_only"
	bl_label = "Render Only Specific Frames"

	@classmethod
	def poll(cls, context):
		if RENDER_STATE["is_running"]:
			cls.poll_message_set("A render job is already running.")
			return False
		if context.scene.render.is_movie_format:
			cls.poll_message_set("Requires an Image Sequence output format.")
			return False
		return True

	def execute(self, context):
		global render_timer, custom_render_cancel_handler
		scene = context.scene
		settings = scene.custom_render_settings
		if sanitize_collection(settings):
			self.report({'WARNING'}, "Duplicate frames removed from list.")
		initial_frames = get_frames_from_collection(settings)
		if not initial_frames:
			self.report({'INFO'}, "Frame list is empty. Nothing to render.")
			return {'CANCELLED'}
		
		frames_to_render = []
		if not scene.render.use_overwrite:
			print("Overwrite is OFF. Checking for existing files to skip...")
			frames_to_render = filter_existing_frames(scene, initial_frames)
			if not frames_to_render:
				self.report({'INFO'}, "All frames already exist. Nothing to render.")
				return {'FINISHED'}
		else:
			print("Overwrite is ON. All specific frames will be rendered.")
			frames_to_render = initial_frames

		# --- Save Original State ---
		RENDER_STATE["original_frame_start"] = scene.frame_start
		RENDER_STATE["original_frame_end"] = scene.frame_end
		RENDER_STATE["original_overwrite_state"] = scene.render.use_overwrite
		RENDER_STATE["is_two_phase_render"] = False

		if IS_ASYNC_SUPPORTED:
			# --- Asynchronous Execution ---
			if handle_render_cancel not in bpy.app.handlers.render_cancel:
				bpy.app.handlers.render_cancel.append(handle_render_cancel)
				custom_render_cancel_handler = handle_render_cancel
			RENDER_STATE["is_running"] = True
			RENDER_STATE["frames_to_render"] = frames_to_render
			RENDER_STATE["current_index"] = 0
			render_timer = bpy.app.timers.register(render_next_frame_modal, first_interval=0.1)
			self.report({'INFO'}, f"Started async rendering of {len(frames_to_render)} frames.")
		else:
			# --- Synchronous Execution ---
			self.report({'INFO'}, f"Started sync rendering of {len(frames_to_render)} frames. UI will freeze.")
			render_frames_synchronous(scene, frames_to_render)
			# Restore state immediately
			scene.frame_start = RENDER_STATE["original_frame_start"]
			scene.frame_end = RENDER_STATE["original_frame_end"]
			scene.render.use_overwrite = RENDER_STATE["original_overwrite_state"]
			print("Render complete.")
			self.report({'INFO'}, "Synchronous render finished.")
		
		return {'FINISHED'}

class RENDER_OT_FullAnimationWithKeyframes(bpy.types.Operator):
	"""Renders in two passes: 1. Specific frames. 2. Rest of animation range."""
	bl_idname = "render.full_animation_with_keyframes"
	bl_label = "Render Full Animation"

	@classmethod
	def poll(cls, context):
		if RENDER_STATE["is_running"]:
			cls.poll_message_set("A render job is already running.")
			return False
		if context.scene.render.is_movie_format:
			cls.poll_message_set("Requires an Image Sequence output format.")
			return False
		return True

	def execute(self, context):
		global render_timer, custom_render_cancel_handler
		scene = context.scene
		settings = scene.custom_render_settings
		if sanitize_collection(settings):
			self.report({'WARNING'}, "Duplicate frames removed from list.")
		initial_frames = get_frames_from_collection(settings)

		# --- Save Original State ---
		RENDER_STATE["original_frame_start"] = scene.frame_start
		RENDER_STATE["original_frame_end"] = scene.frame_end
		RENDER_STATE["original_overwrite_state"] = scene.render.use_overwrite
		RENDER_STATE["is_two_phase_render"] = True
		RENDER_STATE["phase_1_frames"] = set(initial_frames)

		if not initial_frames:
			self.report({'WARNING'}, "Frame list is empty. Rendering full animation directly.")
			execute_phase_2(scene)
			return {'FINISHED'}

		frames_for_phase_1 = []
		if not scene.render.use_overwrite:
			print("Overwrite is OFF. Checking for existing files for first pass.")
			frames_for_phase_1 = filter_existing_frames(scene, initial_frames)
		else:
			print("Overwrite is ON. All specific frames will be rendered in first pass.")
			frames_for_phase_1 = initial_frames

		if not frames_for_phase_1:
			print("No specific frames to render in first pass (all exist). Skipping to Full Animation.")
			execute_phase_2(scene)
			return {'FINISHED'}
		
		if IS_ASYNC_SUPPORTED:
			# --- Asynchronous Execution ---
			if handle_render_cancel not in bpy.app.handlers.render_cancel:
				bpy.app.handlers.render_cancel.append(handle_render_cancel)
				custom_render_cancel_handler = handle_render_cancel
			RENDER_STATE["is_running"] = True
			RENDER_STATE["frames_to_render"] = frames_for_phase_1
			RENDER_STATE["current_index"] = 0
			render_timer = bpy.app.timers.register(render_next_frame_modal, first_interval=0.1)
			self.report({'INFO'}, f"Started async render pass 1/2 ({len(frames_for_phase_1)} frames).")
		else:
			# --- Synchronous Execution ---
			self.report({'INFO'}, f"Started sync render pass 1/2 ({len(frames_for_phase_1)} frames). UI will freeze.")
			render_frames_synchronous(scene, frames_for_phase_1)
			# Restore original frame range for phase 2
			scene.frame_start = RENDER_STATE["original_frame_start"]
			scene.frame_end = RENDER_STATE["original_frame_end"]
			execute_phase_2(scene)
			# State is NOT fully restored here, as phase 2 (async) is now running.
			# We only restore the overwrite state in the sync-only operator.
			self.report({'INFO'}, "Sync render pass 1/2 finished, starting pass 2/2.")

		return {'FINISHED'}

# ==============================================================================
# 5. PANEL UI
# ==============================================================================

class AUTO_CUTSMART_PT_custom_render_panel(bpy.types.Panel):
	"""Creates a custom panel in the Render Properties window."""
	bl_label = "Auto CutSmart - Render Tool"
	bl_idname = "AUTO_CUTSMART_PT_custom_render"
	bl_space_type = 'PROPERTIES'
	bl_region_type = 'WINDOW'
	bl_context = "render"
	bl_options = {'DEFAULT_CLOSED'}

	def draw(self, context):
		layout = self.layout
		scene = context.scene
		settings = scene.custom_render_settings

		# --- Render Progress Info (Only for Async) ---
		if IS_ASYNC_SUPPORTED and (RENDER_STATE["is_running"] or (RENDER_STATE["is_two_phase_render"] and bpy.app.is_job_running('RENDER'))):
			InfoBox = layout.box()
			if RENDER_STATE["is_running"]:
				phase_text = "[1/2] Rendering specific frames..." if RENDER_STATE["is_two_phase_render"] else "Render Job in Progress..."
				InfoBox.label(text=phase_text, icon='INFO')
			elif RENDER_STATE["is_two_phase_render"] and bpy.app.is_job_running('RENDER'):
				InfoBox.label(text="[2/2] Rendering rest of animation...", icon='INFO')

		# --- Render Execution ---
		RenderOpBox = layout.box()
		RenderOpBox.label(text="Render Execution Modes", icon='SCENE')
		if scene.render.is_movie_format:
			warningBox = RenderOpBox.box()
			warningBox.alert = True
			part_1 = "Output format must be an image sequence (e.g., PNG)."
			part_2 = "Use the Video Editor to compile the final video."
			try: panel_width_chars = max(1, int((context.region.width - 40) / 7))
			except AttributeError: panel_width_chars = 30
			wrapper = textwrap.TextWrapper(width=panel_width_chars, break_long_words=False)
			wrapped_lines = wrapper.wrap(part_1) + wrapper.wrap(part_2)
			warning_col = warningBox.column(align=True)
			for i, line in enumerate(wrapped_lines):
				warning_col.label(text=line, icon='ERROR' if i == 0 else 'BLANK1')
		col = RenderOpBox.column(align=True)
		col.operator(RENDER_OT_KeyframeOnly.bl_idname, icon='RENDER_STILL')
		col.operator(RENDER_OT_FullAnimationWithKeyframes.bl_idname, icon='RENDER_ANIMATION')

		# --- Custom Frame List ---
		frame_counts = {}
		for item in settings.frame_items:
			frame_counts[item.frame] = frame_counts.get(item.frame, 0) + 1
		box = layout.box()
		box.label(text="Specific Frames to Render", icon='KEYFRAME')
		box.operator(RENDER_OT_refresh_from_markers.bl_idname, icon='FILE_REFRESH', text="Generate List from Camera Markers")
		boxList = box.box()
		col = boxList.column(align=True)
		if not settings.frame_items:
			col.label(text="List is currently empty.", icon='INFO')
		for i, item in enumerate(settings.frame_items):
			is_duplicate = frame_counts.get(item.frame, 0) > 1
			row = col.row(align=True)
			row.prop(item, "frame", text=f"Frame {i+1}")
			row.alert = is_duplicate
			if is_duplicate:
				row.label(text="(DUPLICATE)")
			remove_op = row.operator(RENDER_OT_list_remove.bl_idname, text="", icon='REMOVE')
			remove_op.index = i
		boxList.operator(RENDER_OT_list_add.bl_idname, text="Add Current Frame", icon='ADD')

		# --- CSV Import/Export Utility ---
		boxB = box.box()
		boxB.label(text="Batch Import / Export", icon='FILE_TEXT')
		boxB.prop(settings, "frame_list_csv_utility", text="CSV Data")
		row = boxB.row(align=True)
		row.operator(RENDER_OT_csv_import.bl_idname, icon='IMPORT', text="Import List")
		row.operator(RENDER_OT_csv_export.bl_idname, icon='EXPORT', text="Export List")

# ==============================================================================
# 6. REGISTRATION
# ==============================================================================

classes = (
	FrameItem,
	CustomRenderSettings,
	RENDER_OT_list_add,
	RENDER_OT_list_remove,
	RENDER_OT_csv_import,
	RENDER_OT_csv_export,
	RENDER_OT_refresh_from_markers,
	RENDER_OT_KeyframeOnly,
	RENDER_OT_FullAnimationWithKeyframes,
	AUTO_CUTSMART_PT_custom_render_panel,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	bpy.types.Scene.custom_render_settings = bpy.props.PointerProperty(type=CustomRenderSettings)
	if not IS_ASYNC_SUPPORTED:
		print("Auto CutSmart Render Tool: Running in synchronous compatibility mode for older Blender versions.")


def unregister():
	if hasattr(bpy.types.Scene, 'custom_render_settings'):
		del bpy.types.Scene.custom_render_settings
	for cls in reversed(classes):
		try:
			bpy.utils.unregister_class(cls)
		except RuntimeError:
			pass

