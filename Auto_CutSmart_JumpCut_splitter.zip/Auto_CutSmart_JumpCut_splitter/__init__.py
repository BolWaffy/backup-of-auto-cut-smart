# __init__.py for the Camera Jump Split Addon
# This script automates splitting a camera's animation into segments based on detected "jump cuts"
# and assigns these segments to two new duplicate cameras. It then creates timeline markers
# to switch between these cameras at the jump points, avoiding harsh motion blur.

bl_info = {
	"name": "Auto CutSmart – Seamless JumpCuts",
	"author": "BolWaffy",
	"version": (0, 0, 1),
	"blender": (4, 2, 0),
	"location": "Properties > Camera Data > Camera Tools",
	"description": "Automatically detects jump cuts in a camera’s animation, duplicates the camera, splits the camera's animation at detected jump cuts, and creates alternating camera markers to avoid harsh motion blur effect during jumps.",
	"warning": "Beta",
	"doc_url": "https://github.com/BolWaffy/Auto-CutSmart-Seamless-JumpCuts/wiki",
	"tracker_url": "https://github.com/BolWaffy/Auto-CutSmart-Seamless-JumpCuts/issues/new/choose",
	"category": "Animation",
}

# --- Imports --- #
import bpy
import math
import mathutils
from math import degrees
import time
import os
import shutil
from collections import deque
import traceback
import re
import uuid

from bpy_extras.io_utils import ImportHelper

from . import auto_cutsmart_profiler as profiler
from . import custom_render_panel as render_panel
from . import report_system

# --------------------------------------------------------------------------------------------------------------------------------------
# --- Constants and Global Variables --- #
# --------------------------------------------------------------------------------------------------------------------------------------

# A global flag to track if a critical error has occurred.
critical_error_occurred = False

# Global ID for tracking unique addon instances for anonymous reporting.
REPORT_ID = str(uuid.uuid4())

# A dictionary to store the start time of each processing stage.
stage_start_times = {}

# A flag to prevent multiple report dialogs from being invoked in case of cascading errors.
_report_invoked = False

description_map = {
	'RATIO': "Simplify F-Curves by keeping only a chosen fraction of keyframes",
	'ERROR': "Simplify F-Curves by removing points within an error tolerance"
}

log_storage = [] # Stores log messages for reprinting

# Data paths for object-level properties considered for jump cut detection
OBJECT_ANIMATION_DATA_PATHS = ["location", "rotation_euler", "rotation_quaternion", "scale"]

# Data paths for camera data properties considered for jump cut detection
CAMERA_DATA_ANIMATION_PATHS = [
	"lens", "shift_x", "shift_y", "sensor_width", "sensor_height",
	"ortho_scale", "fisheye_fov", "fisheye_lens",
	"fisheye_polynomial_k0", "fisheye_polynomial_k1", "fisheye_polynomial_k2",
	"fisheye_polynomial_k3", "fisheye_polynomial_k4",
	"latitude_min", "latitude_max", "longitude_min", "longitude_max"]

# Unicode characters for the progress bar
BLACK_SQUARE = chr(0x25A0)
WHITE_SQUARE = chr(0x25A1)

# Icons for progress stages in the UI
PROCESS_STAGES_ICONS = [
	'KEYTYPE_JITTER_VEC', 'TRASH', 'DUPLICATE', 'MEMORY', 'SHADERFX',
	'SEQ_SPLITVIEW', 'FCURVE', 'BOOKMARKS', 'KEY_HLT', 'BRUSHES_ALL']

# This list defines the order and names of the stages. The weights are calculated dynamically.
DEFAULT_PROCESS_STAGES = [
	("Initialization", 0),
	("Clearing existing data", 0),
	("Duplicating cameras", 0),
	("Analyzing camera animation for jumps", 0),
	("Baking Keyframes", 0),
	("Splitting and assigning animation chunks", 0),
	("Modifying F-curves (Constant/Padding)", 0),
	("Adding timeline markers", 0),
	("Setting Scene Motion Blur Keyframes", 0),
	("Cleanup and restore", 0)
]


# --------------------------------------------------------------------------------------------------------------------------------------
# --- Helper Functions --- #
# --------------------------------------------------------------------------------------------------------------------------------------

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# == Debugging/Logging Func ==
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# -------------------------
# Main Logging Functions
# -------------------------

def VerboseActive(level, OverRide: bool = False) -> bool:
	"""
	Check if verbose logging/level is enabled in addon preferences.
	Levels:
		1 → High Verbose (most detailed)
		2 → Light Verbose (less detailed)
		3 → Jump Debug Output
		10 → Critical (for errors that stop execution)
	"""
	if OverRide:
		return True

	prefs = bpy.context.preferences.addons[__name__].preferences

	# Map levels to preference attributes
	level_map = {
		1: prefs.high_Verbose,
		2: prefs.light_Verbose,
		3: prefs.jump_debug_output,
		10: True # Always and only Major Errors
	}

	if isinstance(level, list):
		return any(level_map.get(lvl, False) for lvl in level)
	else:
		return level_map.get(level, False)

def trigger_report_op():
	"""Wrapper function to call the report operator and satisfy timer requirements."""
	bpy.ops.auto_cutsmart.confirm_report('INVOKE_DEFAULT')
	return None

def log_msg(level, msg):
	"""
	Log a message to console (if verbose level enabled) and store it.
	Triggers the error reporting system on critical errors (level 10).
	"""
	global critical_error_occurred
	global _report_invoked
	prefs = bpy.context.preferences.addons[__name__].preferences

	if level >= 10:
		critical_error_occurred = True

	msg = (str(msg))

	if VerboseActive(level):
		print(msg)
	log_storage.append((level, msg)) # Store the log with its level for reprinting

	# If a critical error occurs and a report hasn't been invoked yet, trigger the confirmation dialog.
	if critical_error_occurred and not _report_invoked:
		_report_invoked = True
		print("\n---==========~==========---~ [!!! 'READ ME' !!!] ~---==========~==========---")
		print("---==========~==========---~ [!!! 'READ ME' !!!] ~---==========~==========---")
		print("---==========~==========---~ [!!! 'READ ME' !!!] ~---==========~==========---\n")
		print("We’re sorry to hear that you’ve encountered an error. To help us fix it, could you please report this bug on our Feedback webpage? You can easily access the webpage by opening the Add-ons Preferences window and clicking the ‘Report a Bug’ button. Your report would be greatly appreciated, and it’ll help us improve the addon. Thanks for your support!")
		print("\n---==========~==========---~ [END OF 'READ ME'] ~---==========~==========---")
		print("---==========~==========---~ [END OF 'READ ME'] ~---==========~==========---")
		print("---==========~==========---~ [END OF 'READ ME'] ~---==========~==========---\n")
		if not prefs.MajorError_Logging:
			bpy.ops.auto_cutsmart.self_report_error()
		else:
			try:
				# Use a timer to delay the operator call slightly. This avoids context issues.
				bpy.app.timers.register(trigger_report_op)
			except Exception as e:
				# If the report operator fails to invoke, log a new error but do not trigger another report loop.
				print(f"FATAL: Failed to invoke confirm_report operator: {e}")

# -------------------------
# Error Report Script Calls
# -------------------------

def get_full_log():
	"""Returns the entire log_storage list for the report system."""
	return log_storage

def get_bl_info():
	"""Returns the addon's bl_info dictionary."""
	return bl_info

def get_report_id():
	"""Returns the unique report ID for the current session."""
	return REPORT_ID

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# == Stage Weight Caculation/Learning Func ==
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

def _buffer_modifier(stage_buffer: float, alpha: float = 0.9, zero_factor: float = 0.15) -> float:
	"""
	Deterministic shape to enforce: 0→fastest (scaled by zero_factor), 1→slowest (1.0), >1→decreasing.
	alpha controls how fast it decays after 1.
	"""
	try:
		try:
			b = float(stage_buffer)
		except (ValueError, TypeError):
			b = 1.0

		if b <= 0.0:
			return zero_factor	# Fastest case, small multiplier
		if abs(b - 1.0) < 1e-9:
			return 1.0	# Slowest case, peak of the curve

		# For b > 1, apply decay
		return 1.0 / (1.0 + alpha * (b - 1.0))
	except Exception:
		log_msg(10, f"An error occurred during _buffer_modifier: {traceback.format_exc()}")

def _poly_features_local(vec, degree: int = 2):
	"""Local polynomial feature expansion. Keep in sync with profiler._poly_features"""
	try:
		feats = [1.0] + list(vec)

		if degree >= 2:
			feats.extend(v*v for v in vec)
			feats.extend(vec[i]*vec[j] for i in range(len(vec)) for j in range(i+1, len(vec)))

		if degree >= 3:
			feats.extend(v*v*v for v in vec)

		return feats
	except Exception:
		log_msg(10, "An error occurred during _poly_features_local: {}".format(traceback.format_exc()))

def _predict_with_coeffs(coeffs: list[float], features: list[float]) -> float:
	try:
		length = min(len(coeffs), len(features))
		return sum(coeffs[i]*features[i] for i in range(length))
	except Exception:
		log_msg(10, "An error occurred during _predict_with_coeffs: {}".format(traceback.format_exc()))

def calculate_dynamic_weights(context, camera_obj, coefficients, redraw_time, ImportKeyframes = None, print_info=False, poly_degree: int = 2):
	"""
	Compute per-stage weights using learned polynomial regression and stage buffer rules.
	1. Assemble raw feature vectors per-stage (scene metrics + specialized buffer features + redraw_time).
	2. Expand features with polynomial terms locally (must match trainer order).
	3. Predict a raw cost per stage via dot(coeffs, features_poly).
	4. Multiply by deterministic buffer modifier enforcing: 0→fast, 1→slowest, >1→faster.
	5. Normalize to 0..100.
	"""
	try:
		scene = context.scene
		preferences = bpy.context.preferences.addons[__name__].preferences

		# --- Gather scene metric data ---
		start_frame, end_frame = scene.frame_start, scene.frame_end
		num_fcurves_total = sum(len(obj.animation_data.action.fcurves) if obj.animation_data and obj.animation_data.action else 0
								for obj in [camera_obj, camera_obj.data])
		num_markers_to_clear = len(scene.timeline_markers)

		if ImportKeyframes is None:
			keyframes = get_all_camera_keyframes(camera_obj, (start_frame, end_frame)) or []
			num_keyframes = len(keyframes)
		else:
			num_keyframes = len(ImportKeyframes)

		num_decimation_blocks = len(context.object.data.decimate_blocks) if getattr(preferences, 'Keep_Bake_Frames', True) else 0
		total_frames_to_bake = (end_frame - start_frame + 1) * max(1, num_fcurves_total)
		num_children = len(list(camera_obj.children_recursive)) if getattr(preferences, 'Copy_Camera_Children', False) else 0

		# --- Stage Buffers ---
		sb = {i: float(getattr(preferences, f'stage{i}_buffer', 1.0)) for i in range(1, 9)}

		# --- Build per-stage raw feature vectors (BEFORE poly expansion) ---
		stage_features = {"stage_0": [redraw_time], "stage_9": [redraw_time]}

		for i in range(1, 9):
			skey = f"stage_{i}"
			buffer_val = sb.get(i, 1.0)

			# --- NEW: Improved Buffer Features ---
			is_zero_buffer = 1.0 if buffer_val == 0.0 else 0.0
			# Feature is 0 at buffer=1, grows quadratically away from it. Models the "V" shape.
			dist_from_one_sq = (buffer_val - 1.0)**2
			# Feature to model the decay specifically for buffers > 1.
			decay_feature = max(0.0, buffer_val - 1.0)

			base_metrics = []
			if i == 1: base_metrics = [num_markers_to_clear]
			elif i == 2: base_metrics = [num_fcurves_total, num_children]
			elif i == 3: base_metrics = [num_keyframes]
			elif i == 4: base_metrics = [total_frames_to_bake, num_decimation_blocks]
			elif i == 5: base_metrics = [num_fcurves_total]
			elif i in [6, 7, 8]: base_metrics = [num_keyframes]

			stage_features[skey] = base_metrics + [is_zero_buffer, dist_from_one_sq, decay_feature, redraw_time]


		# Record features for profiler (if enabled)
		if preferences.keep_learning:
			try:
				for k, vec in stage_features.items():
					profiler.record_stage_features(k, vec)
			except Exception:
				pass

		# Use provided coefficients or fallback to defaults
		learned = coefficients or profiler.get_default_coefficients()


		# --- Predict Raw Weights ---
		raw_weights = [0.0] * len(DEFAULT_PROCESS_STAGES)  # Ensure list has 10 elements (for all stages)

		# Custom index order [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
		index_order = list(range(1, 10)) + [0]

		ratio = 0.01 # Initialize ratio

		for i in index_order:  # Use the custom index order here
			if i == 8 and not getattr(preferences, 'set_motionblur_keyframes', False):
				continue

			skey = f"stage_{i}"
			coeffs = learned.get(skey, [0.001])

			if skey in ("stage_0", "stage_9"):
				# Use learned constant coefficients, bypassing scene metrics entirely
				ratio = coeffs[0] if coeffs else 0.01
				midsum = sum(raw_weights[j] for j in range(1, 9))  # We can safely do this now
				val = ((ratio * midsum * 0.085)) # * (1 if preferences.keep_learning else 0.01)
			else:
				# For other stages, use feature expansion and buffer modifiers
				vec = stage_features[skey]
				feats = _poly_features_local(vec, degree=poly_degree)
				val = _predict_with_coeffs(coeffs, feats)
				buf_val = sb.get(i, 1.0)
				val *= _buffer_modifier(buf_val)

			# Keep non-negative
			raw_weights[i] = max(0.0, float(val))

		# --- Build Dynamic Stages List ---
		dynamic_stages = [(label, raw_weights[i]) for i, (label, _) in enumerate(DEFAULT_PROCESS_STAGES) if i != 8 or getattr(preferences, 'set_motionblur_keyframes', False)]

		# Normalize to 0-100
		total = sum(w for _, w in dynamic_stages)
		if total <= 0.0:
			eq = 100.0 / max(1, len(dynamic_stages))
			return [(label, eq) for label, _ in dynamic_stages]

		out = [(label, (w / total) * 100.0) for label, w in dynamic_stages]

		# Optional verbose logging
		if VerboseActive(1):
			log_msg(1, f"\n--- Dynamic Weight Inputs ---\n"
						f"redraw_time={redraw_time:.4f}\n"
						f"num_markers_to_clear={num_markers_to_clear}\n"
						f"num_fcurves_total={num_fcurves_total}\n"
						f"num_keyframes={num_keyframes}\n"
						f"total_frames_to_bake={total_frames_to_bake}\n"
						f"num_decimation_blocks={num_decimation_blocks}\n"
						f"num_children={num_children}\n"
						f"ratio={ratio}\n")

		return out
	except Exception:
		log_msg(10, "An error occurred during calculate_dynamic_weights: {}".format(traceback.format_exc()))


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# == Camera Split Op. Func ==
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

def ensure_graph_editor_context():
	"""
	Finds or creates a Graph Editor context override.
	Returns a dictionary with the context override and the original area type if it was temporarily changed.
	"""
	try:
		# Search all windows/screens for an existing Graph Editor
		for window in bpy.context.window_manager.windows:
			for area in window.screen.areas:
				if area.type == "GRAPH_EDITOR":
					region = next((r for r in area.regions if r.type == 'WINDOW'), None)
					if region:
						try:
							# Try using temp_override with the found Graph Editor context
							with bpy.context.temp_override(window=window, screen=window.screen, area=area, region=region):
								return {"window": window, "screen": window.screen, "area": area, "region": region}, None
						except Exception as e:
							VerboseActive(1) and log_msg(1, f"Error using temp_override for existing Graph Editor: {e} | Skipping...")
							continue  # Skip and check the next area/screen

		# No Graph Editor found/Usable Graph Editor Context → temporarily convert an existing area
		VerboseActive(1) and log_msg(1, "No Valid Graph Editor found, temporarily converting an existing area")
		for window in bpy.context.window_manager.windows:
			screen = window.screen
			if screen.areas:
				area = screen.areas[0]
				original_type = area.type  # Save the original type of the area
				area.type = "GRAPH_EDITOR"	# Convert the area to Graph Editor
				region = next((r for r in area.regions if r.type == 'WINDOW'), None)
				if region:
					return {"window": window, "screen": screen, "area": area, "region": region}, original_type

		# If no valid context or conversion worked, return None
		return None, None
	except Exception:
		log_msg(10, "An error occurred during ensure_graph_editor_context: {}".format(traceback.format_exc()))

def get_all_fcurve_data_paths(obj_or_data):
	"""
	Returns a set of all data paths from F-curves in the given object's or data's action.
	"""
	try:
		data_paths = set()
		if obj_or_data.animation_data and obj_or_data.animation_data.action:
			for fcurve in obj_or_data.animation_data.action.fcurves:
				data_paths.add(fcurve.data_path)
		return data_paths
	except Exception:
		log_msg(10, "An error occurred during get_all_fcurve_data_paths: {}".format(traceback.format_exc()))

def has_constant_interpolation_at_frame(fcurve, frame, epsilon=0.001):
	"""
	Checks if any keyframe point on the given FCurve at or very near the specified
	frame has 'CONSTANT' interpolation.
	"""
	try:
		for kp in fcurve.keyframe_points:
			if abs(kp.co.x - frame) < epsilon:
				if kp.interpolation == 'CONSTANT':
					return True
		return False
	except Exception:
		log_msg(10, "An error occurred during has_constant_interpolation_at_frame: {}".format(traceback.format_exc()))

def get_evaluated_property_value(obj_or_data, data_path, frame):
	"""
	Evaluates the value of a property at a specific frame using its F-curves.
	Handles single-value, vector, and quaternion properties.
	Returns None if the property is not animated or F-curves are incomplete.
	"""
	try:
		if not obj_or_data or not obj_or_data.animation_data or not obj_or_data.animation_data.action:
			# If no animation data or action, attempt to return the current property value as a fallback.
			try:
				return getattr(obj_or_data, data_path)
			except AttributeError:
				return None

		action = obj_or_data.animation_data.action
		fcurves_for_path = [fc for fc in action.fcurves if fc.data_path == data_path or fc.data_path.startswith(data_path + "[")]

		if not fcurves_for_path:
			# If no F-curves found, return the current property value as a fallback.
			try:
				return getattr(obj_or_data, data_path)
			except AttributeError:
				return None

		# Sort fcurves by array_index to ensure correct order for vectors/quaternions
		fcurves_for_path.sort(key=lambda fc: fc.array_index)

		# Handle single-value properties
		if len(fcurves_for_path) == 1 and fcurves_for_path[0].array_index == -1:
			return fcurves_for_path[0].evaluate(frame)

		# Handle vector/euler properties (e.g., location, rotation_euler, scale)
		if data_path in ["location", "scale", "rotation_euler"]:
			if len(fcurves_for_path) >= 3:
				values = [fc.evaluate(frame) for fc in fcurves_for_path[:3]] # Take first 3 components
				if data_path in ["location", "scale"]:
					return mathutils.Vector(values)
				elif data_path == "rotation_euler":
					if hasattr(obj_or_data, 'rotation_mode'):
						return mathutils.Euler(values, obj_or_data.rotation_mode)
					else:
						return mathutils.Euler(values) # Fallback without rotation_mode
			return None # Incomplete F-curves for vector/euler

		# Handle quaternion properties (e.g., rotation_quaternion)
		if data_path == "rotation_quaternion":
			if len(fcurves_for_path) >= 4:
				values = [fc.evaluate(frame) for fc in fcurves_for_path[:4]]
				return mathutils.Quaternion((values[0], values[1], values[2], values[3]))
			return None # Incomplete F-curves for quaternion

		# Fallback for other single-value properties that might be animated
		return fcurves_for_path[0].evaluate(frame) if fcurves_for_path else None
	except Exception:
		log_msg(10, "An error occurred during get_evaluated_property_value: {}".format(traceback.format_exc()))

def _get_motion_blur_int_values(scene):
	"""
	Dynamically fetches the integer values for the motion blur position enum
	('CENTER', 'START', 'END') based on the current Blender version.
	"""
	values = {}

	#Detect and use right motion blur path depending on Blender Version:
	if bpy.app.version >= (4, 2, 0):
		# Blender 4.0+
		owner = scene.render
		prop_path = "motion_blur_position"
		full_data_path = "render.motion_blur_position"
	else:
		# Blender < 4.0
		owner = scene.cycles
		prop_path = "motion_blur_position"
		full_data_path = "cycles.motion_blur_position"

	try:
		prop = owner.bl_rna.properties[prop_path]
		for item in prop.enum_items:
			if item.identifier in ['CENTER', 'START', 'END']:
				values[item.identifier] = item.value

	except Exception as e:
		 log_msg(1, f"Warning: Failed dynamic lookup for motion blur values: {e}. Falling back to historical defaults.")

	# fall back to defaults
	if not all(k in values for k in ['CENTER', 'START', 'END']):
		log_msg(1, "Warning: Dynamic lookup did not find all motion blur values. Falling back to historical defaults.")

		values = {
			'CENTER': 0,
			'START': 1,
			'END': 2}

	return values, full_data_path

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# == Other Func ==
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

def has_animation(obj):
	"""
	Checks if an object or its data has animation data.
	"""
	return bool((obj and obj.animation_data and obj.animation_data.action) or
				(obj.data.animation_data and obj.data.animation_data.action))

def get_all_camera_keyframes(camera_obj, frame_range=None):
	"""
	Gathers all unique keyframe frame numbers for the camera object and its data.
	If frame_range is not provided, automatically determines the range from both
	the object's and its data's animation, then filter.
	"""
	try:
		keyframes = set()

		BothAnimationPaths = [camera_obj, camera_obj.data]

		# Determine frame range if not provided
		if frame_range:
			start_frame, end_frame = frame_range # Range provided

		else:	# Range not provided, find frame range on Obj and Obj.data animations instead
			start_frame, end_frame = float('inf'), float('-inf')
			for obj in BothAnimationPaths:
				if obj.animation_data and obj.animation_data.action:
					action_range = obj.animation_data.action.frame_range
					start_frame = min(start_frame, action_range[0])
					end_frame = max(end_frame, action_range[1])

			if start_frame == float('inf') or end_frame == float('-inf'): # If no animation data found, return None
				return None

		# Collect keyframes from object and camera data animation
		for obj in BothAnimationPaths:
			if obj.animation_data and obj.animation_data.action:
				for fcurve in obj.animation_data.action.fcurves:
					for kp in fcurve.keyframe_points:
						if start_frame <= kp.co.x <= end_frame:
							keyframes.add(kp.co.x)

		return sorted(keyframes)
	except Exception:
		log_msg(10, "An error occurred during get_all_camera_keyframes: {}".format(traceback.format_exc()))


# --------------------------------------------------------------------------------------------------------------------------------------
# --- Custom Properties for Scene Status and Dynamic Weights --- #
# --------------------------------------------------------------------------------------------------------------------------------------

class CameraSplitSceneStatus(bpy.types.PropertyGroup):
	"""Custom properties for Camera Jump Split addon's scene-level status and progress"""
	overall_progress: bpy.props.FloatProperty(
		name="Overall Progress",
		min=0.0, max=100.0, default=0.0,
		description="Overall progress of the camera splitting operation"
	)
	current_step_text: bpy.props.StringProperty(
		name="Current Step",
		default="",
		description="Description of the current step being processed"
	)
	current_sub_progress_text: bpy.props.StringProperty(
		name="Sub Progress",
		default="",
		description="Detailed progress within the current step"
	)
	jump_frames_detected_count: bpy.props.IntProperty(
		name="Jump Frames Detected",
		default=0,
		description="Number of jump frames detected during the analysis"
	)
	total_markers_added: bpy.props.IntProperty(
		name="Total Markers Added",
		default=0,
		description="Total number of camera markers added"
	)
	is_running: bpy.props.BoolProperty(
		name="Is Running",
		default=False,
		description="True if the camera split operation is currently running"
	)
	show_results: bpy.props.BoolProperty(
		name="Show Results",
		default=False,
		description="True if the final operation results should be displayed"
	)
	progress_stage_INDEX: bpy.props.IntProperty(
		name="Current Stage Index",
		default=0,
		description="Index of Current Stage"
	)

class CameraSplitStageWeight(bpy.types.PropertyGroup):
	"""Property group to store individual stage weights for dynamic progress calculation."""
	stage_index: bpy.props.IntProperty()
	weight: bpy.props.FloatProperty()


# --------------------------------------------------------------------------------------------------------------------------------------
# --- Custom Properties for Auto CutSmart Settings and Decimate Block Properties --- #
# --------------------------------------------------------------------------------------------------------------------------------------

class CameraSplitSettings(bpy.types.PropertyGroup):
	"""Custom properties for Camera Jump Split addon settings"""
	location_threshold: bpy.props.FloatProperty(
		name="Location",
		default=2.0,
		min=0.001,
		subtype='DISTANCE',
		unit='LENGTH',
		description="If the camera moves more than this distance between keyframes, count it as a jump cut",
		precision=3,
	)
	rotation_threshold: bpy.props.FloatProperty(
		name="Rotation",
		default=math.radians(10.0),
		min=math.radians(0.001),
		subtype='ANGLE',
		unit='ROTATION',
		description="If the camera rotates more than this angle between keyframes, count it as a jump cut",
		precision=3,
	)
	lens_threshold: bpy.props.FloatProperty(
		name="Lens",
		default=10.0,
		min=0.001,
		subtype='DISTANCE_CAMERA',
		unit='CAMERA',
		description="If the camera’s focal length changes more than this amount between keyframes, count it as a jump cut",
		precision=3,
	)

	custom_prefix: bpy.props.StringProperty(
		name="Custom Prefix",
		description="Enter a name prefix for duplicated cameras (e.g., 'Shot_'). Leave blank to use the original camera name",
		default="",
	)

	suffix_type: bpy.props.EnumProperty(
		name="Suffix Type",
		description="Choose if duplicates use numbers or letters for suffixes",
		items=[
			('NUMBER', "Number", "Use numbers (e.g., Camera.1, Camera.2)"),
			('LETTER', "Letter", "Use letters (e.g., Camera.A, Camera.B)")
		],
		default='NUMBER',
	)
	#Other, less needed thresholds
	shift_x_threshold: bpy.props.FloatProperty(
		name="Shift X",
		default=0.01,
		min=0.001,
		subtype='UNSIGNED',
		description="If the horizontal shift changes more than this amount, count it as a jump cut",
		precision=3,
	)
	shift_y_threshold: bpy.props.FloatProperty(
		name="Shift Y",
		default=0.01,
		min=0.001,
		subtype='UNSIGNED',
		description="If the vertical shift changes more than this amount, count it as a jump cut",
		precision=3,
	)
	sensor_width_threshold: bpy.props.FloatProperty(
		name="Sensor Width",
		default=0.1,
		min=0.001,
		subtype='DISTANCE_CAMERA',
		unit='CAMERA',
		description="Minimum sensor size change to count as a jump cut",
		precision=3,
	)
	sensor_height_threshold: bpy.props.FloatProperty(
		name="Sensor Height",
		default=0.1,
		min=0.001,
		subtype='DISTANCE_CAMERA',
		unit='CAMERA',
		description="Minimum sensor size change to count as a jump cut",
		precision=3,
	)
	ortho_scale_threshold: bpy.props.FloatProperty(
		name="Orthographic Scale",
		default=1.0,
		min=0.001,
		description="Minimum orthographic scale change to count as a jump cut",
		precision=3,
	)
	fisheye_fov_threshold: bpy.props.FloatProperty(
		name="Fisheye FOV",
		default=math.radians(5),
		max = math.radians(1800),
		min=math.radians(0.001),
		subtype='ANGLE',
		unit='ROTATION',
		description="Minimum fisheye field of view change to count as a jump cut",
		precision=3,
	)
	fisheye_lens_threshold: bpy.props.FloatProperty(
		name="Fisheye Lens",
		default=1.0,
		min=0.01,
		max = 100,
		subtype='DISTANCE_CAMERA',
		unit='CAMERA',
		description="Minimum fisheye lens change to count as a jump cut",
		precision=2,
	)
	fisheye_polynomial_k0_threshold: bpy.props.FloatProperty(
		name="K0",
		default=0.01,
		min=math.radians(0.001),
		precision=6,
		subtype='ANGLE',
		unit='ROTATION',
		description="Minimum polynomial distortion change to count as a jump cut",
		)

	fisheye_polynomial_k1_threshold: bpy.props.FloatProperty(
		name="K1",
		default=0.01,
		min=math.radians(0.001),
		precision=6,
		subtype='ANGLE',
		unit='ROTATION',
		description="Minimum polynomial distortion change to count as a jump cut",
		)

	fisheye_polynomial_k2_threshold: bpy.props.FloatProperty(
		name="K2",
		default=0.01,
		min=math.radians(0.001),
		precision=6,
		subtype='ANGLE',
		unit='ROTATION',
		description="Minimum polynomial distortion change to count as a jump cut",
		)

	fisheye_polynomial_k3_threshold: bpy.props.FloatProperty(
		name="K3",
		default=0.01,
		min=math.radians(0.001),
		precision=6,
		subtype='ANGLE',
		unit='ROTATION',
		description="Minimum polynomial distortion change to count as a jump cut",
		)

	fisheye_polynomial_k4_threshold: bpy.props.FloatProperty(
		name="K4",
		default=0.01,
		min=math.radians(0.001),
		precision=6,
		subtype='ANGLE',
		unit='ROTATION',
		description="Minimum polynomial distortion change to count as a jump cut",
		)


	latitude_min_threshold: bpy.props.FloatProperty(
		name="Latitude Min",
		default=math.radians(5),
		min=math.radians(0.001),
		max = math.radians(180),
		subtype='ANGLE',
		unit='ROTATION',
		description="Minimum vertical panorama limit change to count as a jump cut",
		precision=1)

	latitude_max_threshold: bpy.props.FloatProperty(
		name="Latitude Max",
		default=math.radians(5),
		min=math.radians(0.001),
		max = math.radians(180),
		subtype='ANGLE',
		unit='ROTATION',
		description="Minimum vertical panorama limit change to count as a jump cut",
		precision=1)

	longitude_min_threshold: bpy.props.FloatProperty(
		name="Longitude Min",
		default=math.radians(5.0),
		min=math.radians(0.001),
		max = math.radians(360),
		subtype='ANGLE',
		unit='ROTATION',
		description="Minimum horizontal panorama limit change to count as a jump cut",
		precision=1)

	longitude_max_threshold: bpy.props.FloatProperty(
		name="Longitude Max",
		default=math.radians(5),
		min=math.radians(0.001),
		max = math.radians(360),
		subtype='ANGLE',
		unit='ROTATION',
		description="Minimum horizontal panorama limit change to count as a jump cut",
		precision=1)

class DecimateBlock(bpy.types.PropertyGroup):
	"""
	PropertyGroup to store the configuration for a single decimation step.
	It holds the type of decimation (Ratio or Error Margin) and its corresponding value.
	"""
	decimate_type: bpy.props.EnumProperty(
		name="Decimate Type",
		description="Choose decimation method for keyframes",
		items=[
			('RATIO', "By Ratio", "Simplify F-Curves by keeping only a chosen fraction of keyframes"),
			('ERROR', "By Error Margin", "Simplify F-Curves by removing points that stay within a set error tolerance"),
		]
	)
	factor: bpy.props.FloatProperty(
		name="Remove",
		description="Fraction of keyframes to keep when using ratio decimation (0 removes all, 1 keeps all)",
		min=0.0,
		max=1.0,
		default=0.5,
		subtype='FACTOR'
	)
	error_margin: bpy.props.FloatProperty(
		name="Max Error Margin",
		description="Maximum deviation allowed from the original F-Curve when simplifying keyframes",
		min=0.0,
		default=0.000,
		step=1.0,
		precision=3
	)


# --------------------------------------------------------------------------------------------------------------------------------------
# --- UI / Function Operators --- #
# --------------------------------------------------------------------------------------------------------------------------------------

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# == M A I N   C A M E R A	 S P L I T T I N G	 O p e r a t o r  ==
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class AUTO_CUTSMART_OT_operator(bpy.types.Operator):
	"""Operator to duplicate camera, split animation on jumps, and creates markers."""
	bl_label = "Split Camera Animation on Jumps"
	bl_idname = "camera.split_animation_on_jumps"
	bl_description = "Duplicates camera, splits animation on detected jumps, and creates alternating camera markers"
	bl_options = {'REGISTER', 'UNDO'}

	# Class-level variables to maintain state across modal calls
	_timer = None
	_original_cam_name = None
	_original_cam = None
	_original_cam_data = None
	_progress_stage = 0
	_progress_sub_index = 0
	_segments = []
	_target_cams = [] # List to hold the two duplicated cameras
	_total_keyframes_to_check = 0
	_markers_to_remove = []
	_total_markers = 0
	_temp_cam = None # Temporary camera for baking
	_all_object_animated_paths = set() # Stores all animated paths for the object
	_all_camera_data_animated_paths = set() # Stores all animated paths for the camera data
	_temp_obj_action_name = None # To store the name of the copied object action for temp_cam
	_temp_data_action_name = None # To store the name of the copied camera data action for temp_cam
	_markers_added_by_script = [] # List to store names of markers added by this script run
	_total_fcurves_to_bake = 0 # For baking progress
	_static_thresholds = {}
	_animated_threshold_fcurves = {}
	_children_to_process_queue = []
	_duplication_map = {}
	_total_children_count = 0
	_children_processed_count = 0
	_cached_region = None #cache the region for redraw
	_generated_objects = []

	_waste_looper = 0

	# Variables for the learning system
	_learning_data = {}
	_coefficients = {}
	_raw_predictive_metrics = {}
	_redraw_time = 0.0

	# This will hold the actual weights used for the current run, either default or dynamic
	PROCESS_STAGES = []


	# Property to handle operator actions (e.g., 'CANCEL')
	action: bpy.props.StringProperty(default="")

	@classmethod
	def poll(cls, context):
		obj = context.object
		if has_animation(obj):
			return True
		else:
			cls.poll_message_set("Active Camera has no animation!")
			return False

	# --- Helper Functions --- #
	def get_threshold_value(self, field_name, frame):
		try:
			if field_name in self._animated_threshold_fcurves:
				return self._animated_threshold_fcurves[field_name].evaluate(frame)
			return self._static_thresholds.get(field_name, 0)
		except Exception:
			log_msg(10, "An error occurred during get_threshold_value: {}".format(traceback.format_exc()))

	def load_dynamic_weights(self, context):
		"""
		Loads dynamic weights from scene properties. If none are stored,
		it calls the `calculate_dynamic_weights` function to generate a set.
		"""
		try:
			self.PROCESS_STAGES = calculate_dynamic_weights(context, context.object, self._coefficients, self._redraw_time, self._keyframes_to_check, True)
			log_msg(1, f"Using calculated dynamic weights: {self.PROCESS_STAGES}")
		except Exception as e:
				log_msg(10, f"An error occurred during load_dynamic_weights: {traceback.format_exc()}");
				return self.cancel(context)

	def op_call(self, op, ctx, **kwargs):
		"""
		Calls a Blender operator with a given context in a cross-version safe way.
		If ctx is None, uses the current context.
		"""
		try:
			if ctx is None:
				return op(**kwargs)
			elif isinstance(ctx, dict):
				# Older Blender: pass as first positional argument
				return op(ctx, **kwargs)
			else:
				return op(**kwargs)
		except Exception:
			log_msg(10, "An error occurred during op_call: {}".format(traceback.format_exc()))

	def run_graph_editor_decimation(self, ctx=None):
		try:
			if ctx is None:
				ctx = bpy.context

			space_data = ctx.space_data
			space_data.dopesheet.show_scenes = False
			space_data.dopesheet.show_nodes = False
			space_data.dopesheet.show_worlds = False
			space_data.dopesheet.show_linestyles = False
			space_data.dopesheet.show_modifiers = False
			space_data.dopesheet.show_only_selected = True
			space_data.dopesheet.show_cameras = True
			space_data.dopesheet.show_transforms = True

			self.op_call(bpy.ops.object.select_all, ctx, action='DESELECT')
			self._temp_cam.select_set(True)

			self.op_call(bpy.ops.graph.reveal, ctx)
			self.op_call(bpy.ops.graph.select_all, ctx, action='SELECT')

			self.op_call(bpy.ops.graph.handle_type, ctx, type='VECTOR')
			self.op_call(bpy.ops.graph.handle_type, ctx, type='FREE')

			# Decimation blocks
			for i, block in enumerate(ctx.object.data.decimate_blocks):
				if block.decimate_type == 'RATIO':
					self.op_call(bpy.ops.graph.decimate, ctx, mode='RATIO', factor=block.factor)
					VerboseActive(1) and log_msg(1, f"Decimation {i+1}: Ratio {block.factor}")
				elif block.decimate_type == 'ERROR':
					self.op_call(bpy.ops.graph.decimate, ctx, mode='ERROR', remove_error_margin=block.error_margin)
					VerboseActive(1) and log_msg(1, f"Decimation {i+1}: Error margin {block.error_margin}")
			self.op_call(bpy.ops.graph.select_all, ctx, action='DESELECT')
		except Exception:
			log_msg(10, "An error occurred during run_graph_editor_decimation: {}".format(traceback.format_exc()))

	def duplicate_and_parent_hierarchy(self, original_parent, new_parent, collection):
			"""
			Recursively performs a linked duplicate of the original parent's children
			and parents them to the new parent, maintaining the hierarchy.
			A linked duplicate means the new object shares the same object data (e.g., mesh).
			"""
			try:
				# This map tracks the original child object to its new duplicate
				duplication_map = {}

				# Use a list as a queue to process all descendants
				children_to_process = list(original_parent.children)

				while children_to_process:
					original_child = children_to_process.pop(0)

					# Create a linked duplicate (object.copy() creates a new object with shared object-data)
					new_child = original_child.copy()
					collection.objects.link(new_child)
					duplication_map[original_child] = new_child

					# Add this object's own children to the queue to ensure the entire hierarchy is processed
					children_to_process.extend(original_child.children)

				# Parent the newly created duplicates to maintain the hierarchy structure
				for original_obj, new_obj in duplication_map.items():
					original_obj_parent = original_obj.parent

					if original_obj_parent == original_parent:
						# If the original parent is the camera, parent the new object to the new camera
						new_obj.parent = new_parent
					elif original_obj_parent in duplication_map:
						# If the original parent is another object in the hierarchy, find its duplicate and parent to that
						new_obj.parent = duplication_map[original_obj_parent]

					# Ensure the transform relative to the new parent remains correct
					new_obj.matrix_parent_inverse = original_obj.matrix_parent_inverse.copy()
			except Exception:
				log_msg(10, "An error occurred during duplicate_and_parent_hierarchy: {}".format(traceback.format_exc()))

	def redrawUI(self):
		"""Update UI for redraw."""
		# If the region is cached, use it directly
		try:
			if self._cached_region:
				self._cached_region.tag_redraw()
				return

			# If the region is not cached, find and store it
			for area in bpy.context.screen.areas:
				if area.type == 'PROPERTIES':  # Assuming the panel is in the Properties editor
					for region in area.regions:
						if region.type == 'WINDOW':	 # Target the main window region
							# Store the region for future use
							self._cached_region = region
							self._cached_region.tag_redraw()
							return
		except Exception:
			log_msg(10, "An error occurred during redrawUI: {}".format(traceback.format_exc()))

	def cleanup_generated_objects(self):
		"""
		Robustly removes all objects + children and their data that were generated.
		"""
		for obj in list(self._generated_objects):
			try:
				if obj:
					self.remove_hierarchy(obj)
			except Exception as e:
				log_msg(10, f"An error occurred during cleanup: {traceback.format_exc()}");
				continue

		self._generated_objects = [] # Clear the list

	def remove_hierarchy(self, obj_to_remove):
		"""
		Recursively and robustly removes an object and all of its descendants,
		including their animation data and main data blocks.
		"""
		try:
			if not obj_to_remove or obj_to_remove.name not in bpy.data.objects:
				VerboseActive(2) and log_msg(2, f"Skipped Removal of {obj_to_remove.name}")
				return

			# Use a queue to handle all children and descendants
			queue = deque([obj_to_remove])

			while queue:
				current_obj = queue.popleft()

				# Add children to the queue
				for child in current_obj.children:
					queue.append(child)

				# Get associated data blocks
				obj_action = current_obj.animation_data.action if current_obj.animation_data and current_obj.animation_data.action else None
				data_action = current_obj.data.animation_data.action if current_obj.data and current_obj.data.animation_data and current_obj.data.animation_data.action else None
				obj_data = current_obj.data

				VerboseActive(2) and log_msg(2, f"Attempting to remove: '{current_obj.name}'")

				# Remove the object from the scene
				if current_obj.name in bpy.data.objects:
					try:
						bpy.data.objects.remove(current_obj, do_unlink=True)
						VerboseActive(2) and log_msg(2, "Object Removed")
					except Exception as e:
						VerboseActive(2) and log_msg(10, f"An error occurred when trying to remove object:\n{traceback.format_exc()}")

				# Remove its data blocks if they are no longer in use
				if obj_action and obj_action.name in bpy.data.actions and not obj_action.users:
					bpy.data.actions.remove(obj_action)
					VerboseActive(2) and log_msg(2, "Removed Object Action")

				if data_action and data_action.name in bpy.data.actions and not data_action.users:
					bpy.data.actions.remove(data_action)
					VerboseActive(2) and log_msg(2, "Removed Data Action")

				if obj_data and hasattr(obj_data, 'users') and not obj_data.users:
					if obj_data.name in bpy.data.cameras:
						bpy.data.cameras.remove(obj_data)
						VerboseActive(2) and log_msg(2, "Removed Camera Data")
		except Exception:
			log_msg(10, "An error occurred during remove_hierarchy: {}".format(traceback.format_exc()))

	# --- Main Runner --- #
	def modal(self, context, event):
		if event.type == 'ESC':
			try:
				scene = context.scene
				scene_status = scene.auto_cutsmart_status # Get the scene status PointerProperty
				scene_status.current_step_text = "Canceling Operation..."
				scene_status.current_sub_progress_text = f""; self.redrawUI()
				self.report({'WARNING'}, "Canceled Camera Split")
				return self.cancel(context)
			except Exception:
				log_msg(10, "An error occurred during Main Runner event.type == 'ESC': {}".format(traceback.format_exc()))

		if event.type == 'TIMER':
			# --- Robustness Check: Ensure original camera still exists before each step ---
			try:
				# Accessing any property will raise ReferenceError if the object is gone
				_ = self._original_cam.name
				if self._original_cam.name not in context.scene.objects:
					# This handles cases where the object was renamed
					raise ReferenceError("Camera was renamed.")
			except ReferenceError:
				self.report({'ERROR'}, "Original camera was deleted or renamed. Cancelling operation.")
				return self.cancel(context)

			scene = context.scene
			wm = context.window_manager
			scene_status = scene.auto_cutsmart_status # Get the scene status PointerProperty
			preferences = bpy.context.preferences.addons[__name__].preferences

			try:
				# Get current stage name and weight from the dynamically loaded PROCESS_STAGES
				current_stage_name, stage_weight = self.PROCESS_STAGES[self._progress_stage]
				scene_status.progress_stage_INDEX = self._progress_stage
				scene_status.current_step_text = f"[Step. {self._progress_stage + 1} / {len(self.PROCESS_STAGES)}] {current_stage_name}..."


				# --- Stage 0: Initialization ---
				if self._progress_stage == 0:
					scene_status.current_sub_progress_text = ""
					scene_status.overall_progress = 0.0
					self.redrawUI()

					VerboseActive(1) and log_msg(1,"\n-------- Stage 0: Initialization --------")

					self._original_cam = scene.objects.get(self._original_cam_name)
					if not self._original_cam or self._original_cam.type != 'CAMERA' or \
					   not self._original_cam.animation_data or not self._original_cam.animation_data.action:
						self.report({'ERROR'}, "Selected object is not a camera with animation or has no action assigned.")
						return self.cancel(context)

					self._original_cam_data = self._original_cam.data

					# Dynamically get all animated data paths (full paths)
					self._all_object_animated_paths = get_all_fcurve_data_paths(self._original_cam)
					self._all_camera_data_animated_paths = get_all_fcurve_data_paths(self._original_cam.data)

					settings = self._original_cam.data.auto_cutsmart_settings
					obj_action = self._original_cam.animation_data.action if self._original_cam.animation_data else None
					data_action = self._original_cam.data.animation_data.action if self._original_cam.data.animation_data else None

					threshold_fields = [
						("location_threshold", settings.location_threshold, self._original_cam, data_action),
						("rotation_threshold", settings.rotation_threshold, self._original_cam, data_action),
						("lens_threshold", settings.lens_threshold, self._original_cam.data, data_action),
						("shift_x_threshold", settings.shift_x_threshold, self._original_cam.data, data_action),
						("shift_y_threshold", settings.shift_y_threshold, self._original_cam.data, data_action),
						("sensor_width_threshold", settings.sensor_width_threshold, self._original_cam.data, data_action),
						("sensor_height_threshold", settings.sensor_height_threshold, self._original_cam.data, data_action),
						("ortho_scale_threshold", settings.ortho_scale_threshold, self._original_cam.data, data_action),
						("fisheye_fov_threshold", settings.fisheye_fov_threshold, self._original_cam.data, data_action),
						("fisheye_lens_threshold", settings.fisheye_lens_threshold, self._original_cam.data, data_action),
						("fisheye_polynomial_k0_threshold", settings.fisheye_polynomial_k0_threshold, self._original_cam.data, data_action),
						("fisheye_polynomial_k1_threshold", settings.fisheye_polynomial_k1_threshold, self._original_cam.data, data_action),
						("fisheye_polynomial_k2_threshold", settings.fisheye_polynomial_k2_threshold, self._original_cam.data, data_action),
						("fisheye_polynomial_k3_threshold", settings.fisheye_polynomial_k3_threshold, self._original_cam.data, data_action),
						("fisheye_polynomial_k4_threshold", settings.fisheye_polynomial_k4_threshold, self._original_cam.data, data_action),
						("latitude_min_threshold", settings.latitude_min_threshold, self._original_cam.data, data_action),
						("latitude_max_threshold", settings.latitude_max_threshold, self._original_cam.data, data_action),
						("longitude_min_threshold", settings.longitude_min_threshold, self._original_cam.data, data_action),
						("longitude_max_threshold", settings.longitude_max_threshold, self._original_cam.data, data_action),
					]

					self._static_thresholds.clear()
					self._animated_threshold_fcurves.clear()

					for field_name, static_value, source, action in threshold_fields:
						is_animated = False
						if action:
							for fc in action.fcurves:
								if fc.data_path.endswith(field_name):
									self._animated_threshold_fcurves[field_name] = fc
									is_animated = True
									break
						if not is_animated:
							self._static_thresholds[field_name] = static_value

					VerboseActive(1) and log_msg(1, f"Animated thresholds: {list(self._animated_threshold_fcurves.keys())}")

					profiler.profiler_end(); self._progress_stage += 1; profiler.profiler_begin(self._progress_stage)
					self._progress_sub_index = 0

				# --- Stage 1: Clear Existing Data ---
				elif current_stage_name == "Clearing existing data":
					buffer_size = preferences.stage1_buffer
					if self._progress_sub_index == 0:
						VerboseActive(1) and log_msg(1,"\n-------- Stage 1: Clear Existing Data --------")

						# First, gather all the markers that need to be removed.
						self._markers_to_remove = [marker.name for marker in scene.timeline_markers if marker.camera]
						self._total_markers = len(self._markers_to_remove)

						settings = self._original_cam.data.auto_cutsmart_settings
						cam_prefix = settings.custom_prefix if settings.custom_prefix else self._original_cam_name
						cam1_name = f"{cam_prefix}.A" if settings.suffix_type == 'LETTER' else f"{cam_prefix}.1"
						cam2_name = f"{cam_prefix}.B" if settings.suffix_type == 'LETTER' else f"{cam_prefix}.2"

						VerboseActive(1) and log_msg(1,f"Checking for existing cameras '{cam1_name}' and '{cam2_name}' and their hierarchies.")

						# Remove Existing Cameras
						scene_status.current_sub_progress_text = f"Removing existing cameras & their children..."; self.redrawUI()
						for name in [cam1_name, cam2_name]:
							if name in scene.objects:
								self.remove_hierarchy(scene.objects[name])

						scene_status.current_sub_progress_text = f"Markers that are being removed: {self._total_markers}"; self.redrawUI()

					total_items = self._total_markers
					end_index = min(self._progress_sub_index + buffer_size, total_items) if buffer_size > 0 else total_items

					# Removal all camera markers
					for i in range(self._progress_sub_index, end_index):
						marker_name = self._markers_to_remove[i]
						if marker_name in scene.timeline_markers:
							scene.timeline_markers.remove(scene.timeline_markers[marker_name])

					self._progress_sub_index = end_index
					if not buffer_size == 0:
						scene_status.current_sub_progress_text = f"Markers cleared: [{self._progress_sub_index} / {total_items}]"

					if self._progress_sub_index >= total_items:
						profiler.profiler_end(); self._progress_stage += 1; profiler.profiler_begin(self._progress_stage)
						self._progress_sub_index = 0

						# Log the completion of the stage.
						VerboseActive(1) and log_msg(1, f"\n == [STAGE END DATA] Stage 1: Clear Existing Data ==\nMarkers cleared: {self._total_markers}")

				# --- Stage 2: Duplicate Cameras ---
				elif current_stage_name == "Duplicating cameras":
					buffer_size = preferences.stage2_buffer

					# Sub-stage 0: Setup & Create Temp Camera
					if self._progress_sub_index == 0:
						if self._waste_looper == 0:
							if preferences.Copy_Camera_Children and any(self._original_cam.children):
								def count_children(parent): # Helper to count all descendants non-recursively
									q = list(parent.children)
									count = 0
									while q:
										obj = q.pop(0)
										count += 1
										q.extend(obj.children)
									return count
								self._total_children_count = count_children(self._original_cam)

							VerboseActive(1) and log_msg(1,"\n-------- Stage 2: Duplicate Cameras --------")

							scene_status.current_sub_progress_text = "Creating Temp camera."; self.redrawUI()

							# Create Temporary Camera
							self._temp_cam = self._original_cam.copy()
							self._temp_cam.data = self._original_cam.data.copy()
							context.collection.objects.link(self._temp_cam) # Link to current collection
							self._temp_cam.name = f"{self._original_cam_name}_Temp" # Give it a distinct temporary name

							# Duplicate and assign object-level animation data
							if self._original_cam.animation_data and self._original_cam.animation_data.action:
								original_obj_action = self._original_cam.animation_data.action
								new_obj_action = original_obj_action.copy()
								new_obj_action.use_fake_user = False # Ensure no fake user
								self._temp_cam.animation_data_create()
								self._temp_cam.animation_data.action = new_obj_action
								self._temp_obj_action_name = new_obj_action.name # Store the name for cleanup
								VerboseActive(1) and log_msg(1,f"  Duplicated object action '{new_obj_action.name}' for temp_cam.")
							else:
								self._temp_obj_action_name = None

							# Duplicate and assign camera-data-level animation data
							if self._original_cam.data.animation_data and self._original_cam.data.animation_data.action:
								original_data_action = self._original_cam.data.animation_data.action
								new_data_action = original_data_action.copy()
								new_data_action.use_fake_user = False # Ensure no fake user
								self._temp_cam.data.animation_data_create()
								self._temp_cam.data.animation_data.action = new_data_action
								self._temp_data_action_name = new_data_action.name # Store the name for cleanup
								VerboseActive(1) and log_msg(1,f"  Duplicated camera data action '{new_data_action.name}' for temp_cam.")
							else:
								self._temp_data_action_name = None

							self._generated_objects.append(self._temp_cam)
							VerboseActive(1) and log_msg(1,f"Created temporary camera '{self._temp_cam.name}'.")

							# Set the last keyframe of each F-curve on temp_cam to CONSTANT
							if self._temp_cam.animation_data and self._temp_cam.animation_data.action:
								for fcurve in self._temp_cam.animation_data.action.fcurves:
									if fcurve.keyframe_points:
										fcurve.keyframe_points[-1].interpolation = 'CONSTANT'
										VerboseActive(1) and log_msg(2,f"  Set last keyframe of '{fcurve.data_path}[{fcurve.array_index}]' on temp_cam to CONSTANT.")

							if self._temp_cam.data.animation_data and self._temp_cam.data.animation_data.action:
								for fcurve in self._temp_cam.data.animation_data.action.fcurves:
									if fcurve.keyframe_points:
										fcurve.keyframe_points[-1].interpolation = 'CONSTANT'
										VerboseActive(1) and log_msg(2,f"  Set last keyframe of '{fcurve.data_path}[{fcurve.array_index}]' on temp_cam.data to CONSTANT.")

						if self._waste_looper == 1:

							self._progress_sub_index = 1

						self._waste_looper = 1


					# Sub-stage 1: Create Primary Cameras & Initialize Hierarchy Copy
					elif self._progress_sub_index == 1:

						scene_status.current_sub_progress_text = "Duplicating primary cameras."; self.redrawUI()

						settings = self._original_cam.data.auto_cutsmart_settings

						# Store what collections Og_cam is in, so later can move cam1 & cam2 into
						stored_collection = self._original_cam.users_collection[0]

						cam_prefix = settings.custom_prefix if settings.custom_prefix else self._original_cam_name

						cam1_suffix = "A" if settings.suffix_type == 'LETTER' else "1"
						cam2_suffix = "B" if settings.suffix_type == 'LETTER' else "2"

						cam1_name = f"{cam_prefix}.{cam1_suffix}"
						cam2_name = f"{cam_prefix}.{cam2_suffix}"

						# Robustly remove existing cameras with the target names and their associated data
						for name in [cam1_name, cam2_name]:
							if name in scene.objects:
								self.remove_hierarchy(scene.objects[name])

						# Duplicate camera 1 by copying object and data directly
						self._cam1 = self._original_cam.copy()
						self._cam1.data = self._original_cam.data.copy()
						stored_collection.objects.link(self._cam1)
						self._cam1.name = cam1_name
						self._cam1.animation_data_clear() # Clear any animation data copied with .copy()
						self._cam1.data.animation_data_clear() # Clear any animation data copied with .copy()
						VerboseActive(1) and log_msg(1,f"Created Camera.1  '{self._cam1.name}'.")

						# Duplicate camera 2 by copying object and data directly
						self._cam2 = self._original_cam.copy()
						self._cam2.data = self._original_cam.data.copy()
						stored_collection.objects.link(self._cam2)
						self._cam2.name = cam2_name
						self._cam2.animation_data_clear() # Clear any animation data copied with .copy()
						self._cam2.data.animation_data_clear() # Clear any animation data copied with .copy()
						VerboseActive(1) and log_msg(1,f"Created Camera.2  '{self._cam2.name}'.")

						bpy.ops.object.select_all(action='DESELECT')
						self._generated_objects.append(self._cam1)
						self._generated_objects.append(self._cam2)

						self._target_cams = [self._cam1, self._cam2]

						if preferences.Copy_Camera_Children and any(self._original_cam.children):
							# Initialize state for Cam1's hierarchy copy
							self._children_to_process_queue = list(self._original_cam.children)
							self._duplication_map = {}
							self._children_processed_count = 0

							self._progress_children_processed_count = 0

							self._progress_sub_index = 2 # Start buffered duplication
						else:
							# Skip hierarchy copy, finish stage
							profiler.profiler_end(); self._progress_stage += 1; profiler.profiler_begin(self._progress_stage)
							self._progress_sub_index = 0

					# Sub-stage 2: Duplicate hierarchy for Cam1
					elif self._progress_sub_index == 2:
						if buffer_size == 0:
							scene_status.current_sub_progress_text = f"Copying hierarchy for {self._cam1.name} | {self._total_children_count} being copied"; self.redrawUI()
						else:
							scene_status.current_sub_progress_text = f"Copying hierarchy for {self._cam1.name}: [{self._children_processed_count} / {self._total_children_count}]"


						stored_collection = self._original_cam.users_collection[0]

						total_items = buffer_size if buffer_size > 0 else len(self._children_to_process_queue)
						for _ in range(total_items):
							if not self._children_to_process_queue: break
							original_child = self._children_to_process_queue.pop(0)

							new_child = original_child.copy()
							self._generated_objects.append(new_child) # Track object
							stored_collection.objects.link(new_child)
							self._duplication_map[original_child] = new_child

							self._children_to_process_queue.extend(original_child.children)
							self._children_processed_count += 1

						if not self._children_to_process_queue:
							 if not buffer_size == 0: self.redrawUI()
							 self._progress_sub_index = 3

					# Sub-stage 3: Parent for Cam1 & Initialize for Cam2
					elif self._progress_sub_index == 3:
						scene_status.current_sub_progress_text = f"Parenting hierarchy for {self._cam1.name}..."
						for original_obj, new_obj in self._duplication_map.items():
							original_obj_parent = original_obj.parent
							if original_obj_parent == self._original_cam: new_obj.parent = self._cam1
							elif original_obj_parent in self._duplication_map: new_obj.parent = self._duplication_map[original_obj_parent]
							new_obj.matrix_parent_inverse = original_obj.matrix_parent_inverse.copy()

						# Initialize state for Cam2's hierarchy copy
						self._children_to_process_queue = list(self._original_cam.children)
						self._duplication_map = {}

						self._progress_children_processed_count = self._children_processed_count

						self._children_processed_count = 0
						self._progress_sub_index = 4

					# Sub-stage 4 (BUFFERABLE): Duplicate hierarchy for Cam2
					elif self._progress_sub_index == 4:
						if buffer_size == 0:
							scene_status.current_sub_progress_text = f"Copying hierarchy for {self._cam2.name} | {self._total_children_count} being copied"; self.redrawUI()
						else:
							scene_status.current_sub_progress_text = f"Copying hierarchy for {self._cam2.name}: [{self._children_processed_count} / {self._total_children_count}]"

						stored_collection = self._original_cam.users_collection[0]

						total_items = buffer_size if buffer_size > 0 else len(self._children_to_process_queue)

						for _ in range(total_items):
							if not self._children_to_process_queue: break
							original_child = self._children_to_process_queue.pop(0)

							new_child = original_child.copy()
							self._generated_objects.append(new_child) # Track object
							stored_collection.objects.link(new_child)
							self._duplication_map[original_child] = new_child

							self._children_to_process_queue.extend(original_child.children)
							self._children_processed_count += 1

						if not self._children_to_process_queue:
							if not buffer_size == 0: self.redrawUI()
							self._progress_sub_index = 5

					# Sub-stage 5: Parent for Cam2 & Finish Stage
					elif self._progress_sub_index == 5:
						scene_status.current_sub_progress_text = f"Parenting hierarchy for {self._cam2.name}..."
						for original_obj, new_obj in self._duplication_map.items():
							original_obj_parent = original_obj.parent
							if original_obj_parent == self._original_cam: new_obj.parent = self._cam2
							elif original_obj_parent in self._duplication_map: new_obj.parent = self._duplication_map[original_obj_parent]
							new_obj.matrix_parent_inverse = original_obj.matrix_parent_inverse.copy()

						profiler.profiler_end(); self._progress_stage += 1; profiler.profiler_begin(self._progress_stage)
						self._progress_sub_index = 0

				# --- Stage 3: Analyzing and Detect Jump Frames ---
				elif current_stage_name == "Analyzing camera animation for jumps":
					buffer_size = preferences.stage3_buffer
					if self._progress_sub_index == 0:

						VerboseActive(1) and log_msg(1,"\n-------- Stage 3: Analyzing and Detect Jump Frames --------")
						log_msg(3, f"\n{'-' * 10}===[DEBUG DATA 'Part 1']=== {'-' * 10}\n{chr(0x25A0)} = Detected Jumpframe\n{chr(0x25cb)} = NOT a Jump Frame")

						self._jump_frames_detected = [] # To store actual jump frames

						scene_start = scene.frame_start
						scene_end = scene.frame_end
						self.original_keyframe_Num = self._keyframes_to_check
						self._total_keyframes_to_check = len(self._keyframes_to_check)


						scene_status.current_sub_progress_text = f"Analyzing {self._total_keyframes_to_check} frames..."; self.redrawUI()

						if self._total_keyframes_to_check < 2:
							VerboseActive(1) and log_msg(1,f"Not enough keyframes on original camera within scene range [{scene_start}, {scene_end}] to analyze for jumps. Canceling.")
							self._segments = [(scene_start, scene_end)]
							scene_status.jump_frames_detected_count = 0
							# Cancel
							self.report({'ERROR'}, "Not enough keyframes on Camera within scene range.")
							return self.cancel(context)

					total_items = self._total_keyframes_to_check
					end_index = min(self._progress_sub_index + buffer_size, total_items) if buffer_size > 0 else total_items

					for i in range(self._progress_sub_index, end_index):
						if i == 0:
							self._progress_sub_index += 1
							continue

						prev_frame = math.floor(self._keyframes_to_check[i - 1])
						curr_frame = math.ceil(self._keyframes_to_check[i])

						is_consecutive = (curr_frame - prev_frame) <= 1.0 # Check if frames are consecutive or subframe apart

						# Check for constant interpolation on any relevant FCurve at curr_frame
						is_constant_interpolation = False
						fcurves_to_check = []
						if self._original_cam.animation_data and self._original_cam.animation_data.action:
							fcurves_to_check.extend(self._original_cam.animation_data.action.fcurves)
						if self._original_cam.data.animation_data and self._original_cam.data.animation_data.action:
							fcurves_to_check.extend(self._original_cam.data.animation_data.action.fcurves)

						for fc in fcurves_to_check:
							base_data_path = fc.data_path.split('[')[0]
							if base_data_path in OBJECT_ANIMATION_DATA_PATHS or \
							   base_data_path in CAMERA_DATA_ANIMATION_PATHS:
								if has_constant_interpolation_at_frame(fc, curr_frame):
									is_constant_interpolation = True
									break

						if is_consecutive or is_constant_interpolation:
							# Optimized Value Retrieval using fcurve.evaluate()
							prev_loc = get_evaluated_property_value(self._original_cam, "location", prev_frame)
							curr_loc = get_evaluated_property_value(self._original_cam, "location", curr_frame)

							# Handle rotation (Euler or Quaternion)
							prev_rot_euler = None
							curr_rot_euler = None
							if "rotation_euler" in self._all_object_animated_paths:
								prev_rot_euler = get_evaluated_property_value(self._original_cam, "rotation_euler", prev_frame)
								curr_rot_euler = get_evaluated_property_value(self._original_cam, "rotation_euler", curr_frame)
							elif "rotation_quaternion" in self._all_object_animated_paths:
								prev_quat = get_evaluated_property_value(self._original_cam, "rotation_quaternion", prev_frame)
								curr_quat = get_evaluated_property_value(self._original_cam, "rotation_quaternion", curr_frame)
								if prev_quat and curr_quat:
									prev_rot_euler = prev_quat.to_euler(self._original_cam.rotation_mode)
									curr_rot_euler = curr_quat.to_euler(self._original_cam.rotation_mode)

							# Get camera data properties
							prev_lens = get_evaluated_property_value(self._original_cam_data, "lens", prev_frame)
							curr_lens = get_evaluated_property_value(self._original_cam_data, "lens", curr_frame)

							prev_shift_x = get_evaluated_property_value(self._original_cam_data, "shift_x", prev_frame)
							curr_shift_x = get_evaluated_property_value(self._original_cam_data, "shift_x", curr_frame)
							prev_shift_y = get_evaluated_property_value(self._original_cam_data, "shift_y", prev_frame)
							curr_shift_y = get_evaluated_property_value(self._original_cam_data, "shift_y", curr_frame)

							prev_sensor_width = get_evaluated_property_value(self._original_cam_data, "sensor_width", prev_frame)
							curr_sensor_width = get_evaluated_property_value(self._original_cam_data, "sensor_width", curr_frame)
							prev_sensor_height = get_evaluated_property_value(self._original_cam_data, "sensor_height", prev_frame)
							curr_sensor_height = get_evaluated_property_value(self._original_cam_data, "sensor_height", curr_frame)

							prev_ortho_scale = get_evaluated_property_value(self._original_cam_data, "ortho_scale", prev_frame)
							curr_ortho_scale = get_evaluated_property_value(self._original_cam_data, "ortho_scale", curr_frame)

							prev_fisheye_fov = get_evaluated_property_value(self._original_cam_data, "fisheye_fov", prev_frame)
							curr_fisheye_fov = get_evaluated_property_value(self._original_cam_data, "fisheye_fov", curr_frame)
							prev_fisheye_lens = get_evaluated_property_value(self._original_cam_data, "fisheye_lens", prev_frame)
							curr_fisheye_lens = get_evaluated_property_value(self._original_cam_data, "fisheye_lens", curr_frame)

							prev_k0 = get_evaluated_property_value(self._original_cam_data, "fisheye_polynomial_k0", prev_frame)
							curr_k0 = get_evaluated_property_value(self._original_cam_data, "fisheye_polynomial_k0", curr_frame)
							prev_k1 = get_evaluated_property_value(self._original_cam_data, "fisheye_polynomial_k1", prev_frame)
							curr_k1 = get_evaluated_property_value(self._original_cam_data, "fisheye_polynomial_k1", curr_frame)
							prev_k2 = get_evaluated_property_value(self._original_cam_data, "fisheye_polynomial_k2", prev_frame)
							curr_k2 = get_evaluated_property_value(self._original_cam_data, "fisheye_polynomial_k2", curr_frame)
							prev_k3 = get_evaluated_property_value(self._original_cam_data, "fisheye_polynomial_k3", prev_frame)
							curr_k3 = get_evaluated_property_value(self._original_cam_data, "fisheye_polynomial_k3", curr_frame)
							prev_k4 = get_evaluated_property_value(self._original_cam_data, "fisheye_polynomial_k4", prev_frame)
							curr_k4 = get_evaluated_property_value(self._original_cam_data, "fisheye_polynomial_k4", curr_frame)

							prev_lat_min = get_evaluated_property_value(self._original_cam_data, "latitude_min", prev_frame)
							curr_lat_min = get_evaluated_property_value(self._original_cam_data, "latitude_min", curr_frame)
							prev_lat_max = get_evaluated_property_value(self._original_cam_data, "latitude_max", prev_frame)
							curr_lat_max = get_evaluated_property_value(self._original_cam_data, "latitude_max", curr_frame)
							prev_lon_min = get_evaluated_property_value(self._original_cam_data, "longitude_min", prev_frame)
							curr_lon_min = get_evaluated_property_value(self._original_cam_data, "longitude_min", curr_frame)
							prev_lon_max = get_evaluated_property_value(self._original_cam_data, "longitude_max", prev_frame)
							curr_lon_max = get_evaluated_property_value(self._original_cam_data, "longitude_max", curr_frame)

							location_diff = (curr_loc - prev_loc).length if prev_loc and curr_loc else 0.0

							# Calculate highest absolute difference for rotation (Euler angles)
							highest_rot_diff = 0
							if prev_rot_euler and curr_rot_euler:
								for axis in range(3):
									diff = abs(curr_rot_euler[axis] - prev_rot_euler[axis])
									highest_rot_diff = max(highest_rot_diff, diff)

							settings = self._original_cam.data.auto_cutsmart_settings
							is_jump = False

							# Check thresholds for object properties
							if location_diff > self.get_threshold_value("location_threshold", curr_frame) or \
							   highest_rot_diff > self.get_threshold_value("rotation_threshold", curr_frame):
								is_jump = True

							# Check thresholds for camera data properties (only if values are not None)
							if (curr_shift_x is not None and prev_shift_x is not None and abs(curr_shift_x - prev_shift_x) > self.get_threshold_value("shift_x_threshold", curr_frame)) or \
							   (curr_shift_y is not None and prev_shift_y is not None and abs(curr_shift_y - prev_shift_y) > self.get_threshold_value("shift_y_threshold", curr_frame)) or \
							   (curr_sensor_width is not None and prev_sensor_width is not None and abs(curr_sensor_width - prev_sensor_width) > self.get_threshold_value("sensor_width_threshold", curr_frame)) or \
							   (curr_sensor_height is not None and prev_sensor_height is not None and abs(curr_sensor_height - prev_sensor_height) > self.get_threshold_value("sensor_height_threshold", curr_frame)):
								is_jump = True

							# Camera type specific thresholds
							if self._original_cam_data.type == 'PERSP':
								if curr_lens is not None and prev_lens is not None and abs(curr_lens - prev_lens) > self.get_threshold_value("lens_threshold", curr_frame):
									is_jump = True
							elif self._original_cam_data.type == 'ORTHO':
								if curr_ortho_scale is not None and prev_ortho_scale is not None and abs(curr_ortho_scale - prev_ortho_scale) > self.get_threshold_value("ortho_scale_threshold", curr_frame):
									is_jump = True
							elif self._original_cam_data.type == 'PANO':
								if scene.render.engine == 'CYCLES':
									pano_type = self._original_cam_data.panorama_type
									if pano_type == 'FISHEYE_EQUIDISTANT':
										if curr_fisheye_fov is not None and prev_fisheye_fov is not None and abs(curr_fisheye_fov - prev_fisheye_fov) > self.get_threshold_value("fisheye_fov_threshold", curr_frame):
											is_jump = True
									elif pano_type == 'FISHEYE_EQUISOLID':
										if (curr_fisheye_lens is not None and prev_fisheye_lens is not None and abs(curr_fisheye_lens - prev_fisheye_lens) > self.get_threshold_value("fisheye_lens_threshold", curr_frame)) or \
										   (curr_fisheye_fov is not None and prev_fisheye_fov is not None and abs(curr_fisheye_fov - prev_fisheye_fov) > self.get_threshold_value("fisheye_fov_threshold", curr_frame)):
											is_jump = True
									elif pano_type == 'EQUIRECTANGULAR':
										if (curr_lat_min is not None and prev_lat_min is not None and abs(curr_lat_min - prev_lat_min) > self.get_threshold_value("latitude_min_threshold", curr_frame)) or \
										   (curr_lat_max is not None and prev_lat_max is not None and abs(curr_lat_max - prev_lat_max) > self.get_threshold_value("latitude_max_threshold", curr_frame)) or \
										   (curr_lon_min is not None and prev_lon_min is not None and abs(curr_lon_min - prev_lon_min) > self.get_threshold_value("longitude_min_threshold", curr_frame)) or \
										   (curr_lon_max is not None and prev_lon_max is not None and abs(curr_lon_max - prev_lon_max) > self.get_threshold_value("longitude_max_threshold", curr_frame)):
											is_jump = True
									elif pano_type == 'FISHEYE_LENS_POLYNOMIAL':
										if (curr_fisheye_fov is not None and prev_fisheye_fov is not None and abs(curr_fisheye_fov - prev_fisheye_fov) > self.get_threshold_value("fisheye_fov_threshold", curr_frame)) or \
										   (curr_k0 is not None and prev_k0 is not None and abs(curr_k0 - prev_k0) > self.get_threshold_value("fisheye_polynomial_k0_threshold", curr_frame)) or \
										   (curr_k1 is not None and prev_k1 is not None and abs(curr_k1 - prev_k1) > self.get_threshold_value("fisheye_polynomial_k1_threshold", curr_frame)) or \
										   (curr_k2 is not None and prev_k2 is not None and abs(curr_k2 - prev_k2) > self.get_threshold_value("fisheye_polynomial_k2_threshold", curr_frame)) or \
										   (curr_k3 is not None and prev_k3 is not None and abs(curr_k3 - prev_k3) > self.get_threshold_value("fisheye_polynomial_k3_threshold", curr_frame)) or \
										   (curr_k4 is not None and prev_k4 is not None and abs(curr_k4 - prev_k4) > self.get_threshold_value("fisheye_polynomial_k4_threshold", curr_frame)):
											is_jump = True
								else: # Non-Cycles PANO
									if curr_lens is not None and prev_lens is not None and abs(curr_lens - prev_lens) > self.get_threshold_value("lens_threshold", curr_frame):
										is_jump = True

							# Helpful Display Threshold Debug Stuff
							char_jump = '\u25A0' if is_jump else '\u25CB'
							char_sep = '=' * 2 if is_jump else 'x' * 2
							log_lines = [
								f"\n {char_jump} {char_sep} [FRAME: {curr_frame}] {char_sep} {char_jump}",
								f"	  Location Dif: {location_diff}",
								f"	  Rot Dif: {highest_rot_diff}"
							]
							if curr_shift_x is not None and prev_shift_x is not None:
								log_lines.append(f"	   Shift_x Dif: {abs(curr_shift_x - prev_shift_x)}")
							if curr_shift_y is not None and prev_shift_y is not None:
								log_lines.append(f"	   Shift_y Dif: {abs(curr_shift_y - prev_shift_y)}")
							if curr_sensor_width is not None and prev_sensor_width is not None:
								log_lines.append(f"	   Sensor_Width Dif: {abs(curr_sensor_width - prev_sensor_width)}")
							if curr_sensor_height is not None and prev_sensor_height is not None:
								log_lines.append(f"	   Sensor_Height Dif: {abs(curr_sensor_height - prev_sensor_height)}")
							camera_type = self._original_cam_data.type
							if camera_type == 'PERSP' and curr_lens is not None and prev_lens is not None:
								log_lines.append(f"	   Lens Dif: {abs(curr_lens - prev_lens)}")
							elif camera_type == 'ORTHO' and curr_ortho_scale is not None and prev_ortho_scale is not None:
								log_lines.append(f"	   Ortho Scale Dif: {abs(curr_ortho_scale - prev_ortho_scale)}")
							elif camera_type == 'PANO':
								if scene.render.engine == 'CYCLES':
									if self._original_cam_data.panorama_type == 'FISHEYE_EQUIDISTANT' and curr_fisheye_fov is not None and prev_fisheye_fov is not None:
										log_lines.append(f"	   Fisheye FOV Dif: {abs(curr_fisheye_fov - prev_fisheye_fov)}")
								elif curr_lens is not None and prev_lens is not None:
									log_lines.append(f"	   Lens Dif: {abs(curr_lens - prev_lens)}")

							log_msg(3, "\n".join(log_lines))

							# [END] Helpful Display Threshold Debug Stuff

							if is_jump:
								self._jump_frames_detected.append(curr_frame)

					self._progress_sub_index = end_index

					if not (self._progress_sub_index >= total_items or buffer_size == 0):
						scene_status.current_sub_progress_text = f"Keyframes analyzed: [{self._progress_sub_index} / {total_items}]"

					if self._progress_sub_index >= total_items:

						log_msg(3, f"{'-' * 10}~=[END OF DATA]=~{'-' * 10}\n")
						jump_frames = sorted(list(set(self._jump_frames_detected)))
						scene_status.jump_frames_detected_count = len(jump_frames)

						if len(jump_frames) == 0:
							# Cancel
							VerboseActive(1) and log_msg(1,f"No jumpframes found on camera within scene range [{scene_start}, {scene_end}] to continue. Canceling...")
							self.report({'ERROR'}, "No jumpframes found on Camera within scene range")
							return self.cancel(context)

						scene_status.current_sub_progress_text = f"Caculating frame range of {len(jump_frames) - 1} Chunks"; self.redrawUI()
						scene_end = scene.frame_end

						# Ensure jump_frames include scene_start
						scene_start = scene.frame_start
						if scene_start not in jump_frames:
							jump_frames.insert(0, scene_start)

						jump_frames = sorted(list(set(jump_frames))) # Re-sort and remove duplicates after adding boundaries

						self._segments = []
						for i in range(len(jump_frames)):
							start_frame = int(round(jump_frames[i]))
							end_frame = None

							if i < len(jump_frames) - 1:
								end_frame = int(round(jump_frames[i+1])) - 1
							else:
								end_frame = scene_end

							if start_frame <= end_frame:
								self._segments.append((start_frame, end_frame))

						# Move to the next stage
						profiler.profiler_end(); self._progress_stage += 1; profiler.profiler_begin(self._progress_stage)
						self._progress_sub_index = 0

						if VerboseActive(1):
							total_keyframes = sum(
								1 for fc in (self._temp_cam.animation_data.action.fcurves if self._temp_cam.animation_data and self._temp_cam.animation_data.action else []) for kp in fc.keyframe_points
								if scene_start <= kp.co.x <= scene_end
							) + sum(
								1 for fc in (self._temp_cam.data.animation_data.action.fcurves if self._temp_cam.data.animation_data and self._temp_cam.data.animation_data.action else []) for kp in fc.keyframe_points
								if scene_start <= kp.co.x <= scene_end)

							log_msg(1, f"\n == [STAGE END DATA] Stage 3: Analyzing and Detect Jump Frames ==\n"
										f"Total Keyframes: {total_keyframes}\n")

				# --- Stage 4: Sample & Convert Keyframes on Temp Camera ---
				elif current_stage_name == "Baking Keyframes":
					buffer_size = preferences.stage4_buffer
					if self._progress_sub_index == 0:
						scene_status.current_sub_progress_text = "Preparing to sample fcurves..."; self.redrawUI()

						VerboseActive(1) and log_msg(1,"\n-------- Stage 4: Sample & Convert Keyframes on Temp Camera --------")
						# Get start and end frames for the operation
						scene = context.scene
						self.start_frame = scene.frame_start
						self.end_frame = scene.frame_end

						# Collect all F-curves from the temporary camera into a single list
						self.fcurves_to_process = []
						if self._temp_cam.animation_data and self._temp_cam.animation_data.action:
							self.fcurves_to_process.extend(self._temp_cam.animation_data.action.fcurves)
						if self._temp_cam.data.animation_data and self._temp_cam.data.animation_data.action:
							self.fcurves_to_process.extend(self._temp_cam.data.animation_data.action.fcurves)
						self._total_fcurves_to_bake = len(self.fcurves_to_process)
						self._fcurves_to_bake = self.fcurves_to_process

						# --- Log initial keyframe count for debugging ---
						if VerboseActive(1):
							self.begin_keyframes_count = sum(len(fc.keyframe_points) for fc in self.fcurves_to_process)
							log_msg(1, f"  Total keyframes before processing: {self.begin_keyframes_count}")


					total_items = self._total_fcurves_to_bake
					end_index = min(self._progress_sub_index + buffer_size, total_items) if buffer_size > 0 else total_items

					scene_status.current_sub_progress_text = f"Total fcurves to sample: {total_items}"; self.redrawUI()

					for i in range(self._progress_sub_index, end_index):
						fcurve = self._fcurves_to_bake[i]
						fcurve.convert_to_samples(self.start_frame, self.end_frame)
						fcurve.convert_to_keyframes(self.start_frame, self.end_frame)

					self._progress_sub_index = end_index
					if not buffer_size == 0:
						scene_status.current_sub_progress_text = f"F-curves baked: [{self._progress_sub_index} / {total_items}]"

					if self._progress_sub_index >= total_items:

						if preferences.Keep_Bake_Frames and (0 < len(context.object.data.decimate_blocks)):
							animation_data = self._temp_cam.animation_data
							animation_data_data = self._temp_cam.data.animation_data
							# Collect all unique start and end frames from segments to preserve them from decimation
							frames_to_preserve_from_decimation = set()
							if True: # Always preserve original keyframes
								for frameNum in self.original_keyframe_Num:
									frames_to_preserve_from_decimation.add(frameNum)
							for start, end in self._segments:
								frames_to_preserve_from_decimation.add(start)
								frames_to_preserve_from_decimation.add(end)
							frames_to_preserve_from_decimation = sorted(list(frames_to_preserve_from_decimation))

						# [Debug Data] 'Point.2' Get total keyframes AFTER Bake / BEFORE Decimation
							if VerboseActive(1):
								AfterBake_keyframes_count = 0
								if animation_data and animation_data.action:
									for fc in animation_data.action.fcurves:
										AfterBake_keyframes_count += len(fc.keyframe_points)
								if animation_data_data and animation_data_data.action:
									for fc in animation_data_data.action.fcurves:
										AfterBake_keyframes_count += len(fc.keyframe_points)

							scene_status.current_sub_progress_text = "Applying decimation..."; self.redrawUI()

							# --- [FIX] Use try/finally to ensure UI context is always restored ---
							override, original_type = None, None
							try:
								try:
									override, original_type = ensure_graph_editor_context()
									if override:
										if hasattr(bpy.context, "temp_override"):
											with bpy.context.temp_override(**override):
												self.run_graph_editor_decimation()
										else:
											ctx = bpy.context.copy()
											ctx.update(override)
											self.run_graph_editor_decimation(ctx)
									else:
										log_msg(1, "No valid Graph Editor context found or created.")
								except Exception:
									log_msg(10, f"A major error occurred: {traceback.format_exc()}")

								finally:
									# Ensure the original area type is restored even if an error occurs.
									if original_type and override and override.get("area"):
										try:
											# Check if area still exists before modifying
											if override["area"].type == 'GRAPH_EDITOR':
												override["area"].type = original_type
										except (ReferenceError, Exception) as e:
											log_msg(10, f"Could not restore original area type: {traceback.format_exc()}")

							except Exception as e:
								log_msg(10, f"Unexpected error during Graph Editor context handling: {traceback.format_exc()}")

						# --- Final logging ---
						profiler.profiler_end(); self._progress_stage += 1; profiler.profiler_begin(self._progress_stage)
						self._progress_sub_index = 0

						if VerboseActive(1):
							final_keyframes_count = sum(len(fc.keyframe_points) for fc in self.fcurves_to_process)
							log_msg(1, f"  Total keyframes after processing: {final_keyframes_count}")
							log_msg(1, f"  Keyframe difference: {final_keyframes_count - self.begin_keyframes_count}")
							log_msg(1, f"== [STAGE END DATA] Stage 4: Sample & Convert complete ==")

				# --- Stage 5: Split and Assign Animation Chunks ---
				elif current_stage_name == "Splitting and assigning animation chunks":
					buffer_size = preferences.stage5_buffer

					if self._progress_sub_index == 0:
						log_msg(1, "\n-------- Stage 5: Split and Assign Animation Chunks (Per F-Curve) --------")

						# --- Initialization for the stage ---
						# 1. Collect all source F-curves into a single list
						self._fcurves_to_split = []
						temp_obj_action = self._temp_cam.animation_data.action if self._temp_cam.animation_data else None
						temp_data_action = self._temp_cam.data.animation_data.action if self._temp_cam.data.animation_data else None

						if temp_obj_action:
							self._fcurves_to_split.extend([(fc, 'OBJECT') for fc in temp_obj_action.fcurves if fc.data_path in self._all_object_animated_paths])
						if temp_data_action:
							self._fcurves_to_split.extend([(fc, 'DATA') for fc in temp_data_action.fcurves if fc.data_path in self._all_camera_data_animated_paths])

						self._total_fcurves_to_split = len(self._fcurves_to_split)
						scene_status.current_sub_progress_text = f"Processing {self._total_fcurves_to_split} F-curves..."
						self.redrawUI()

						# 2. Pre-sort segments for each camera
						self._segments_for_cams = [[], []]
						for i, segment in enumerate(self._segments):
							self._segments_for_cams[i % 2].append(segment)

						# 3. Ensure target cameras have actions ready
						for cam in self._target_cams:
							if not cam.animation_data: cam.animation_data_create()
							if not cam.animation_data.action: cam.animation_data.action = bpy.data.actions.new(f"{cam.name}Action")
							if not cam.data.animation_data: cam.data.animation_data_create()
							if not cam.data.animation_data.action: cam.data.animation_data.action = bpy.data.actions.new(f"{cam.name}_DataAction")

					# --- Buffering Loop (per F-curve) ---
					total_items = self._total_fcurves_to_split
					end_index = min(self._progress_sub_index + buffer_size, total_items) if buffer_size > 0 else total_items

					# Helper function to avoid code duplication
					def is_in_any_segment(frame, segment_list):
						for start, end in segment_list:
							if start <= frame <= end:
								return True
						return False

					for i in range(self._progress_sub_index, end_index):
						source_fc, fc_type = self._fcurves_to_split[i]

						# Process for both target cameras
						for cam_idx, target_cam in enumerate(self._target_cams):
							segments_for_this_cam = self._segments_for_cams[cam_idx]

							# Filter keyframes for the current camera's segments
							keyframes_to_copy = [kp for kp in source_fc.keyframe_points if is_in_any_segment(kp.co.x, segments_for_this_cam)]

							if keyframes_to_copy:
								# Get the correct target action (object or data)
								target_action = target_cam.animation_data.action if fc_type == 'OBJECT' else target_cam.data.animation_data.action

								# Find or create the target F-curve
								target_fc = target_action.fcurves.find(data_path=source_fc.data_path, index=source_fc.array_index)
								if not target_fc:
									target_fc = target_action.fcurves.new(data_path=source_fc.data_path, index=source_fc.array_index)

								# Efficiently add and populate keyframes
								key_count = len(keyframes_to_copy)
								existing_keys = len(target_fc.keyframe_points)
								target_fc.keyframe_points.add(count=key_count)
								for k, kp in enumerate(keyframes_to_copy):
									new_kp = target_fc.keyframe_points[existing_keys + k]
									new_kp.co = kp.co
									new_kp.interpolation = kp.interpolation
									new_kp.easing = kp.easing
									new_kp.back = kp.back
									new_kp.amplitude = kp.amplitude
									new_kp.period = kp.period
									new_kp.handle_left_type = kp.handle_left_type
									new_kp.handle_right_type = kp.handle_right_type
									new_kp.handle_left = kp.handle_left
									new_kp.handle_right = kp.handle_right

					self._progress_sub_index = end_index
					if not buffer_size == 0:
						scene_status.current_sub_progress_text = f"F-curves processed: [{self._progress_sub_index} / {total_items}]"

					if self._progress_sub_index >= total_items:
						for cam in self._target_cams:
							if bpy.app.version >= (4, 4, 0):
								# For object-level animation
								if cam.animation_data:
									action = cam.animation_data.action
									if action:
										# Check if a suitable slot already exists
										if not cam.animation_data.action_suitable_slots:
											# Create a new slot compatible with the action
											slot = cam.animation_data.action_slots.new(action)
										else:
											slot = cam.animation_data.action_suitable_slots[0]
										cam.animation_data.action_slot = slot

								# For data-level animation (camera data block)
								if cam.data.animation_data:
									data_action = cam.data.animation_data.action
									if data_action:
										if not cam.data.animation_data.action_suitable_slots:
											data_slot = cam.data.animation_data.action_slots.new(data_action)
										else:
											data_slot = cam.data.animation_data.action_suitable_slots[0]
										cam.data.animation_data.action_slot = data_slot

						profiler.profiler_end(); self._progress_stage += 1; profiler.profiler_begin(self._progress_stage)
						self._progress_sub_index = 0
						VerboseActive(1) and log_msg(1, f"Finished processing {total_items} F-curves.")

				# --- Stage 6: Modify F-curves for current segment (Constant + Padding) ---
				elif current_stage_name == "Modifying F-curves (Constant/Padding)":
					buffer_size = preferences.stage6_buffer

					if self._progress_sub_index == 0:
						log_msg(1,"\n-------- Stage 6: Modify F-curves for current segment (Constant + Padding) --------")
						scene_status.current_sub_progress_text = f"Total Segments to Modify: {len(self._segments)}{' | In progress...' if buffer_size == 0 else ''}"; self.redrawUI()

					total_items = len(self._segments)
					end_index = min(self._progress_sub_index + buffer_size, total_items) if buffer_size > 0 else total_items

					for i in range(self._progress_sub_index, end_index):
						# Get the target camera and its actions for the current segment.
						start_frame, end_frame = self._segments[i]
						current_target_cam = self._target_cams[i % 2]
						target_object_action = current_target_cam.animation_data.action
						target_camera_data_action = current_target_cam.data.animation_data.action

						if start_frame <= end_frame:
							all_target_fcurves = []
							if target_object_action:
								all_target_fcurves.extend([fc for fc in target_object_action.fcurves if fc.data_path in self._all_object_animated_paths])
							if target_camera_data_action:
								all_target_fcurves.extend([fc for fc in target_camera_data_action.fcurves if fc.data_path in self._all_camera_data_animated_paths])

							last_frame_in_segment = end_frame
							for target_fc in all_target_fcurves:
								kps_at_last_frame = [kp for kp in target_fc.keyframe_points if abs(kp.co.x - last_frame_in_segment) < 0.001]
								for kp_target in kps_at_last_frame:
									kp_target.interpolation = 'CONSTANT'

							# Padding keyframe logic: Add a keyframe two frames after the end of the current segment
							if i + 2 < len(self._segments):
								next_next_segment_start_frame = self._segments[i + 2][0]
								padding_frame = last_frame_in_segment + 2

								if padding_frame <= scene.frame_end:
									# OBJECT LEVEL ANIMATION PATHS
									if self._original_cam.animation_data and self._original_cam.animation_data.action:
										for fcurve in self._original_cam.animation_data.action.fcurves:
											if fcurve.data_path in self._all_object_animated_paths:
												try:
													evaluated_value = fcurve.evaluate(next_next_segment_start_frame)

													target_fcurve_obj = current_target_cam.animation_data.action.fcurves.find(
														data_path=fcurve.data_path,
														index=fcurve.array_index
													)
													if not target_fcurve_obj:
														target_fcurve_obj = current_target_cam.animation_data.action.fcurves.new(
															data_path=fcurve.data_path,
															index=fcurve.array_index
														)

													kps_at_padding_obj = [kp for kp in target_fcurve_obj.keyframe_points if abs(kp.co.x - padding_frame) < 0.001]
													for kp_to_remove in kps_at_padding_obj:
														target_fcurve_obj.keyframe_points.remove(kp_to_remove)

													new_kp = target_fcurve_obj.keyframe_points.insert(padding_frame, evaluated_value)
													new_kp.interpolation = 'CONSTANT'
													new_kp.handle_left_type = 'FREE'
													new_kp.handle_right_type = 'FREE'

													log_msg(2,f"	 -> Padded object F-curve '{fcurve.data_path}' at {padding_frame} with value {evaluated_value}")
												except Exception as e:
													log_msg(10,f"	 -> Warning: Could not pad object F-curve '{fcurve.data_path}' at {padding_frame}: {traceback.format_exc()}")

									# OBJECT "DATA" LEVEL ANIMATION PATHS
									if self._original_cam.data.animation_data and self._original_cam.data.animation_data.action:
										for fcurve in self._original_cam.data.animation_data.action.fcurves:
											if fcurve.data_path in self._all_camera_data_animated_paths:
												try:
													evaluated_value = fcurve.evaluate(next_next_segment_start_frame)

													target_fcurve_data = current_target_cam.data.animation_data.action.fcurves.find(
														data_path=fcurve.data_path,
														index=fcurve.array_index
													)
													if not target_fcurve_data:
														target_fcurve_data = current_target_cam.data.animation_data.action.fcurves.new(
															data_path=fcurve.data_path,
															index=fcurve.array_index
														)

													kps_at_padding_data = [kp for kp in target_fcurve_data.keyframe_points if abs(kp.co.x - padding_frame) < 0.001]
													for kp_to_remove in kps_at_padding_data:
														target_fcurve_data.keyframe_points.remove(kp_to_remove)

													new_kp = target_fcurve_data.keyframe_points.insert(padding_frame, evaluated_value)
													new_kp.interpolation = 'CONSTANT'
													new_kp.handle_left_type = 'FREE'
													new_kp.handle_right_type = 'FREE'

													log_msg(2,f"	 -> Padded camera data F-curve '{fcurve.data_path}' at {padding_frame} with value {evaluated_value}")
												except Exception as e:
													log_msg(10,f"	 -> Warning: Could not pad camera data F-curve '{fcurve.data_path}' at {padding_frame}: {traceback.format_exc()}")

					self._progress_sub_index = end_index
					if not buffer_size == 0:
						scene_status.current_sub_progress_text = f"Segments modified: [{self._progress_sub_index} / {total_items}]"

					if self._progress_sub_index >= total_items:
						profiler.profiler_end(); self._progress_stage += 1; profiler.profiler_begin(self._progress_stage)
						self._progress_sub_index = 0
						VerboseActive(1) and log_msg(1,f"Finished modifying {total_items} segments.")

				# --- Stage 7: Add Timeline Markers ---
				elif current_stage_name == "Adding timeline markers":
					buffer_size = preferences.stage7_buffer

					if self._progress_sub_index == 0:
						total_segments = len(self._segments)
						VerboseActive(1) and log_msg(1,"\n-------- Stage 7: Add Timeline Markers --------")
						scene_status.current_sub_progress_text = f"Total Markers to add: {total_segments}"; self.redrawUI()

					total_items = len(self._segments)
					end_index = min(self._progress_sub_index + buffer_size, total_items) if buffer_size > 0 else total_items

					for i in range(self._progress_sub_index, end_index):
						start_frame, end_frame = self._segments[i]
						current_target_cam = self._target_cams[i % 2]

						marker_name = f"Segment {i + 1} Start ({current_target_cam.name})"

						if marker_name in scene.timeline_markers:
							bpy.context.scene.timeline_markers.remove(bpy.context.scene.timeline_markers.get(marker_name))

						marker = scene.timeline_markers.new(marker_name, frame=int(start_frame))
						marker.camera = current_target_cam
						self._markers_added_by_script.append(marker.name)  # Store marker name

					self._progress_sub_index = end_index
					if not buffer_size == 0:
						scene_status.current_sub_progress_text = f"Markers added: [{self._progress_sub_index} / {total_items}]"

					if self._progress_sub_index >= total_items:

						scene_status.total_markers_added = len(self._segments)
						profiler.profiler_end(); self._progress_stage += 1; profiler.profiler_begin(self._progress_stage)
						self._progress_sub_index = 0  # Reset index for next stage
						if VerboseActive(1):
							log_msg(1, f"\n== [STAGE END DATA] Stage 7: Add Timeline Markers ==\n"
									   f"Total Markers added (use segments): {len(self._segments)}\n")

				# --- Stage 8: Set Scene Motion Blur Keyframes (Conditional) ---
				elif current_stage_name == "Setting Scene Motion Blur Keyframes":
					buffer_size = preferences.stage8_buffer
					if preferences.set_motionblur_keyframes:
						if self._progress_sub_index == 0:
							VerboseActive(1) and log_msg(1,"\n-------- Stage 8: Set Scene Motion Blur Keyframes --------")

							# --- Compatibility Logic: Find correct path and integer values ---
							mb_values, motion_blur_path = _get_motion_blur_int_values(scene)

							# Store the compatible integer values
							self.MB_CENTER = mb_values['CENTER']
							self.MB_START = mb_values['START']
							self.MB_END = mb_values['END']

							VerboseActive(1) and log_msg(1,f"Motion Blur Path: {motion_blur_path}")
							VerboseActive(1) and log_msg(1,f"Detected F-Curve Values: CENTER={self.MB_CENTER}, START={self.MB_START}, END={self.MB_END}")

							# Make sure scene has animation action data
							scene_action = scene.animation_data.action if scene.animation_data else None
							if not scene_action:
								scene.animation_data_create()
								scene_action = bpy.data.actions.new("SceneMotionBlurAction")
								scene.animation_data.action = scene_action

							if not scene.animation_data:
								scene.animation_data_create()

							# Check scene has action (creates one if needed)
							if not scene.animation_data.action:
								scene.animation_data.action = bpy.data.actions.new("SceneMotionBlurAction")

							scene_action = scene.animation_data.action


							self.motion_blur_fcurve = scene_action.fcurves.find(data_path=motion_blur_path)
							if not self.motion_blur_fcurve:
								self.motion_blur_fcurve = scene_action.fcurves.new(data_path=motion_blur_path)

							# Make action have fake user so not purged
							if scene_action:
								scene_action.use_fake_user = True

							self.total_jump_frames = len(self._jump_frames_detected)
							scene_status.current_sub_progress_text = f"Total keyframes to add: {self.total_jump_frames * 3}"; self.redrawUI()

						total_items = len(self._jump_frames_detected)
						end_index = min(self._progress_sub_index + buffer_size, total_items) if buffer_size > 0 else total_items

						# Iterate through all detected jump frames and set keyframes for each one.
						for i in range(self._progress_sub_index, end_index):
							jump_frame = self._jump_frames_detected[i]
							prev_frame = jump_frame - 1
							curr_frame = jump_frame
							next_frame = jump_frame + 1

							# Frame before jump: motion_blur_position = 'END'
							if prev_frame >= scene.frame_start:
								kps_at_prev = [kp for kp in self.motion_blur_fcurve.keyframe_points if abs(kp.co.x - prev_frame) < 0.001]
								for kp_to_remove in kps_at_prev:
									self.motion_blur_fcurve.keyframe_points.remove(kp_to_remove)
								new_kp = self.motion_blur_fcurve.keyframe_points.insert(prev_frame, self.MB_END)

								new_kp.interpolation = 'CONSTANT'
								new_kp.handle_left_type = 'FREE'
								new_kp.handle_right_type = 'FREE'
								VerboseActive(2) and log_msg(2,f"	   -> Set motion_blur_position to END ({self.MB_END}) at frame {prev_frame}")

							# Frame at jump: motion_blur_position = 'START'
							kps_at_curr = [kp for kp in self.motion_blur_fcurve.keyframe_points if abs(kp.co.x - curr_frame) < 0.001]
							for kp_to_remove in kps_at_curr:
								self.motion_blur_fcurve.keyframe_points.remove(kp_to_remove)
							new_kp = self.motion_blur_fcurve.keyframe_points.insert(curr_frame, self.MB_START)

							new_kp.interpolation = 'CONSTANT'
							new_kp.handle_left_type = 'FREE'
							new_kp.handle_right_type = 'FREE'
							VerboseActive(2) and log_msg(2,f"	   -> Set motion_blur_position to START ({self.MB_START}) at frame {curr_frame}")

							# Two frames after jump: motion_blur_position = 'CENTER'
							if next_frame <= scene.frame_end:
								kps_at_next = [kp for kp in self.motion_blur_fcurve.keyframe_points if abs(kp.co.x - next_frame) < 0.001]
								for kp_to_remove in kps_at_next:
									self.motion_blur_fcurve.keyframe_points.remove(kp_to_remove)
								new_kp = self.motion_blur_fcurve.keyframe_points.insert(next_frame, self.MB_CENTER)

								new_kp.interpolation = 'CONSTANT'
								new_kp.handle_left_type = 'FREE'
								new_kp.handle_right_type = 'FREE'
								VerboseActive(2) and log_msg(2,f"	   -> Set motion_blur_position to CENTER ({self.MB_CENTER}) at frame {next_frame}")

						self._progress_sub_index = end_index
						if not buffer_size == 0:
							scene_status.current_sub_progress_text = f"Keyframes added: [{self._progress_sub_index * 3} / {total_items * 3}]"

						# After the loop is complete, update the status and advance to the next stage.
						if self._progress_sub_index >= total_items:
							profiler.profiler_end(); self._progress_stage += 1; profiler.profiler_begin(self._progress_stage)
							self._progress_sub_index = 0
							if VerboseActive(1):
								log_msg(1, f"\n== [STAGE END DATA] Stage 8: Set Scene Motionblur Keyframes ==\n"
											f"Total Motion Blur Keyframes set: {self.total_jump_frames * 3}\n")

					 # If motion blur keyframes option is not active, skip this stage
					else:
						profiler.profiler_end(); self._progress_stage += 1; profiler.profiler_begin(self._progress_stage)
						self._progress_sub_index = 0

				# --- Stage 8/9: Cleanup and restore ---
				elif current_stage_name == "Cleanup and restore":

					if not preferences.set_motionblur_keyframes:
						log_msg(1, "Stage: Setting Scene Motion Blur Keyframes [Skipped]")
						profiler.profiler_end(False); self._progress_stage += 1; profiler.profiler_begin(self._progress_stage)
						self._progress_sub_index = 0


					VerboseActive(1) and log_msg(1,f"\n-------- Stage {'9' if preferences.set_motionblur_keyframes else '8'}: Cleanup and Restore --------")

					if not preferences.Keep_Bake_Frames:

						scene_status.current_sub_progress_text = "Converting generated cameras keyframes to samples | In progress..."; self.redrawUI()

						camList = [self._cam1, self._cam2]
						scene_start = scene.frame_start
						scene_end = scene.frame_end

						for i in range(len(camList)):
							current_target_cam = camList[i]
							target_object_action = current_target_cam.animation_data
							target_camera_data_action = current_target_cam.data.animation_data

							self.fcurves_to_process = []

							if target_object_action and target_object_action.action:
								self.fcurves_to_process.extend(target_object_action.action.fcurves)
							if target_camera_data_action and target_camera_data_action.action:
								self.fcurves_to_process.extend(target_camera_data_action.action.fcurves)

							for i, fcurve in enumerate(self.fcurves_to_process):
								fcurve.convert_to_samples(scene_start, scene_end)


					scene_status.current_sub_progress_text = "Cleaning up temporary data..."; self.redrawUI()

					# Safely delete Temporary Camera and its associated data
					self.remove_hierarchy(self._temp_cam)

					VerboseActive(1) and log_msg(1,"Cleaned up temporary camera | On completion.")

					# Re-select original camera and restore frame
					bpy.ops.object.select_all(action='DESELECT')
					if self._original_cam and self._original_cam.name in bpy.data.objects:
						bpy.data.objects[self._original_cam.name].select_set(True)
						context.view_layer.objects.active = bpy.data.objects[self._original_cam.name]

					profiler.profiler_end() # End the last profiling stage
					self._progress_stage += 1 # Increment to move past the last stage index
					if VerboseActive(1):
						log_msg(1, f"\n == [STAGE END DATA] Stage {'9' if preferences.set_motionblur_keyframes else '8'}: Cleanup and restore ==\n")
					scene_status.overall_progress = 100.0
					scene_status.current_step_text = "Complete!"
					scene_status.current_sub_progress_text = f"Detected {scene_status.jump_frames_detected_count} jump frames."
					print("=====~~~~~===== Camera splitting complete =====~~~~~=====\n")



					# --- Update Learning Data (Conditional) ---
					if preferences.keep_learning:

						# Log the summary of the run
						stage_labels = [label for label, _ in DEFAULT_PROCESS_STAGES]
						profiler.log_profiler_summary(stage_labels)

						# Finalize the run. Append and save data.
						profiler.finalize_run()

						VerboseActive(1) and log_msg(1, "Performance data saved and coefficients updated.")
					else:
						VerboseActive(1) and log_msg(1, "Learning is disabled. Performance data not saved.")


					return self.finish(context)

			except Exception:
				log_msg(10, "An error occurred during Main Runner modal stage section: {}".format(traceback.format_exc()))
				return self.cancel(context)

			try:
				# Calculate overall progress based on completed stages and current sub-progress
				total_weight = sum(weight for _, weight in self.PROCESS_STAGES)
				completed_weight = sum(self.PROCESS_STAGES[i][1] for i in range(self._progress_stage))

				if self._progress_stage < len(self.PROCESS_STAGES):
					current_stage_weight = self.PROCESS_STAGES[self._progress_stage][1]
				else:
					current_stage_weight = 0 # No current stage if all are completed

				sub_progress_factor = 0
				if current_stage_name == "Clearing existing data" and self._total_markers > 1:
					sub_progress_factor = self._progress_sub_index / self._total_markers

				elif current_stage_name == "Duplicating cameras": # Camera Duplication + children copy
					child_progression = self._progress_children_processed_count + self._children_processed_count
					sub_progress_factor = (min(self._progress_sub_index, 1) + child_progression) / ((self._total_children_count*2) + 1)

				elif current_stage_name == "Analyzing camera animation for jumps" and self._total_keyframes_to_check > 1: # Jump detection
					sub_progress_factor = (self._progress_sub_index - 1) / (self._total_keyframes_to_check - 1) if (self._total_keyframes_to_check - 1) > 0 else 0

				elif current_stage_name == "Splitting and assigning animation chunks" and self._total_fcurves_to_split > 0:
					 sub_progress_factor = self._progress_sub_index / self._total_fcurves_to_split

				elif current_stage_name in ["Modifying F-curves (Constant/Padding)", "Adding timeline markers"] and len(self._segments) > 0: # Iterating segments/markers
					 sub_progress_factor = self._progress_sub_index / len(self._segments)

				elif current_stage_name == "Setting Scene Motion Blur Keyframes": # Special case for motion blur, depends on jump frames
					 sub_progress_factor = self._progress_sub_index / len(self._jump_frames_detected) if len(self._jump_frames_detected) > 0 else 0

				elif current_stage_name == "Baking Keyframes" and self._total_fcurves_to_bake > 0: # Baking F-curves
					 sub_progress_factor = self._progress_sub_index / self._total_fcurves_to_bake

				current_progress_in_stage = current_stage_weight * sub_progress_factor
				scene_status.overall_progress = ((completed_weight + current_progress_in_stage) / total_weight) * 100.0 if total_weight > 0 else 100.0


				self.redrawUI()
			except Exception:
				log_msg(10, "An error occurred during Main Runner Calculate overall progress section: {}".format(traceback.format_exc()))
				return {'RUNNING_MODAL'}


		return {'RUNNING_MODAL'}

	def invoke(self, context, event):
		try:
			wm = context.window_manager
			scene = context.scene
			preferences = bpy.context.preferences.addons[__name__].preferences
			global _report_invoked, critical_error_occurred

			# Reset error flags for a new run
			_report_invoked = False
			critical_error_occurred = False

			if self.action == 'CANCEL':
				return self.cancel(context)

			scene_status = scene.auto_cutsmart_status

			if scene_status.is_running:
				self.report({'WARNING'}, "Canceled Camera Split")
				return self.cancel(context)

			selected_obj = context.view_layer.objects.active
			if not selected_obj or selected_obj.type != 'CAMERA' or not has_animation(selected_obj):
				self.report({'ERROR'}, "Select a Camera with animation to Split.")
				return {'CANCELLED'}

			settings = selected_obj.data.auto_cutsmart_settings
			if bpy.context.screen.show_fullscreen:
				self.report({'WARNING'},"Looks like you're in fullscreen mode — switching back to continue.")
				bpy.ops.screen.back_to_previous()

			# Reset all state variables for a new run
			log_storage.clear() # Clear logs for a new run
			self._original_cam_name = selected_obj.name
			self._original_cam = selected_obj
			self._progress_stage = 0
			self._progress_sub_index = 0
			self._segments = []
			self._target_cams = []
			self._total_keyframes_to_check = 0
			self._markers_to_remove = []
			self._total_markers = 0
			self._temp_cam = None
			self._cam1 = None
			self._cam2 = None
			self._all_object_animated_paths = set()
			self._all_camera_data_animated_paths = set()
			self._temp_obj_action_name = None
			self._temp_data_action_name = None
			self._markers_added_by_script = []
			self._total_fcurves_to_bake = 0
			self._generated_objects = [] # Initialize the cleanup list
			self._children_to_process_queue = deque()
			self._duplication_map = {}
			self._total_children_count = 0
			self._children_processed_count = 0
			self._progress_children_processed_count = 0
			self._waste_looper = 0
			self._cached_region = None
			self._cached_views = []

			scene_status.overall_progress = 0.0
			scene_status.progress_stage_INDEX = 0
			scene_status.current_step_text = "Starting..."
			scene_status.current_sub_progress_text = ""
			scene_status.jump_frames_detected_count = 0
			scene_status.total_markers_added = 0
			scene_status.is_running = True
			scene_status.show_results = False

			profiler.init_run()

			# --- Measure redraw time and load learning data ---
			frameNumBefore = scene.frame_float
			start_redraw_time = time.perf_counter()
			bpy.ops.wm.redraw_timer(type='ANIM_STEP', iterations=preferences.test_animSteps)
			self._redraw_time = (time.perf_counter() - start_redraw_time)/preferences.test_animSteps

			scene.frame_float = frameNumBefore

			# --- [FIX] Handle potentially corrupted learning data ---
			if preferences.use_default_coef:
				self._coefficients = profiler.get_default_coefficients()
			else:
				self._coefficients, success = profiler.load_learning_data()
				if not success:
					self.report({'ERROR'}, "Learning data file may be corrupt. Please 'Reset Learning Data' in addon preferences.")

				# Fallback if coefficients are empty
				if not self._coefficients:
					self._coefficients = profiler.get_default_coefficients()


			# --- Gather metrics for the current run ---
			start_frame = scene.frame_start
			end_frame = scene.frame_end

			self._keyframes_to_check = get_all_camera_keyframes(self._original_cam, (start_frame, end_frame))

			self.load_dynamic_weights(context)

			profiler.profiler_begin(self._progress_stage)

			# Check if in camera view and Stage buffer is not set to 0, store and kick out if so, to prevent ncias / fast camera jumping flashing for user comfort.
			if not preferences.stage7_buffer == 0:
				for area in context.screen.areas:
					if area.type == 'VIEW_3D':
						for space in area.spaces:
							if space.type == 'VIEW_3D':
								region_3d = space.region_3d
								if region_3d.view_perspective == 'CAMERA':
									VerboseActive(1) and log_msg(1,"Camera view detected. Kicking user out...")
									region_3d.view_perspective = 'PERSP'  # Kick out to perspective
									self._cached_views.append({'region_3d': region_3d, 'was_in_cam': True})
								else:
									self._cached_views.append({'region_3d': region_3d, 'was_in_cam': False})

			self._timer = wm.event_timer_add(0.01, window=context.window) # Update frequently
			wm.modal_handler_add(self)
			return {'RUNNING_MODAL'}
		except Exception:
			log_msg(10, "An error occurred during AUTO_CUTSMART_OT_operator invoke: {}".format(traceback.format_exc()))

	def finish(self, context):
		try:
			wm = context.window_manager
			scene_status = context.scene.auto_cutsmart_status
			if self._timer:
				wm.event_timer_remove(self._timer)
				self._timer = None

			# Restore views that were in camera perspective
			for view_data in self._cached_views:
				region_3d = view_data.get('region_3d')
				was_in_cam = view_data.get('was_in_cam', False)

				if was_in_cam and region_3d:
					try:
						# Check if the region_3d is still valid.
						is_valid = any(
							space.region_3d == region_3d
							for area in context.screen.areas if area.type == 'VIEW_3D'
							for space in area.spaces if space.type == 'VIEW_3D'
						)

						if is_valid:
							log_msg(1, "Restoring camera view")
							region_3d.view_perspective = 'CAMERA'
						else:
							log_msg(1, "Cached viewport no longer exists. Skipping")
					except ReferenceError:
						log_msg(1, "ReferenceError: Cached viewport no longer exists. Skipping")
					except Exception as e:
						log_msg(1, f"An unexpected error occurred during view restoration: {e}")

			# Clear the cache
			self._cached_views = []

			scene_status.is_running = False
			scene_status.show_results = True
			self.report({'INFO'}, "Camera splitting complete!")
			return {'FINISHED'}
		except Exception:
			log_msg(10, "An error occurred during AUTO_CUTSMART_OT_operator finish: {}".format(traceback.format_exc()))

	def cancel(self, context):
		"""
		A robust cleanup function that attempts to clean up all resources
		even if errors occur during the process.
		"""
		try:
			wm = context.window_manager
			scene = context.scene
			scene_status = scene.auto_cutsmart_status

			# Each cleanup step is wrapped in its own try/except block to ensure
			# that a failure in one step doesn't prevent subsequent steps from running.

			# 1. Stop the modal timer
			try:
				if self._timer:
					wm.event_timer_remove(self._timer)
					self._timer = None
			except Exception as e:
				log_msg(1, f"Error removing modal timer: {e}")

			# 2. Reset scene status flags
			scene_status.is_running = False
			scene_status.show_results = False

			# 3. Clean up all generated objects
			try:
				self.cleanup_generated_objects()
			except Exception as e:
				log_msg(1, f"Error during object cleanup: {e}\n{traceback.format_exc()}")

			# 4. Remove markers added by this script run
			try:
				for marker_name in self._markers_added_by_script:
					if marker_name in scene.timeline_markers:
						scene.timeline_markers.remove(scene.timeline_markers[marker_name])
				VerboseActive(1) and log_msg(1, "Cleaned up script-added markers.")
			except Exception as e:
				log_msg(1, f"Error during marker cleanup: {e}\n{traceback.format_exc()}")

			# 5. Restore original selection if possible
			try:
				if self._original_cam_name and self._original_cam_name in bpy.data.objects:
					bpy.ops.object.select_all(action='DESELECT')
					original_obj = bpy.data.objects.get(self._original_cam_name)
					if original_obj:
						original_obj.select_set(True)
						context.view_layer.objects.active = original_obj
			except (ReferenceError, Exception) as e:
				# ReferenceError can happen if _original_cam is a dangling pointer.
				log_msg(1, f"Could not restore original selection: {e}")

			# 6. Restore 3D views if they were changed
			try:
				for view_data in self._cached_views:
					region_3d = view_data.get('region_3d')
					was_in_cam = view_data.get('was_in_cam', False)
					if was_in_cam and region_3d:
						region_3d.view_perspective = 'CAMERA'
				self._cached_views = []
			except (ReferenceError, Exception) as e:
				log_msg(1, f"Could not restore camera view on cancel: {e}")

			return {'CANCELLED'}
		except Exception:
			log_msg(10, "An error occurred during AUTO_CUTSMART_OT_operator cancel: {}".format(traceback.format_exc()))


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# == Decimate UI Operators ==
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class AddDecimateBlockOperator(bpy.types.Operator):
	"""
	Operator to add a new decimation block to the process chain.
	"""
	bl_idname = "object.add_decimate_block"
	bl_label = "Add Decimate Block"
	bl_options = {'REGISTER', 'UNDO'}
	bl_description = "Add a new F-Curve simplification block to the active camera's process chain"

	decimate_type: bpy.props.EnumProperty(
		name="Decimate Type",
		description="Choose the method for simplifying F-Curves",
		items=[
			('RATIO', "By Ratio", "Simplify F-Curves by keeping only a chosen fraction of keyframes"),
			('ERROR', "By Error Margin", "Simplify F-Curves by removing points that stay within a set error tolerance"),
		]
	)

	@classmethod
	def description(cls, context, properties):
		return description_map.get(properties.decimate_type, "")


	def execute(self, context):
		try:
			# Add a new instance of DecimateBlock to the camera's collection property
			new_block = context.camera.decimate_blocks.add()
			new_block.decimate_type = self.decimate_type

			return {'FINISHED'}
		except Exception:
			log_msg(10, "An error occurred during AddDecimateBlockOperator: {}".format(traceback.format_exc()))

class RemoveDecimateBlockOperator(bpy.types.Operator):
	"""Operator for removing decimation blocks."""
	bl_idname = "object.remove_decimate_block"
	bl_label = "Remove Decimate Block"
	bl_options = {'REGISTER', 'UNDO'}

	index: bpy.props.IntProperty(
		name="Index",
		description="Index of the block to remove from the list."
	)

	def execute(self, context):
		try:
			# Remove the block at the specified index from the collection
			context.camera.decimate_blocks.remove(self.index)
			return {'FINISHED'}
		except Exception:
			log_msg(10, "An error occurred during RemoveDecimateBlockOperator: {}".format(traceback.format_exc()))

class MoveDecimateBlockOperator(bpy.types.Operator):
	"""
	Operator to reorder decimation blocks within the process chain.
	Triggered by the 'Up' and 'Down' arrow buttons.
	"""
	bl_idname = "object.move_decimate_block"
	bl_label = "Move Decimate Block"
	bl_options = {'REGISTER', 'UNDO'}

	index: bpy.props.IntProperty(
		name="Index",
		description="Current index of the block to move."
	)
	direction: bpy.props.EnumProperty(
		name="Direction",
		items=[
			('UP', "Up", "Move the block up"),
			('DOWN', "Down", "Move the block down"),
		]
	)

	@classmethod
	def description(cls, context, properties):
		if properties.direction == 'UP':
			return "Move the block up"
		elif properties.direction == 'DOWN':
			return "Move the block down"
		return

	def execute(self, context):
		try:
			blocks = context.camera.decimate_blocks
			current_index = self.index
			new_index = -1

			if self.direction == 'UP':
				if current_index > 0:
					new_index = current_index - 1
			elif self.direction == 'DOWN':
				if current_index < len(blocks) - 1:
					new_index = current_index + 1

			if new_index != -1:
				blocks.move(current_index, new_index)
			return {'FINISHED'}
		except Exception:
			log_msg(10, "An error occurred during MoveDecimateBlockOperator: {}".format(traceback.format_exc()))


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# == Main Panel UI Operators ==
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class AUTO_CUTSMART_OT_clear_results(bpy.types.Operator):
	"""Operator to dismiss the displayed camera split results."""
	bl_label = "Dismiss Results"
	bl_idname = "camera.clear_split_results"
	bl_description = "Clear results"

	def execute(self, context):
		try:
			scene_status = context.scene.auto_cutsmart_status
			scene_status.show_results = False
			scene_status.jump_frames_detected_count = 0
			scene_status.total_markers_added = 0
			self.report({'INFO'}, "Camera split results dismissed.")
			return {'FINISHED'}
		except Exception:
			log_msg(10, "An error occurred during AUTO_CUTSMART_OT_clear_results: {}".format(traceback.format_exc()))


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# == Addon Preferences UI Operators ==
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class AUTO_CUTSMART_OT_reset_learning_data(bpy.types.Operator):
	"""Reset all stored learning data and coefficients."""
	bl_idname = "camera.reset_learning_data"
	bl_label = "Reset Learning Data"
	bl_description = "Deletes all saved performance data, resetting the progress bar calculation to its default behavior. [This action is PERMANENT!]"

	def execute(self, context):
		# Actual logic to reset learning data
		profiler.reset_learning_data()
		self.report({'INFO'}, "All learned performance data has been reset.")
		return {'FINISHED'}

	def invoke(self, context, event):
		# This triggers Blender's built-in confirmation dialog
		if bpy.app.version >= (4, 0, 0):
			return context.window_manager.invoke_confirm(self, event, title ='Delete Learning Data?', message='Are you sure you want to delete the learning data?\n\nIf you have not backed up the learning .json file,\nthis action is permanent!', icon ='WARNING', confirm_text ='Yes')
		else:
			return context.window_manager.invoke_confirm(self, event)

class REPRINT_LOGS_OT_operator(bpy.types.Operator):
	bl_idname = "camera.reprint_logs"
	bl_label = "Reprint Logs"
	bl_description = "Reprint stored logs based on current verbosity settings"

	def execute(self, context):
		try:
			preferences = bpy.context.preferences.addons[__name__].preferences
			selected_logs = []

			for level, msg in log_storage:
				if VerboseActive(level):
					selected_logs.append(msg)

			log_method = preferences.log_print_method

			if selected_logs:
				selected_logs.insert(0,"\no---==========---o [START OF DEBUG REPRINT REPORT] o---==========---o\n")
				selected_logs.append("\nx---==========---x [END OF DEBUG REPRINT REPORT] x---==========---x\n")

				if log_method == 'INFO':
					for log in selected_logs:
						self.report({'INFO'}, log)
				elif log_method == 'CONSOLE':
					for log in selected_logs:
						print(log)
			else:
				self.report({'INFO'}, "No logs to print based on selected verbosity levels.")

			return {'FINISHED'}
		except Exception:
			log_msg(10, "An error occurred during REPRINT_LOGS_OT_operator: {}".format(traceback.format_exc()))


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# == Error Report Operators ==
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class CS_OT_ConfirmReport(bpy.types.Operator):
	"""Asks the user if they want to save an error report."""
	bl_idname = "auto_cutsmart.confirm_report"
	bl_label = "Submit Anonymous Bug Report?"
	bl_options = {'INTERNAL'}

	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width=500)

	def draw(self, context):
		layout = self.layout

		layout.label(text="Encountered an unexpected and FATAL error.", icon='ERROR')

		col = layout.column()
		col.alert = True
		MainBox = col.box()


		boxA = MainBox.box()
		boxA.scale_y=0.5

		boxA.separator(factor=0.25)
		boxA.label(text="We’re sorry that you’ve encountered an error. To help us fix it, could you")
		boxA.label(text="please submit an anonymous report to our Issue webpage?")
		boxA.separator(factor=0.25)

		boxB=MainBox.box()
		boxB.scale_y=0.5

		boxB.separator(factor=0.25)
		boxB.label(text="In the next window, you can choose what data to include in the report.")
		boxB.label(text="Rest assured, personal data (like your system username and drive letter)")
		boxB.label(text="will be automatically redacted.")
		boxB.label(text="")

		boxB.label(text="If you'd prefer to report the issue later, you can save the log to your")
		boxB.label(text="computer. You can then access the webpage at any time by opening the")
		boxB.label(text="Add-ons Preferences window and clicking the ‘Report a Bug’ button.")
		boxB.separator(factor=0.25)

		boxC = MainBox.box()
		boxC.scale_y=0.5

		boxC.separator(factor=0.25)
		boxC.label(text="Your report is really appreciated and will help us improve the addon.")
		boxC.label(text="Thanks for your support!")
		boxC.separator(factor=0.25)

	def execute(self, context):
		bpy.ops.auto_cutsmart.report_error('INVOKE_DEFAULT')
		return {'FINISHED'}

	def cancel(self, context):
		bpy.ops.auto_cutsmart.submit_report_no('INVOKE_DEFAULT')

class CS_OT_SubmitReportNo(bpy.types.Operator):
	"""Do nothing, just close the dialog"""
	bl_idname = "auto_cutsmart.submit_report_no"
	bl_label = "Cancel Report"

	def execute(self, context):
		self.report({'INFO'}, "Report canceled.")
		return {'CANCELLED'}

class CS_OT_ShowSubmissionLinks(bpy.types.Operator):
	"""Shows the final dialog with links to open GitHub and copy the URL."""
	bl_idname = "auto_cutsmart.show_submission_links"
	bl_label = "Report Saved Successfully"
	bl_options = {'INTERNAL'}

	def invoke(self, context, event):
		return context.window_manager.invoke_props_dialog(self, width=400)

	def draw(self, context):
		layout = self.layout
		col = layout.column()
		col.label(text="Please attach the saved log file to a new issue on GitHub.", icon='INFO')
		col.separator()
		row = col.row(align=True)
		row.scale_y = 1.5
		row.operator("auto_cutsmart.open_url", text="Open GitHub Issues Page", icon='URL').url = bl_info['tracker_url']
		row.operator("auto_cutsmart.copy_url", text="Copy Link", icon='COPYDOWN').url = bl_info['tracker_url']

	def execute(self, context):
		return {'FINISHED'}


class CS_OT_ReportError(bpy.types.Operator, ImportHelper):
	"""Operator to handle file saving and URL opening for error reporting."""
	bl_idname = "auto_cutsmart.report_error"
	bl_label = "Save Error Report"
	filename_ext = ".log"

	filter_glob: bpy.props.StringProperty(
		default="*.log",
		options={'HIDDEN'},
		maxlen=255,
	)

	# New properties for controlling the error report content, now directly on the operator
	report_include_time: bpy.props.BoolProperty(
		name="Include Time",
		description="Includes the specific time and timezone in the report. If disabled, only the date is included.",
		default=True
	)
	report_include_os_details: bpy.props.BoolProperty(
		name="Include Detailed OS Info",
		description="Includes the full OS version number and platform information. If disabled, a general OS name is used (e.g., 'Windows 10').",
		default=True
	)
	report_include_processor: bpy.props.BoolProperty(
		name="Include Processor Details",
		description="Includes the name and details of your system's processor.",
		default=True
	)
	report_include_arch_linkage: bpy.props.BoolProperty(
		name="Include Architecture Linkage",
		description="Includes the system's architecture linkage. If disabled, only the 'bits' are reported.",
		default=True
	)
	report_include_python_path: bpy.props.BoolProperty(
		name="Include Python Executable Path",
		description="Includes the full file path to the Python executable.",
		default=True
	)
	report_include_cwd: bpy.props.BoolProperty(
		name="Include Current Working Directory",
		description="Includes the directory from which Blender was launched.",
		default=True
	)

	def execute(self, context):
		try:
			# The report options are now on the operator itself (self)
			report_content = report_system.generate_report(get_full_log(), get_bl_info(), get_report_id(), self)

			# Save the report to the user's chosen file path
			with open(self.filepath, 'w', encoding='utf-8') as f:
				f.write(report_content)

			self.report({'INFO'}, f"Error report saved to: {self.filepath}")

			# Show the next dialog with links
			bpy.ops.auto_cutsmart.show_submission_links('INVOKE_DEFAULT')

			return {'FINISHED'}
		except Exception as e:
			log_msg(10, f"Failed to save error report: {e}")
			self.report({'ERROR'}, "Failed to save error report. See console for details.")
			return {'CANCELLED'}

	def invoke(self, context, event):
		# Suggest a default filename for the user
		self.filepath = f"CJS_error_report_{get_report_id()}.log"
		# This function now also shows the properties defined on this class
		context.window_manager.fileselect_add(self)
		return {'RUNNING_MODAL'}

	def cancel(self, context):
		bpy.ops.auto_cutsmart.submit_report_no('INVOKE_DEFAULT')

class CS_OT_OpenURL(bpy.types.Operator):
	"""Operator to open a URL in the browser."""
	bl_idname = "auto_cutsmart.open_url"
	bl_label = "Open URL"
	url: bpy.props.StringProperty()

	def execute(self, context):
		try:
			bpy.ops.wm.url_open(url=self.url)
			return {'FINISHED'}
		except Exception:
			self.report({'ERROR'}, "Failed to open URL. Please copy the link and paste it in your browser.")
			return {'CANCELLED'}

class CS_OT_CopyURL(bpy.types.Operator):
	"""Operator to copy a URL to the clipboard."""
	bl_idname = "auto_cutsmart.copy_url"
	bl_label = "Copy URL"
	url: bpy.props.StringProperty()

	def execute(self, context):
		try:
			bpy.context.window_manager.clipboard = self.url
			self.report({'INFO'}, "Link copied to clipboard.")
			return {'FINISHED'}
		except Exception as e:
			self.report({'ERROR'}, f"Failed to copy link: {e}")
			return {'CANCELLED'}

class CS_OT_Self_ReportError(bpy.types.Operator):
	bl_idname = "auto_cutsmart.self_report_error"
	bl_label = "Report Critical Error"

	def execute(self, context):
		self.report({'ERROR'}, "[FATAL] A critical error has occurred. See console for details")
		return {'CANCELLED'}


# --------------------------------------------------------------------------------------------------------------------------------------
# --- Panels / Menus --- #
# --------------------------------------------------------------------------------------------------------------------------------------

#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# == M A I N   P A N E L ==
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# == MAIN PANEL ==
class AUTO_CUTSMART_PT_main_panel(bpy.types.Panel):
	"""Creates a Panel in the object data properties for cameras"""
	bl_label = "Auto CutSmart – Seamless Jump Cuts"
	bl_idname = "AUTO_CUTSMART_PT_main_panel"
	bl_space_type = 'PROPERTIES'
	bl_region_type = 'WINDOW'
	bl_context = 'data'
	bl_category = 'Camera Tools'
	bl_options = {'DEFAULT_CLOSED'}

	@classmethod
	def poll(cls, context):
		obj = context.object
		return obj is not None and obj.type == 'CAMERA'

	def draw(self, context):
		layout = self.layout
		selected_obj = context.object
		scene_status = context.scene.auto_cutsmart_status

		if scene_status.is_running:
			box = layout.box()
			col = box.column(align=True)

			icon_use = PROCESS_STAGES_ICONS[scene_status.progress_stage_INDEX]

			col.label(text=scene_status.current_step_text, icon = icon_use)
			col.label(text=scene_status.current_sub_progress_text, icon = 'BLANK1')
			col.separator()

			# Dynamic progress bar
			panel_width = context.region.width
			avg_char_width = 7 * context.preferences.view.ui_scale
			text_label_estimate_chars = 20
			available_bar_chars = int((panel_width - (text_label_estimate_chars * avg_char_width) - 20) / avg_char_width)
			available_bar_chars = max(10, min(available_bar_chars, 50))

			filled_blocks = int(scene_status.overall_progress / 100.0 * available_bar_chars)
			empty_blocks = available_bar_chars - filled_blocks

			progress_bar_str = f"[{BLACK_SQUARE * filled_blocks}{WHITE_SQUARE * empty_blocks}]"

			percentage_text = f"Processing: {int(scene_status.overall_progress)}%"

			row = col.row(align=True)
			row.label(text=percentage_text)
			row = col.row(align=True)
			row.label(text=progress_bar_str)
			col.separator()

			col.emboss = 'NONE'
			col.alert = True
			col.operator(AUTO_CUTSMART_OT_operator.bl_idname, text="← Press Esc to cancel", icon='CANCEL', emboss = False)

		elif scene_status.show_results:
			box = layout.box()
			col = box.column(align=True)

			col.separator(factor = 0.5)
			row = col.row(align=True)
			row.label(text=f"Operation Complete!", icon = 'KEYTYPE_JITTER_VEC')

			row.operator(AUTO_CUTSMART_OT_clear_results.bl_idname, text="", icon='X')

			col.label(text=f"Detected Jump Frames: {scene_status.jump_frames_detected_count}", icon = 'INFO')

			col.separator(factor = 1)

			if selected_obj and selected_obj.type == 'CAMERA':
				col.operator(AUTO_CUTSMART_OT_operator.bl_idname, text=f"Split animation of: {selected_obj.name}", icon='SEQ_STRIP_DUPLICATE')
			else:
				layout.label(text="Select a Camera with animation to Split")

		else:
			if selected_obj and selected_obj.type == 'CAMERA':
				box = layout.box()
				col = box.column()
				col.label(text=f"Split animation of: {selected_obj.name}")
				col.operator(AUTO_CUTSMART_OT_operator.bl_idname, text=f"Split animation of: {selected_obj.name}", icon='UNLINKED')
			else:
				layout.label(text="Select a Camera with animation to Split")

# == Jump Threshold PANEL ==
class AUTO_CUTSMART_PT_jump_thresholds(bpy.types.Panel):
	bl_label = "Jump Cut Detection Sensitivity"
	bl_idname = "AUTO_CUTSMART_PT_jump_thresholds"
	bl_space_type = 'PROPERTIES'
	bl_region_type = 'WINDOW'
	bl_context = 'data'
	bl_parent_id = "AUTO_CUTSMART_PT_main_panel"
	bl_options = {'DEFAULT_CLOSED'}
	bl_icon = 'CANCEL'

	@classmethod
	def poll(cls, context):
		obj = context.object
		scene_status = context.scene.auto_cutsmart_status
		return obj is not None and obj.type == 'CAMERA' and not scene_status.is_running

	def draw(self, context):
		layout = self.layout
		layout.use_property_split = True
		settings = context.object.data.auto_cutsmart_settings
		camera_data = context.object.data
		render_engine = context.scene.render.engine

		obj = context.object
		layout.active = has_animation(obj)

		col = layout.column(align=True)
		col.prop(settings, "location_threshold")
		col.prop(settings, "rotation_threshold")

		if camera_data.type == 'PERSP' or \
		   (camera_data.type == 'PANO' and render_engine != 'CYCLES'):
			col.prop(settings, "lens_threshold")

		if camera_data.type == 'ORTHO':
			col.prop(settings, "ortho_scale_threshold")

# == Extra Jump Threshold PANEL ==
class AUTO_CUTSMART_PT_more_thresholds(bpy.types.Panel):
	bl_label = "More Camera Thresholds"
	bl_idname = "AUTO_CUTSMART_PT_more_thresholds"
	bl_space_type = 'PROPERTIES'
	bl_region_type = 'WINDOW'
	bl_context = 'data'
	bl_parent_id = "AUTO_CUTSMART_PT_jump_thresholds"
	bl_options = {'DEFAULT_CLOSED'}

	@classmethod
	def poll(cls, context):
		obj = context.object
		scene_status = context.scene.auto_cutsmart_status
		return obj is not None and obj.type == 'CAMERA' and not scene_status.is_running

	def draw(self, context):
		layout = self.layout
		layout.use_property_split = True
		settings = context.object.data.auto_cutsmart_settings
		camera_data = context.object.data
		render_engine = context.scene.render.engine

		obj = context.object
		layout.active = has_animation(obj)

		col = layout.column(align=True)

		allowed_pano_types = {"EQUIRECTANGULAR", "FISHEYE_EQUIDISTANT", "FISHEYE_LENS_POLYNOMIAL", "FISHEYE_EQUISOLID"}

		if camera_data.type == 'PANO' and render_engine == 'CYCLES':
			pano_type = camera_data.panorama_type
			if pano_type == 'FISHEYE_EQUIDISTANT':
				col.prop(settings, "fisheye_fov_threshold")

			elif pano_type == 'FISHEYE_EQUISOLID':
				col.prop(settings, "fisheye_lens_threshold")
				col.prop(settings, "fisheye_fov_threshold")

			elif pano_type == 'EQUIRECTANGULAR':
				sub = col.column(align=True)
				sub.separator()
				sub.prop(settings, "latitude_min_threshold", text="Latitude Min")
				sub.prop(settings, "latitude_max_threshold", text="Max")
				sub.separator()
				sub.prop(settings, "longitude_min_threshold", text="Longitude Min")
				sub.prop(settings, "longitude_max_threshold", text="Max")

			elif pano_type == 'FISHEYE_LENS_POLYNOMIAL':
				col.prop(settings, "fisheye_fov_threshold")
				col.prop(settings, "fisheye_polynomial_k0_threshold", text="K0")
				col.prop(settings, "fisheye_polynomial_k1_threshold", text="K1")
				col.prop(settings, "fisheye_polynomial_k2_threshold", text="K2")
				col.prop(settings, "fisheye_polynomial_k3_threshold", text="K3")
				col.prop(settings, "fisheye_polynomial_k4_threshold", text="K4")

			if pano_type in allowed_pano_types:
				col.separator(factor=1.0)

		col = layout.column(align=True)
		col.prop(settings, "shift_x_threshold")
		col.prop(settings, "shift_y_threshold")

		col.separator(factor=0.5)
		col = layout.column(align=True)

		if camera_data.sensor_fit == 'AUTO':
			col.prop(settings, "sensor_width_threshold", text ="Sensor Size")

		else:
			col.active = camera_data.sensor_fit == 'HORIZONTAL'
			col.prop(settings, "sensor_width_threshold")

			col = layout.column(align=True)
			col.active = camera_data.sensor_fit == 'VERTICAL'
			col.prop(settings, "sensor_height_threshold")

# == Naming New Camera PANEL ==
class AUTO_CUTSMART_PT_naming_options(bpy.types.Panel):
	bl_label = "Duplicated Camera Naming"
	bl_idname = "AUTO_CUTSMART_PT_naming_options"
	bl_space_type = 'PROPERTIES'
	bl_region_type = 'WINDOW'
	bl_context = 'data'
	bl_parent_id = "AUTO_CUTSMART_PT_main_panel"
	bl_options = {'DEFAULT_CLOSED'}

	@classmethod
	def poll(cls, context):
		obj = context.object
		scene_status = context.scene.auto_cutsmart_status
		return obj is not None and obj.type == 'CAMERA' and not scene_status.is_running

	def draw(self, context):
		layout = self.layout
		layout.use_property_split = True
		settings = context.object.data.auto_cutsmart_settings

		obj = context.object
		layout.active = has_animation(obj)

		col = layout.column()
		col.prop(settings, "custom_prefix")
		col.prop(settings, "suffix_type")

# == Decimate PANEL ==
class AUTO_CUTSMART_PT_decimate_process_panel(bpy.types.Panel):
	"""
	Custom panel for the Interactive Decimate Process for F-curves.
	"""
	bl_label = "Interactive F-Curve Decimation"
	bl_idname = "AUTO_CUTSMART_PT_decimate_process_panel"
	bl_space_type = 'PROPERTIES'
	bl_region_type = 'WINDOW'
	bl_context = 'data' # Appears in object data properties
	bl_parent_id = "AUTO_CUTSMART_PT_main_panel" # Child of the main camera split panel
	bl_options = {'DEFAULT_CLOSED'} # Collapsible by default

	@classmethod
	def poll(cls, context):
		obj = context.object
		# Only show if a camera object is selected and not running the main split operation AND Keep_Bake_Frames is set to True
		preferences = bpy.context.preferences.addons[__name__].preferences
		return obj is not None and obj.type == 'CAMERA' and not context.scene.auto_cutsmart_status.is_running and preferences.Keep_Bake_Frames

	def draw(self, context):
		layout = self.layout
		obj = context.object
		layout.active = has_animation(obj)

		row = layout.row()
		row.menu(DecimateOptionsMenu.bl_idname, text="Add Decimate Step", icon='ADD')

		main_container_box = layout.box()

		camera = context.camera
		if camera.decimate_blocks:
			for i, block in enumerate(camera.decimate_blocks):
				individual_block_box = main_container_box.box()
				row = individual_block_box.row(align=True)

				col = row.column(align=True)

				up_button_row = col.row(align=True)
				op_up = up_button_row.operator(MoveDecimateBlockOperator.bl_idname, text="", icon='TRIA_UP')
				op_up.index = i
				op_up.direction = 'UP'
				up_button_row.enabled = (i > 0)

				down_button_row = col.row(align=True)
				op_down = down_button_row.operator(MoveDecimateBlockOperator.bl_idname, text="", icon='TRIA_DOWN')
				op_down.index = i
				op_down.direction = 'DOWN'
				down_button_row.enabled = (i < len(camera.decimate_blocks) - 1)

				if block.decimate_type == 'RATIO':
					row.label(text="By Ratio:")
					row.prop(block, "factor", text="Factor")
				elif block.decimate_type == 'ERROR':
					row.label(text="By Error Margin:")
					row.prop(block, "error_margin", text="Error")

				op_remove = row.operator(RemoveDecimateBlockOperator.bl_idname, text="", icon='X')
				op_remove.index = i
		else:
			main_container_box.label(text="Click 'Add Decimate Step' to begin.")


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# == Decimate Menu Items ==
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

class DecimateOptionsMenu(bpy.types.Menu):
	"""
	Menu that appears when the 'Add Decimate Step' button is pressed.
	Offers choices for the type of decimation block to add.
	"""
	bl_label = "Decimate Options"
	bl_idname = "OBJECT_MT_decimate_options_menu"
	bl_description = "Add a new F-Curve simplification block for the current camera"


	def draw(self, context):
		layout = self.layout
		layout.operator(AddDecimateBlockOperator.bl_idname, text="By Ratio").decimate_type = 'RATIO'
		layout.operator(AddDecimateBlockOperator.bl_idname, text="By Error Margin").decimate_type = 'ERROR'


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# == ADDONS PREFERENCES PANEL ==
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Set custom Motionblur detection description before class registration:
set_motionblur_keyframes_desc = "Automatically add keyframes to the scene’s motion blur position setting at detected jump cuts" if bpy.app.version >= (4, 2, 0) else "Automatically add keyframes to the scene’s motion blur position setting at detected jump cuts (Only works in Cycles)"
version_check = bpy.app.version >= (4, 2, 0)

# == Constants For PREFERENCES CLASS ==
_cached_weights = None
_needs_refresh = True


# Helper Functions For PREFERENCES CLASS #
def update_show_weights(self, context):
	"""This function is called when the 'show_dynamic_weights' property changes"""
	try:
		global _needs_refresh
		_needs_refresh = True
	except Exception:
		log_msg(10, "An error occurred during update_show_weights: {}".format(traceback.format_exc()))

def recalc_weights(context):
	try:
		global _cached_weights, _needs_refresh
		preferences = bpy.context.preferences.addons[__name__].preferences

		scene = context.scene
		camera_obj = context.object
		learning_data, _ = profiler.load_learning_data()
		coefficients = learning_data.get("coefficients", profiler.get_default_coefficients())

		frameNumBefore = scene.frame_float
		start_redraw_time = time.perf_counter()
		bpy.ops.wm.redraw_timer(type='ANIM_STEP', iterations=preferences.test_animSteps)
		_redraw_time = (time.perf_counter() - start_redraw_time)/preferences.test_animSteps

		scene.frame_float = frameNumBefore

		_cached_weights = calculate_dynamic_weights(context, camera_obj, coefficients, _redraw_time)
		_needs_refresh = False
	except Exception:
		log_msg(10, "An error occurred during recalc_weights: {}".format(traceback.format_exc()))


# == Main PREFERENCES PANEL ==
class AUTO_CUTSMART_ADDON_Preferences(bpy.types.AddonPreferences):
	bl_idname = __name__


	set_motionblur_keyframes: bpy.props.BoolProperty(
		name="Set Scene Motionblur Keyframes",
		description=set_motionblur_keyframes_desc,
		default=True
	)

	Keep_Bake_Frames: bpy.props.BoolProperty(
		name="Keep Bake Frames",
		description="Duplicated cameras will retain their baked keyframes instead of being resampled. Enables F-Curve decimation options",
		default=False
	)

	Copy_Camera_Children: bpy.props.BoolProperty(
		name="Copy Child Hierarchy",
		description="Also duplicate any child objects of the camera",
		default=False
	)

	#Show Extra Weight Options

	keep_learning: bpy.props.BoolProperty(
		name="Keep Learning",
		description="Enable to continuously update the learning data file after each run. Disable to use the current learned data without further updates",
		default=False
	)

	use_default_coef: bpy.props.BoolProperty(
		name="Use Default Progress Calculation Weights",
		description="Enable to use the default Calculation Stage Progress Weights that is used to calculate how long each stage might take for the overall progress bar",
		default=True
	)

	only_record_run: bpy.props.BoolProperty(
		name="Only record run statistics",
		description="Enable to only record the run statistics to run history, skipping the recalculation of the stage weights coefficients",
		default=False
	)

	max_run_history: bpy.props.IntProperty(
		name="Max number of stored historical runs",
		description="Limit the number of historical runs to avoid a bloated file (Set to 0 for Infinite Stored Runs)",
		default=0,
		min = 0
	)

	test_animSteps: bpy.props.IntProperty(
		name="Number of animation step iteration",
		description="The number of animation step iterations to perform to calculate the stages weight using the variable redraw time",
		default=1,
		min = 1,
		soft_max=10
	)

	show_dynamic_weights: bpy.props.BoolProperty(
		name="Show Stage Weights",
		description="Display calculated stage weights values of each processing stage contributes to the overall progress bar. This is mainly for diagnostics",
		default=False,
		update=update_show_weights
	)

	# Stage buffering START

	stage1_buffer: bpy.props.IntProperty(
		name="Stage 1 Buffer",
		description="Number of Markers to buffer for 'Clearing existing data'. Set to 0 to disable",
		min=0, default=0
	)

	stage2_buffer: bpy.props.IntProperty(
		name="Stage 2 Buffer",
		description="Number of Child Objects to buffer for 'Duplicating cameras'. Set to 0 to disable",
		min=0, default=0
	)

	stage3_buffer: bpy.props.IntProperty(
		name="Stage 3 Buffer",
		description="Number of Frames to buffer for 'Analyzing camera animation for jumps'. Set to 0 to disable",
		min=0, default=0
	)
	stage4_buffer: bpy.props.IntProperty(
		name="Stage 4 Buffer",
		description="Number of F-Curves to buffer for 'Baking Keyframes'. Set to 0 to disable",
		min=0, default=0
	)
	stage5_buffer: bpy.props.IntProperty(
		name="Stage 5 Buffer",
		description="Number of F-Curves to buffer for 'Splitting and assigning animation chunks'. Set to 0 to disable",
		min=0, default=0
	)
	stage6_buffer: bpy.props.IntProperty(
		name="Stage 6 Buffer",
		description="Number of Segments to buffer for 'Modifying F-curves'. Set to 0 to disable",
		min=0, default=0
	)
	stage7_buffer: bpy.props.IntProperty(
		name="Stage 7 Buffer",
		description="Number of Markers to buffer for 'Adding timeline markers'. Set to 0 to disable",
		min=0, default=0
	)
	stage8_buffer: bpy.props.IntProperty(
		name="Stage 8 Buffer",
		description="Number of Segments to buffer for 'Setting Scene Motion Blur Keyframes'. Set to 0 to disable",
		min=0, default=0
	)
	# Stage buffering END

	# Toggle for hiding non Buffer Stages
	hide_NonBuffer_Stages: bpy.props.BoolProperty(
		name="Hide Non-Bufferable Stages",
		description="Hide stages without adjustable buffers. This makes the UI more compact and easier to read",
		default=True
	)

	# Toggle for displaying stage buffers
	show_stage_buffers_expanded: bpy.props.BoolProperty(
		name="Stage Buffers",
		description="Show advanced buffer settings for all stages. \n⚠️ Only change these values if Blender crashes or freezes during processing. Lower buffers may improve stability but slow performance. Setting a buffer to 0 disables buffering",
		default=False
	)

	# Verbose levels
	light_Verbose: bpy.props.BoolProperty(
		name="Level 2 Logging (High Verbose)",
		description="Print detailed verbose information to console",
		default=False
	)

	high_Verbose: bpy.props.BoolProperty(
		name="Level 1 Logging (Light Verbose)",
		description="Print light verbose information to console",
		default=False
	)

	jump_debug_output: bpy.props.BoolProperty(
		name="Enable Jump Detection Debug Output",
		description="Print highly detailed debug information about jump detection to console",
		default=False
	)

	MajorError_Logging: bpy.props.BoolProperty(
		name="FATAL Error Reporting",
		description="In the event of a FATAL Error, A popup will ask you if you want to send a Error report log",
		default=True
	)

	# Log print method selection options
	log_print_method: bpy.props.EnumProperty(
		name="Log Print Method",
		description="Choose where to print logs when reprinting",
		items=[
			('INFO', "Info Panel", "Print to Blender's Info Panel"),
			('CONSOLE', "Console", "Print to the System Console")
		],
		default='CONSOLE',
	)

	active_tab: bpy.props.EnumProperty(
		items=[
			('MISC', "Misc Options", "Miscellaneous settings for the addon"),
			('DEBUG', "Debug Options", "Settings related to debugging and logging"),
		],
		default='MISC',
	)

	debug_Print_Misc_expanded: bpy.props.BoolProperty(
		name="Log Print Options",
		description="Show Options / Button to reprint stored logs from last Camera Split run",
		default=False
	)

	debug_Logging_Level_expanded: bpy.props.BoolProperty(
		name="Log Debugging Level Selection",
		description="Select what level/s of logging should be stored and printed",
		default=False
	)

	Misc_StageWeights_Options_expanded: bpy.props.BoolProperty(
		name="Show Extra Options for Stage Weights",
		description="Show additional options for viewing (if Blender's Debug Menu is set) or resetting the calculated weights of each Stage for calculating the progress bar progression UI",
		default=False
	)

	def draw(self, context):
		global _cached_weights, _needs_refresh
		layout = self.layout
		layout.label(text="Camera Jump Cut Split Preferences")

		row = layout.row(align=True)
		row.prop(self, "active_tab", expand=True)

		if self.active_tab == 'MISC': # Misc Options
			col = layout.column(align=True)
			col.label(text="Miscellaneous Options", icon='SETTINGS')
			col.separator()
			col.prop(self, "set_motionblur_keyframes")
			col.prop(self, "Keep_Bake_Frames")
			col.prop(self,"Copy_Camera_Children")

			if version_check:
				col.separator(factor=2.0, type= 'LINE')
			else:  # Old Blender version compatibility
				col.separator(factor=2.0)

			 # Stage Weights Option
			if self.Misc_StageWeights_Options_expanded:
				layout = layout.box()
			layout.prop(self, "Misc_StageWeights_Options_expanded", icon='DISCLOSURE_TRI_DOWN' if self.Misc_StageWeights_Options_expanded else 'DISCLOSURE_TRI_RIGHT')
			if self.Misc_StageWeights_Options_expanded:

				Display_DEBUG = bpy.app.debug_value == 20000

				row = layout.row(align=True)
				col = row.column()
				col.label(text="Stage Progress Bar Calculation Weight Options:", icon='WPAINT_HLT')

				col.separator(factor=0.5)

				HistRunGrid = col.grid_flow(row_major=True, columns=1, align=True)
				HistRunGrid.alignment='LEFT'
				HistRunGrid.label(text="Max number of stored historical runs")
				HistRunGrid.prop(self, "max_run_history", text='')
				HistRunGrid.separator(factor=2)

				col.prop(self, "keep_learning", text="Keep Learning", toggle=False) #colSplit.prop(self, "keep_learning", text="Keep Learning", icon = 'CHECKBOX_HLT' if self.keep_learning else 'CHECKBOX_DEHLT', toggle=False)
				col.prop(self, "use_default_coef")

				if not Display_DEBUG:
					row = layout.row(align=True)
					col = row.column()
					col.scale_y = 1.5

				if version_check:
					col.separator(factor=0.75 if Display_DEBUG else 0.5, type= 'LINE' if Display_DEBUG else 'SPACE')
				else:  # Old Blender version compatibility
					col.separator(factor=0.75 if Display_DEBUG else 0.5)
				col.operator("camera.reset_learning_data", text="Reset Learning Data", icon='FILE_REFRESH')

				col.separator(factor=0.5 if Display_DEBUG else 0.8)


				# Only show the "Show Stage Weights" option if debug value is set
				if Display_DEBUG:
					col.prop(self, "show_dynamic_weights", icon='HIDE_OFF' if self.show_dynamic_weights else 'HIDE_ON')
					col.separator(factor=0.75)

					col.prop(self, "only_record_run")

					col.prop(self, "test_animSteps")

					col2 = row.column()
					col2_EMPTY = col2.column()
					col2_EMPTY.separator(factor=0.5)
					col2_EMPTY.separator_spacer()
					col2_EMPTY.separator_spacer()
					col2_EMPTY.separator_spacer()
					col2_EMPTY.separator_spacer()
					col2_EMPTY.separator(factor=0.75)
					col2_EMPTY.separator_spacer()

					if self.show_dynamic_weights:
						camera_obj = context.object

						if _needs_refresh or not (camera_obj and camera_obj.type == 'CAMERA' and has_animation(camera_obj)):
							sub_row=col2.row().box()
							sub_row.scale_x = 1.02

						if not (camera_obj and camera_obj.type == 'CAMERA' and has_animation(camera_obj)):
							sub_row.label(text="Predicted Stage Weights", icon='PREFERENCES')
							sub_row.label(text="N/A: No animated camera selected.", icon='INFO')
						else:
							# Check if we need to recalculate the weights
							if _needs_refresh:
								sub_row.label(text="Predicted Stage Weights", icon='PREFERENCES')
								sub_row.label(text="\nLOADING...")
								bpy.app.timers.register(lambda: recalc_weights(context), first_interval=0.01) #This caches the weights after the text label changes to 'LOADING..."

							# Display the cached weights
							elif _cached_weights:
								sub_box = col2.box()
								sub_box.scale_x = 0.5
								sub_box.label(text="Predicted Stage Weights", icon='PREFERENCES')
								for stage_name, weight_percent in _cached_weights:
									row = sub_box.row()
									row.label(text=f"{stage_name}:")
									row.label(text=f"{weight_percent:.2f}%")
					else:
						sub_row=col2.row().box()
						sub_row.label(text="\n(No weights to display)", icon ='CANCEL')
						sub_row.label(text="")
						sub_row.scale_x = 1.02

			# Stage buffers
			layout = self.layout
			if self.show_stage_buffers_expanded:
				layout = layout.box()
			layout.prop(self, "show_stage_buffers_expanded", icon='DISCLOSURE_TRI_DOWN' if self.show_stage_buffers_expanded else 'DISCLOSURE_TRI_RIGHT')
			if self.show_stage_buffers_expanded:
				box = layout.box()
				col = box.column(align=False)
				col.label(text="Stage Buffering", icon='TIME')

				if bpy.app.debug_value == 20000:

					col.prop(self, "hide_NonBuffer_Stages") # Hide Stages that dont have any buffer options
					col.separator()

				not self.hide_NonBuffer_Stages and col.box().label(text="Stage 0 Buffer | No Buffer Needed") #null
				col.prop(self, "stage1_buffer")
				row = col.row()
				row.active = self.Copy_Camera_Children # Only enable if copying children
				row.prop(self, "stage2_buffer")
				col.prop(self, "stage3_buffer")
				col.prop(self, "stage4_buffer")
				col.prop(self, "stage5_buffer")
				col.prop(self, "stage6_buffer")
				col.prop(self, "stage7_buffer")
				row = col.row()
				row.active = self.set_motionblur_keyframes # Only enable if Set Scene Motionblur Keyframes
				row.prop(self, "stage8_buffer")
				not self.hide_NonBuffer_Stages and col.box().label(text = "Stage 9 Buffer | No Buffer Needed") #null



		elif self.active_tab == 'DEBUG': # Debug Options

			col = layout.column(align=True)
			col.label(text="Debug Options", icon='INFO')
			col.separator()
			col.prop(self, "jump_debug_output")
			col.prop(self, "MajorError_Logging")
			if version_check:
				col.separator(factor=2.0, type= 'LINE')
			else:  # Old Blender version compatibility
				col.separator(factor=2.0)

			# Verbose Levels
			if bpy.app.debug_value == 20000:
				if self.debug_Logging_Level_expanded:
					layout = layout.box()
				layout.prop(self, "debug_Logging_Level_expanded", text="Log Debugging Level Selection", icon='DISCLOSURE_TRI_DOWN' if self.debug_Logging_Level_expanded else 'DISCLOSURE_TRI_RIGHT')
				if self.debug_Logging_Level_expanded:
					col = layout.column(align=True)
					col.label(text="Choose the level of Verbose Logging", icon='TOOL_SETTINGS')
					col.prop(self, "high_Verbose")
					col.prop(self, "light_Verbose")

			# Print Method Options
			layout = self.layout
			if self.debug_Print_Misc_expanded:
				layout = layout.box()
			layout.prop(self, "debug_Print_Misc_expanded", text="Log Print Options", icon='DISCLOSURE_TRI_DOWN' if self.debug_Print_Misc_expanded else 'DISCLOSURE_TRI_RIGHT')
			if self.debug_Print_Misc_expanded:
				row = layout.row(align=True)
				row.label(text="Logging Options:", icon='TEXT') #or MENU_PANEL
				row = layout.row(align=True)
				# row.separator()
				col1 = row.column(align=True)
				col1.prop(self, "log_print_method")
				row.separator()
				col2 = row.column(align=True)
				col2.operator("camera.reprint_logs", text="Reprint Stored Logs", icon='CONSOLE')
				col2.scale_x = 2.0


# -------------------------------------------------------------------
# --- Registration --- #
# -------------------------------------------------------------------

classes = (
	CameraSplitSettings,
	CameraSplitSceneStatus,
	CameraSplitStageWeight,
	AUTO_CUTSMART_OT_operator,
	AUTO_CUTSMART_OT_clear_results,
	AUTO_CUTSMART_OT_reset_learning_data,
	AUTO_CUTSMART_PT_main_panel,
	AUTO_CUTSMART_PT_jump_thresholds,
	AUTO_CUTSMART_PT_more_thresholds,
	AUTO_CUTSMART_PT_naming_options,
	DecimateBlock,
	AddDecimateBlockOperator,
	DecimateOptionsMenu,
	RemoveDecimateBlockOperator,
	MoveDecimateBlockOperator,
	AUTO_CUTSMART_PT_decimate_process_panel,
	AUTO_CUTSMART_ADDON_Preferences,
	REPRINT_LOGS_OT_operator,
	CS_OT_ConfirmReport,
	CS_OT_ShowSubmissionLinks,
	CS_OT_ReportError,
	CS_OT_OpenURL,
	CS_OT_CopyURL,
	CS_OT_SubmitReportNo,
	CS_OT_Self_ReportError
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)

	# Register custom properties on Camera and Scene types
	bpy.types.Camera.auto_cutsmart_settings = bpy.props.PointerProperty(type=CameraSplitSettings)
	bpy.types.Scene.auto_cutsmart_status = bpy.props.PointerProperty(type=CameraSplitSceneStatus)
	bpy.types.Camera.decimate_blocks = bpy.props.CollectionProperty(type=DecimateBlock)
	bpy.types.Scene.auto_cutsmart_dynamic_weights = bpy.props.CollectionProperty(type=CameraSplitStageWeight)

	# --- Load default learning data if none exists ---
	addon_path = os.path.dirname(__file__)
	default_data_filename = "auto_cutsmart_learning.json"
	source_path = os.path.join(addon_path, "LoadData", default_data_filename)
	dest_path = profiler.get_storage_path()

	if not os.path.exists(dest_path):
		if os.path.exists(source_path):
			try:
				dest_dir = os.path.dirname(dest_path)
				os.makedirs(dest_dir, exist_ok=True)
				shutil.copy2(source_path, dest_path)
				print(f"'{default_data_filename}' not found. Copied default learning data to user config.")
			except Exception as e:
				print(f"Error copying default learning data: {e}")
		else:
			print(f"Warning: Default learning data not found at '{source_path}'. A new file will be created on the first run.")

	profiler.initialize_profiler()
	render_panel.register()
	print("Registered Auto CutSmart - Camera Splitter addon")

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
	render_panel.unregister()

	# Unregister custom properties
	if hasattr(bpy.types.Camera, 'auto_cutsmart_settings'):
		del bpy.types.Camera.auto_cutsmart_settings
	if hasattr(bpy.types.Scene, 'auto_cutsmart_status'):
		del bpy.types.Scene.auto_cutsmart_status
	if hasattr(bpy.types.Camera, 'decimate_blocks'):
		del bpy.types.Camera.decimate_blocks
	if hasattr(bpy.types.Scene, 'auto_cutsmart_dynamic_weights'):
		del bpy.types.Scene.auto_cutsmart_dynamic_weights
