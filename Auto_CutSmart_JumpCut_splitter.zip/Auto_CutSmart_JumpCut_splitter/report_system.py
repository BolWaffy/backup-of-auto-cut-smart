# ===============================
# FILE: report_system.py
# (Custom error reporting for the addon)
# ===============================
import bpy
import platform
import sys
import time
from datetime import datetime

import traceback
import importlib
import re
import os

def redact_blend_path(tb: str) -> str:
	"""
	Redacts any .blend path (and following subpaths).
	Collapses to OS-specific placeholder:
	  - Windows -> DRIVE:\RedactBlendPath\Redact.blend
	  - Linux/macOS -> /HOME/REDACTED/RedactBlendPath/Redact.blend
	"""
	tb_norm = tb.replace("\\", "/")
	system = platform.system()

	# Check if the path has already been redacted (with DRIVE:) and avoid replacing again.
	if system == "Windows":
		replacement = "DRIVE:/RedactBlendPath/Redact.blend"
	else:  # Linux + Darwin(macOS)
		replacement = "/HOME/REDACTED/RedactBlendPath/Redact.blend"

	# Replace anything leading up to ".blend" with redacted path
	tb_norm = re.sub(
		r'(DRIVE:/|/HOME/REDACTED/|[A-Za-z]?:/)[^"\n]*?\.blend', 
		replacement,
		tb_norm
	)

	# Restore slash style 
	if system == "Windows" and "\\" in tb:
		return tb_norm.replace("/", "\\")
	
	return tb_norm

def redact_all_user_paths(tb: str) -> str:
	"""
	Redacts all user-specific directories in addon/system paths and within
	error messages. Preserves OS identity in formatting.
	"""
	system = platform.system()

	if system == "Windows":
		tb = tb.replace("\\\\", "\\")
		
		# Step 1: Redact the drive letter (C:, D:, etc.) to 'DRIVE:'
		tb = re.sub(
			r'([A-Za-z]):\\',
			r'DRIVE:\\',
			tb)
		
		# Step 2: Redact the user's name in the 'Users' folder
		tb = re.sub(
			r'DRIVE:\\Users\\[^\\]+',
			r'DRIVE:\\Users\\REDACT',
			tb)
		
		
	elif system == "Linux":
		# Redact paths like /home/username/...
		tb = re.sub(
			r'(/home/[^/]+)',
			r'/HOME/REDACTED',
			tb)
	elif system == "Darwin":  # macOS
		# Redact paths like /Users/username/...
		tb = re.sub(
			r'(/Users/[^/]+)',
			r'/HOME/REDACTED',
			tb)

	return tb

def redact_traceback(tb: str) -> str:
	"""
	Redacts sensitive paths from a traceback string:
	- Collapses .blend paths
	- Collapses user home dirs in addon/system paths
	- Redacts file paths in the error message
	"""
	tb = redact_all_user_paths(tb)
	tb = redact_blend_path(tb)

	return tb

def generate_report(log_storage, bl_info, report_id, report_options):
	"""
	Generates a formatted error report from the log storage and addon data.
	
	Args:
		log_storage (list): A list of tuples containing log messages.
		bl_info (dict): The addon's bl_info dictionary.
		report_id (str): The unique ID for the report session.
		report_options (bpy.types.AddonPreferences): The addon preferences object containing privacy options.
	"""
	report = []
	
# -- TIME CACULATION -- #
	local_time = datetime.fromtimestamp(time.time())

	# --- Section 1: Payload ---
	report.append("============--- [Report Payload] ---============")
	
	# Conditionally add time and timezone based on user's preference
	if report_options.report_include_time:
		local_tz_name = time.tzname[0] if time.localtime().tm_isdst == 0 else time.tzname[1]
		utc_offset_str = f"UTC{time.timezone // 3600:+03d}:00" 
		report.append(f"Timestamp:\n    Date: {local_time.strftime('%m/%d/%Y')}\n    Time: {local_time.strftime('%I:%M:%S %p')}\n    Timezone: {local_tz_name} [{utc_offset_str}]")
	else:
		report.append(f"Timestamp:\n    Date: {local_time.strftime('%m/%d/%Y')}")

	report.append(f"report_id: {report_id}")
	
	report.append("\n--- Blender Information ---")
	report.append(f"Blender Version: {bpy.app.version_string}")
	report.append(f"Blender Build Date: {bpy.app.build_date}")
	report.append(f"Addon Version: {'.'.join(map(str, bl_info.get('version', 'N/A')))}")

	# --- System Information ---
	report.append("\n--- System Information ---")

	# Conditionally add detailed OS information
	if report_options.report_include_os_details:
		report.append(f"Operating System: {platform.system()} {platform.release()} ({platform.version()})")
	else:
		os_name = platform.system()
		os_display = os_name # Default display
		if os_name == "Windows":
			# Use the Windows version number to distinguish between 10 and 11
			try:
				win_version_number = int(platform.version().split('.')[2])
				if win_version_number >= 22000:
					os_display = "Windows 11"
				else:
					os_display = "Windows 10"
			except (ValueError, IndexError):
				os_display = "Windows" # Fallback if version number is not as expected
		elif os_name in ["Linux", "Darwin"]:
			os_display = f"{os_name} {platform.release()}"
		
		report.append(f"Operating System: {os_display}")
	
	# Conditionally add processor details
	processor_info = platform.processor() if report_options.report_include_processor else 'OPT OUT'
	report.append(f"Processor: {processor_info}")
	
	# --- Platform Summary ---
	report.append("\n--- Platform Summary ---")
	platform_info = platform.platform() if report_options.report_include_os_details else 'OPT OUT (Full Platform Info)'
	report.append(f"Full Platform Info: {platform_info}")
	
	# --- Architecture and C Library ---
	report.append("\n--- Architecture & C Library ---")
	# Conditionally add architecture linkage
	arch_info = platform.architecture()
	arch_display = arch_info if report_options.report_include_arch_linkage else f"{arch_info[0]} (bits)"
	report.append(f"System Architecture: {arch_display}")
		
	report.append(f"Libc Version: {platform.libc_ver()}")

	# --- Python Environment Information ---
	report.append("\n--- Python Environment Information ---")
	report.append(f"Python Version: {platform.python_version()}")
	report.append(f"Python Implementation: {platform.python_implementation()}")
	report.append(f"Python Build Info: {platform.python_build()}")

	# --- sys Module Information ---
	report.append("\n--- System Information (sys Module) ---")
	report.append(f"Platform: {sys.platform}")
	report.append(f"Python Version Info: {sys.version}")
	
	# Conditionally add Python executable path
	python_path = sys.executable if report_options.report_include_python_path else 'OPT OUT'
	report.append(f"Python Executable Path: {python_path}")
	
	report.append(f"Maximum Integer Size: {sys.maxsize}")
	report.append(f"Recursion Limit: {sys.getrecursionlimit()}")
	report.append(f"Command-line Arguments: {sys.argv}")
	
	# --- OS and Process Information ---
	report.append("\n--- OS and Process Information (os Module) ---")
	report.append(f"OS Type: {os.name}")
	
	# Conditionally add Current Working Directory
	cwd_info = os.getcwd() if report_options.report_include_cwd else 'OPT OUT'
	report.append(f"Current Working Directory: {cwd_info}")

	# --- Section 2: Stored Variables ---
	report.append("============--- [Contextual Variables] ---============")
	
	# Add a try block for each variable to prevent the report from failing if a variable is the source of the error
	try:
		report.append(f"  - Current Addon Version: {'.'.join(map(str, bl_info.get('version', 'N/A')))}")
	except Exception as e:
		report.append(f"  - Error getting addon version: {e}")
		report.append(f"    Traceback: {str(traceback.format_exc().strip())}")

	try:
		active_obj = bpy.context.active_object
		report.append(f"  - Active Object Name: {active_obj.name if active_obj else 'None'}")
	except Exception as e:
		report.append(f"  - Error getting active object name: {e}")
		report.append(f"    Traceback: {str(traceback.format_exc().strip())}")

	try:
		active_obj = bpy.context.active_object
		report.append(f"  - Active Object Type: {active_obj.type if active_obj else 'None'}")
	except Exception as e:
		report.append(f"  - Error getting active object name: {e}")
		report.append(f"    Traceback: {str(traceback.format_exc().strip())}")
		
	try:
		scene = bpy.context.scene
		report.append(f"  - Scene Frame Range: {scene.frame_start} to {scene.frame_end}")
	except Exception as e:
		report.append(f"  - Error getting scene frame range: {e}")
		report.append(f"    Traceback: {str(traceback.format_exc().strip())}")

	try:
		active_obj = bpy.context.active_object
		if active_obj and active_obj.type == 'CAMERA':
			settings = active_obj.data.auto_cutsmart_settings
			scene_status = scene.auto_cutsmart_status
			decimate_blocks_collection = active_obj.data.decimate_blocks

			# 1. Print CameraSplitSettings properties
			report.append("\n--- Auto CutSmart Object Settings Properties---")
			for prop in settings.bl_rna.properties:
				if prop.identifier != 'rna_type':
					prop_value = getattr(settings, prop.identifier)
					report.append(f"  - {prop.identifier}: {prop_value}")

			# 2. Print CameraSplitSceneStatus properties
			report.append("\n--- Auto CutSmart Scene Status Properties ---")
			for prop in scene_status.bl_rna.properties:
				if prop.identifier != 'rna_type':
					prop_value = getattr(scene_status, prop.identifier)
					report.append(f"  - {prop.identifier}: {prop_value}")

			# 3. Print DecimateBlock collection items based on decimate_type
			report.append("\n--- DecimateBlock Collection Items ---")
			if decimate_blocks_collection:
				for i, block in enumerate(decimate_blocks_collection):
					report.append(f"  - Item {i+1}:")
					for prop in block.bl_rna.properties:
						if prop.identifier != 'rna_type':
							prop_value = getattr(block, prop.identifier)
							if prop.identifier == 'decimate_type':
								report.append(f"      {prop.identifier}: {prop_value}")
								if prop_value == 'RATIO':
									# Print only 'factor' for decimate_type == 'RATIO'
									factor = getattr(block, 'factor', None)
									report.append(f"      factor: {factor}")
								elif prop_value == 'ERROR':
									# Print only 'error_margin' for decimate_type == 'ERROR'
									error_margin = getattr(block, 'error_margin', None)
									report.append(f"      error_margin: {error_margin}")
								
					report.append("")

			else:
				report.append("     The 'decimate_blocks' collection is empty.")    
		else:
			report.append("  - Camera Settings: Not a camera object or no object active.")
	except Exception as e:
		report.append(f"  - Error getting camera settings: {e}")
		report.append(f"    Traceback: {str(traceback.format_exc().strip())}")
		
	try:
		# Access the addon preferences using its __package__ name
		prefs = bpy.context.preferences.addons[__package__].preferences
		
		report.append("--- AUTO_CUTSMART_ADDON_Preferences Properties ---")
		
		# Iterate through all properties defined on the class
		for prop in prefs.bl_rna.properties:
			# Exclude default Blender properties that are not part of the addon
			if prop.identifier != 'rna_type':
				prop_name = prop.identifier
				prop_value = getattr(prefs, prop_name)
				report.append(f"  - {prop_name}: {prop_value}")

	except KeyError:
		report.append("Error: The 'Camera Jump Split' addon is not enabled or its package name is not found.")
		
	except Exception as e:
		report.append(f"  - Error getting addon preferences: {e}")
		report.append(f"    Traceback: {str(traceback.format_exc().strip())}")
	
	report.append("")
	
	# --- Section 3: Log ---
	report.append("==========--- [Log] ---==========")
	for level, msg in log_storage:
		report.append(f"{msg}")

	# Redact all entries in the report containing a traceback
	for i, entry in enumerate(report):
		report[i] = redact_traceback(entry)

	return "\n".join(report)
