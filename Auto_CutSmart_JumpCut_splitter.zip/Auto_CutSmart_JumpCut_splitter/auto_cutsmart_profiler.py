# ===============================
# FILE: camera_split_profiler.py
# (with persistence + coefficients stored)
# ===============================
"""
The profiler module for the Camera Jump Split addon.

This module is responsible for:
1. Storing and retrieving historical run data for the addon.
2. Using polynomial regression to calculate coefficients for the progress bar's dynamic weights.
3. Providing an API for the main addon script to record stage timings and metrics.
"""

# --- Imports --- #
import bpy
import time, os, json
from math import isfinite
from typing import Dict, List, Any, Optional, Tuple
import numpy as np
import importlib

from collections import defaultdict, deque
import traceback

# ----------------------------
# Globals
# ----------------------------
STORAGE_FILENAME = "auto_cutsmart_learning.json"
_profiler_data: Dict[str, Any] = {"runs": [], "coefficients": {}}
_coefficients: Dict[str, List[float]] = {}
_current_stage_index: Optional[int] = None
_stage_started_at: float = 0.0
_run_timings: Dict[int, float] = {}
_run_metrics: Dict[str, List[float]] = {}
log_storage = []
_addon_root = None

# Labels for each coefficient used in the regression model for logging and CSV export.
# labels must  match the feature vectors being generated in __init__.py
COEFFICIENT_LABELS = {
	"stage_0": ["redraw_time"],
	"stage_1": ["num_markers", "is_zero_buffer", "dist_from_one_sq", "decay_feature", "redraw_time"],
	"stage_2": ["num_fcurves", "num_children", "is_zero_buffer", "dist_from_one_sq", "decay_feature", "redraw_time"],
	"stage_3": ["num_keyframes", "is_zero_buffer", "dist_from_one_sq", "decay_feature", "redraw_time"],
	"stage_4": ["bake_frames", "decimate_blocks", "is_zero_buffer", "dist_from_one_sq", "decay_feature", "redraw_time"],
	"stage_5": ["num_fcurves", "is_zero_buffer", "dist_from_one_sq", "decay_feature", "redraw_time"],
	"stage_6": ["num_keyframes", "is_zero_buffer", "dist_from_one_sq", "decay_feature", "redraw_time"], # Using num_keyframes as a proxy for num_segments
	"stage_7": ["num_keyframes", "is_zero_buffer", "dist_from_one_sq", "decay_feature", "redraw_time"], # Using num_keyframes as a proxy for num_segments
	"stage_8": ["num_keyframes", "is_zero_buffer", "dist_from_one_sq", "decay_feature", "redraw_time"], # Using num_keyframes as a proxy for num_jumps
	"stage_9": ["redraw_time"],
}

# ----------------------------
# Paths & Persistence
# ----------------------------

def get_storage_path() -> str:
	"""
	Returns the full path to the learning data storage file in the user's Blender config directory.
	"""
	try:
		return os.path.join(bpy.utils.user_resource('CONFIG', path="auto_cutsmart_addon_LearningData", create=True), STORAGE_FILENAME)
	except Exception:
		log_msg(10, "An error occurred during [PROFILER] get_storage_path: {}".format(traceback.format_exc()))

def load_learning_data() -> Tuple[Any, bool]:
	"""
	Loads learning data and coefficients from the storage file.

	[MODIFIED] This function now returns a tuple: (data, success_flag).
	`data` is _profiler_data if refit=True, else _coefficients.
	`success_flag` is False if the data file was corrupt, allowing the main
	operator to notify the user.

	Args:
		refit (bool): If True, refits the regression model after loading.

	Returns:
		Tuple[Any, bool]: A tuple containing the loaded data and a success flag.
	"""
	try:
		global _profiler_data, _coefficients
		path = get_storage_path()
		was_corrupted = False
		if os.path.exists(path):
			try:
				with open(path, 'r', encoding='utf-8') as f:
					_profiler_data = json.load(f)
				# --- [FIX] Basic validation to detect corrupted structure ---
				if not isinstance(_profiler_data.get("runs"), list) or \
				   not isinstance(_profiler_data.get("coefficients"), dict):
					raise TypeError("Learning data has an invalid format.")
				_coefficients = _profiler_data.get("coefficients", {})
			except (json.JSONDecodeError, TypeError) as e:
				log_msg(1, f"Warning: Auto CutSmart learning data file might be corrupted. Error: {e}. Using defaults for this session.")
				_profiler_data = {"runs": [], "coefficients": {}}
				_coefficients = {} # Reset to empty, main script will use defaults
				was_corrupted = True
			except Exception as e:
				log_msg(1, f"Error loading learning data from {path}: {e}")
				_profiler_data = {"runs": [], "coefficients": {}}
				_coefficients = {}
				# Consider other errors as potential corruption for safety
				was_corrupted = True
		else:
			# File doesn't exist, which is a normal case
			_profiler_data = {"runs": [], "coefficients": {}}
			_coefficients = {}

		if not was_corrupted:
			return _coefficients, not was_corrupted
	except Exception:
		log_msg(10, "An error occurred during [PROFILER] load_learning_data: {}".format(traceback.format_exc()))

def save_learning_data() -> bool:
	"""
	[MODIFIED] Saves the current learning data and coefficients to the storage file
	using a safe temp-file-and-rename approach to prevent corruption.
	"""
	try:
		global _profiler_data, _coefficients
		_profiler_data["coefficients"] = _coefficients
		
		# Convert _profiler_data["runs"] to a list if it's a deque
		if isinstance(_profiler_data["runs"], deque):
			_profiler_data["runs"] = list(_profiler_data["runs"])
		
		path = get_storage_path()
		temp_path = path + ".tmp"
		
		try:
			# Write to a temporary file first
			with open(temp_path, 'w', encoding='utf-8') as f:
				json.dump(_profiler_data, f, indent=2)
				
			# If write is successful, atomically replace the old file.
			log_msg(1, f" Saved Tmp File to: '{temp_path}'")
			os.replace(temp_path, path)
			log_msg(1, f" Saved File to: '{path}'")
			
			return True
			
		except Exception as e:
			log_msg(10, f"Auto CutSmart Addon: Failed to save learning data: {e}\n{traceback.format_exc()}")
			
			# Clean up the temp file if it exists on failure
			if os.path.exists(temp_path):
				try:
					os.remove(temp_path)
				except Exception as e_clean:
					 log_msg(10, f"Could not remove temporary file {temp_path}: {traceback.format_exc()}")
			return False
	except Exception:
		log_msg(10, "An error occurred during [PROFILER] save_learning_data: {}".format(traceback.format_exc()))

def reset_learning_data():
	"""
	Deletes the learning data file from disk.
	"""
	path = get_storage_path()
	if os.path.exists(path):
		try:
			os.remove(path)
			log_msg(1, f"Learning data file deleted: {path}")
		except Exception as e:
			log_msg(10, f"Auto CutSmart Addon: Failed to delete learning data: {traceback.format_exc()}")
	else:
		log_msg(1, f"The file {path} does not exist.")

# ----------------------------
# Core Profiler API
# ----------------------------

def init_run():
	"""
	Initializes the profiler for a new run.
	"""
	try:
		global _run_timings, _run_metrics, _current_stage_index, _stage_started_at
		_run_timings = {}
		_run_metrics = {}
		_current_stage_index = None
		_stage_started_at = 0.0
	except Exception:
		log_msg(10, "An error occurred during [PROFILER] init_run: {}".format(traceback.format_exc()))

def profiler_begin(stage_index: int):
	"""
	Starts timing for a specific stage.
	"""
	try:
		global _current_stage_index, _stage_started_at
		_current_stage_index = stage_index
		_stage_started_at = time.perf_counter()
	except Exception:
		log_msg(10, "An error occurred during [PROFILER] profiler_begin: {}".format(traceback.format_exc()))

def profiler_end(NoSkip = True):
	"""
	Stops timing the current stage and records the elapsed time.
	"""
	try:
		global _current_stage_index, _stage_started_at, _run_timings
		if _current_stage_index is None:
			return
		elapsed = max(0.0, time.perf_counter() - _stage_started_at) if NoSkip else 0.0
		_run_timings[_current_stage_index] = _run_timings.get(_current_stage_index, 0.0) + elapsed
		log_msg(2, f"Run Timing for [Stage {_current_stage_index}]: {_run_timings[_current_stage_index]}")
		_current_stage_index = None
		_stage_started_at = 0.0
	except Exception:
		log_msg(10, "An error occurred during [PROFILER] profiler_end: {}".format(traceback.format_exc()))

def record_stage_features(stage_key: str, feature_vector: List[float]):
	"""
	Records the feature vector for a specific stage of the current run.
	"""
	try:
		_run_metrics[stage_key] = feature_vector[:]
	except Exception:
		log_msg(10, "An error occurred during [PROFILER] record_stage_features: {}".format(traceback.format_exc()))

def finalize_run():
	"""
	Finalizes the current run, stores the data, refits the regression model, and saves to file.
	"""
	try:
		preferences = bpy.context.preferences.addons[__package__].preferences

		# Max History Remover
		original_runs_type = type(_profiler_data["runs"])  # Store the original type of runs
		log_msg(1, f"Total Runs: {len(_profiler_data['runs'])+1}")
		if preferences.max_run_history > 0:
			if not isinstance(_profiler_data["runs"], deque):  # Only convert to deque if not already a deque
				_profiler_data["runs"] = deque(_profiler_data["runs"], maxlen=preferences.max_run_history)	# Convert to deque

		if _run_timings:
			_profiler_data["runs"].append({	 # Add the new run to the learning data
				"metrics": _run_metrics.copy(),
				"timings": {str(k): float(v) for k, v in _run_timings.items()}})

			if not preferences.only_record_run:
				_refit_all_stages()

			# Revert back to the original type (e.g., list) if necessary
			if original_runs_type != deque:
				_profiler_data["runs"] = list(_profiler_data["runs"])

			save_learning_data()

	except Exception:
		log_msg(10, "An error occurred during [PROFILER] finalize_run: {}".format(traceback.format_exc()))

def get_run_timings():
	"""
	Returns the timings for the current run.
	"""
	return dict(_run_timings)

def get_coefficients() -> Dict[str,List[float]]:
	"""
	Returns the currently loaded coefficients.
	"""
	return dict(_coefficients)

def get_default_coefficients() -> Dict[str, List[float]]:
	"""
	Returns a hardcoded set of default coefficients.
	"""
	return {
		"stage_0": [0.045498669731025676],
		"stage_1": [0.16262600209913752, 0.004183876994349305, -0.03265116576356571, -0.00071250092224521, -0.023353664763765693, -4.48422058988516, -1.036446329354653e-05, -0.03265154153310536, 5.307581668298769e-08, 0.0015967431826911088, 134.9990882604032, -0.004253580839920281, 8.001815088067052e-07, -0.00010174007724942783, 0.12673682891570875, -0.03265034110255641, 0.0, -4.005698412650267, -1.197121367758258e-05, 0.0005161488969887786, -0.0548850225317595],
		"stage_2": [-1.2217676108887356, 0.32732312207763997, 0.019586565094767697, -0.2666935423428567, -0.01724748452830917, -0.007943951436372776, -18.66101614860946, -0.019090503965216474, -0.003693271797001643, -0.2666542937493059, 5.193994458108072e-08, 0.017953374143593177, 845.5321793573777, 0.0047881056691804645, 0.07766936405759782, 9.356747381084048e-06, -0.0009269600159181588, 2.99137404811934, 0.04708281352311007, 1.1772552263302857e-05, -0.0014121855537195353, 4.07790236422046, -0.26665411178127874, 0.0, 9.642982554457017, -1.144625818831307e-05, 0.0029061497845409663, -0.3534856721646575],
		"stage_3": [0.60235936996297, 0.0032439075250305064, -0.20745952833052111, -0.00806678473034063, -0.1042227663143662, 9.444476959459537, 1.673963209668044e-07, -0.20744482425855512, 2.447961828104799e-07, 0.01209051674090867, -89.81608780024438, -0.003043413941444666, 9.536732655174246e-07, -0.00011552624784520056, 0.0043859781085237365, -0.20745491414853065, 0.0, 0.20891175192713024, -5.4862363438824084e-05, 0.00032079004519376957, -0.06351508271952604],
		"stage_4": [0.0889578701903765, -9.931206735790985e-09, 0.0, -0.015225264060856097, -0.0016414122826244896, -0.004096856109105461, -7.787929909084316, 1.4890981287767773e-11, 0.0, -0.015227332107304205, 6.88051618496928e-09, 0.0017591722903460467, 194.17489683151942, 0.0, -3.744049528292719e-07, 8.476380642196118e-11, -1.4422088292211057e-08, -5.642457975359912e-05, 0.0, 0.0, 0.0, 0.0, -0.01522743265628347, 0.0, 2.1301831872445156, -1.5080037610472405e-06, -0.0006703759712147584, 0.11148675462118314],
		"stage_5": [0.1518710163969711, -0.12098158772576946, 0.08792974420244254, 0.006571874193547456, -0.01670236896471311, -24.942540016742267, 0.017408057063299516, 0.08792448923349121, 7.84819859906319e-08, -0.005432268612729014, -215.5406626387576, -0.05808490248783762, 1.671626282739925e-05, -0.0020020550280443732, 6.000570884512557, 0.08792448552913096, 0.0, -13.260705244097666, -1.748988338459558e-05, 0.004355317143018127, -0.5152235825638026],
		"stage_6": [0.09703421146324963, 0.0007200408092463579, -0.01905079735215623, -0.00026615573909797484, -0.01314398700935891, 3.284255899173332, 2.1959576672069383e-06, -0.019048001985457582, 3.137638059096711e-08, 0.0007828389036284055, 193.02073098335285, -0.0005200969260210613, 1.411805810993385e-07, -1.754557283908181e-05, 0.014887332367011027, -0.019051720907127413, 0.0, 0.5793799233685198, -7.048353152350197e-06, -0.00021045078381730242, 0.010412877782687388],
		"stage_7": [0.3926642309744752, 0.005875165419350921, -0.07939487968485097, -0.0016322542943471923, -0.16160394950928755, 57.75380075058679, -7.158363213754681e-08, -0.07942435206083223, 4.5269185548659265e-07, 0.008821408137917673, -38.02819796397829, -0.006944730440072065, 1.8930194381331916e-06, -0.00024077808524886323, 0.08325325046636066, -0.07941357079586496, 0.0, -67.97883213829438, -0.00010138988134940566, 0.018929179465432464, -2.371283340652857],
		"stage_8": [0.20000704564060892, 0.0006586173014953775, -0.053029524724978815, -0.0021916785208957773, -0.024097913741672722, -0.6670364676053623, -2.2959535495455434e-08, -0.05302422239614516, 5.3646640181297405e-08, 0.003081549219513421, 240.8483023579013, -0.0007334333061885394, 1.8097281972507465e-07, -2.2565182642629883e-05, 0.008804138680214589, -0.05302692094923966, 0.0, 2.7818938831424083, -1.2003387721708912e-05, -0.0005524109859713669, 0.06829774235275266],
		"stage_9": [0.09840443764233593]
	}

# ----------------------------
# Polynomial regression engine
# ----------------------------

def _poly_features(vec: List[float], degree: int = 2) -> List[float]:
	"""
	Expands a feature vector into a polynomial feature vector.
	This function must be kept consistent with `_poly_features_local` in __init__.py.
	"""
	try:
		feats = [1.0]
		feats.extend(vec)
		if degree >= 2:
			n = len(vec)
			for i in range(n):
				feats.append(vec[i] * vec[i])
			for i in range(n):
				for j in range(i + 1, n):
					feats.append(vec[i] * vec[j])
		if degree >= 3:
			for x in vec:
				feats.append(x * x * x)
		return feats
	except Exception:
		log_msg(10, "An error occurred during [PROFILER] _poly_features: {}".format(traceback.format_exc()))

def _fit_linear_regression(X: List[List[float]], y: List[float], l2: float = 1e-6) -> List[float]:
	"""
	Fits a linear regression model with L2 regularization (ridge regression).
	"""
	try:
		m = len(X)
		if m == 0:
			return []

		n = len(X[0])
		try:
			X_mat = np.array(X)
			y_mat = np.array(y)
			# Add a small L2 regularization to prevent singular matrix issues
			regularization_mat = l2 * np.identity(n)
			coeffs = np.linalg.solve(X_mat.T @ X_mat + regularization_mat, X_mat.T @ y_mat)
			return coeffs.tolist()
		except np.linalg.LinAlgError:
			log_msg(1, f"Linear regression failed due to a singular matrix. Returning empty coefficients.")
			return []
		except Exception as e:
			log_msg(10, "An unexpected error occurred during regression: {}".format(traceback.format_exc()))
			return []
	except Exception:
		log_msg(10, "An error occurred during [PROFILER] _fit_linear_regression: {}".format(traceback.format_exc()))

def _refit_all_stages():
	"""
	Re-fits the regression model for all stages based on collected run data.
	"""
	global _profiler_data, _coefficients

	try:
		# Group data by stage
		stage_data = {key: {'X': [], 'y': []} for key in COEFFICIENT_LABELS.keys()}

		# Collect data from all runs
		for run in _profiler_data.get("runs", []):
			metrics = run.get("metrics", {})
			timings = run.get("timings", {})

			for stage_key, features in metrics.items():
				if stage_key in COEFFICIENT_LABELS:
					try:
						# Find the corresponding timing
						stage_index = int(stage_key.split('_')[-1])
						timing = timings.get(str(stage_index))
						if timing is not None and isfinite(timing) and timing > 0:
							poly_feats = _poly_features(features)
							stage_data[stage_key]['X'].append(poly_feats)
							stage_data[stage_key]['y'].append(timing)
					except (ValueError, TypeError):
						continue # Skip invalid data

		# Fit a model for each stage
		new_coefficients = {}
		for stage_key, data in stage_data.items():
			if data['X']:
				if stage_key in ("stage_0", "stage_9"):
					# Special handling for Stage 0 and Stage 9: compute ratio against middle stages
					ratios = []
					for run in _profiler_data.get("runs", []):
						timings = run.get("timings", {})
						try:
							stage_index = int(stage_key.split('_')[-1])
							t = timings.get(str(stage_index))
							# Sum of timings excluding Stage 0 and Stage 9
							midsum = sum(v for k, v in timings.items() if k not in ("0", "9"))
							if t and midsum > 0:
								ratios.append(t / midsum)
						except Exception:
							continue
					const_ratio = sum(ratios) / len(ratios) if ratios else 0.01
					new_coefficients[stage_key] = [const_ratio]
				else:
					# Use regular regression for all other stages
					coeffs = _fit_linear_regression(data['X'], data['y'])
					if coeffs:
						new_coefficients[stage_key] = coeffs
			else:
				# Fallback to defaults if no data to fit
				new_coefficients[stage_key] = get_default_coefficients().get(stage_key, [])

		_coefficients = new_coefficients
		log_msg(1, "Successfully re-fitted coefficients.")

	except Exception as e:
		log_msg(10, "An error occurred during [PROFILER] _refit_all_stages: {}".format(traceback.format_exc()))
		_coefficients = get_default_coefficients()

# ----------------------------
# Verbosity and Logging
# ----------------------------

def _get_addon_root():
	try:
		global _addon_root
		if _addon_root is None:
			_addon_root = importlib.import_module(__package__)
		return _addon_root
	except Exception:
		log_msg(10, "An error occurred during [PROFILER] _get_addon_root: {}".format(traceback.format_exc()))

def VerboseActive(level: int) -> bool:
	"""Check verbosity flags from the main addon preferences."""
	return _get_addon_root().VerboseActive(level)

def log_msg(level: int, msg: str) -> None:
	"""Forward profiler log messages to the main addon's logger."""
	_get_addon_root().log_msg(level, msg)

def log_profiler_summary(stage_labels):
	"""Print a neat summary of profiler timings with stage labels."""
	try:
		if VerboseActive(1):
			timings = get_run_timings()
			if not timings:
				log_msg(1, "Profiler: no timings recorded this run.")
				return

			log_msg(1,"==== Profiler Summary ====")
			total = sum(timings.values())
			for idx, label in enumerate(stage_labels):
				t = timings.get(idx, 0.0)
				pct = (t / total * 100.0) if total > 0 else 0.0
				log_msg(1,f"Stage {idx} ({label}): {t:.4f}s ({pct:.1f}%)")
			log_msg(1,f"TOTAL: {total:.4f}s")
			log_msg(1,"==========================")
	except Exception:
		log_msg(10, "An error occurred during [PROFILER] log_profiler_summary: {}".format(traceback.format_exc()))

# ----------------------------
# Initialization
# ----------------------------
def initialize_profiler():
	"""
	Function to be called by the main addon's register() to load data safely.
	"""
	try:
		global _addon_root # Make sure this line exists
		_addon_root = importlib.import_module(__package__)
		load_learning_data()
		print("Auto CutSmart Profiler Loaded")
	except Exception:
		log_msg(10, "An error occurred during [PROFILER] initialize_profiler: {}".format(traceback.format_exc()))
